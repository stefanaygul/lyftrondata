

"""
    # USER NOTE
    "Connection Type" :{
        "your parameter " : "connector parameter "
    }
"""
MAPPING = {

    "personaltoken": {
        "personal_token": "personal_token"
    },
    "basicauth": {
        "username": "username",
        "password": "password"
    },
    "oauth2": {
        "client_id": "client_id",
        "client_secret": "client_secret",
        "redirect_uri": "redirect_uri",
        "scope": "scope"
    },
    "oauth2_client_credentials": {
        "client_id": "client_id",
        "client_secret": "client_secret",
        "redirect_uri": "redirect_uri",
        "scope": "scope",


    },
    "aws": {
        "accessKey": "access_key_id",
        "secretKey": "secret_access_key",
        "region": "region_name",
        "bucket": "bucket",
        "aggregate": "aggregate",
    }

}
