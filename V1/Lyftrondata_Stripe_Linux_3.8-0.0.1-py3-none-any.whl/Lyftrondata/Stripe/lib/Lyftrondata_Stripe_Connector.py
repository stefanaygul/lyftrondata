from sqlalchemy import create_engine
import pandas as pd
import sqlparse
import requests
import math
import schedule
import time
import os
import re
import json
import concurrent.futures
import base64 

from Lyftrondata.Stripe.lib import Lyftrondata_Stripe_utils as utils
from Lyftrondata.Stripe.config import config, mapping
from Lyftrondata import payasyougo as pg, AutomatedSchema as AutoSchema

global Connector_name
Connector_name = "Lyftrondata_Stripe_Connector"

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

data = []
gs = None
dt = None
lookUp = None
engine = create_engine('sqlite://')
engines = [['PostgreSQL','postgresql://scott:tiger@localhost/mydatabase'],['Sql Server','mssql+pyodbc://scott:tiger@mydsn'],['Oracle','oracle://scott:tiger@127.0.0.1:1521/sidname'],['MySQL','mysql://scott:tiger@localhost/foo'],['SQLite','sqlite:///foo.db']]
supportedEngines = pd.DataFrame(columns=['Engine Name','Example Connection'],data=engines,index=None)

##########################################################################
            ####   CONNECTIONS DATA PARSER FETCH DATA    ####
##########################################################################

class Connect:
    ##########################################################################
    #####   ALL CLASS VARIABLES    ####
    ##########################################################################


    dirname = os.path.dirname(__file__)
    endpoints = dict()

    # CALLOUT PARAMS
    StartTime = time.time()
    worker = 10
    session = requests.Session()
    code = None
    __environment = ''
    timeout = 10

    # AUTH PARAMS
    token = None
    expired_time = None
    fetched_time = None
    client_id = None
    client_secret = None
    refresh_token = None
    refreshtoken_url = ""
    base_url = "https://api.stripe.com/v1/"
    auth_url = ""
    token_url =  ""
    scope = ""
    subdomain = ""

    # LOG PARAMS
    logging_options = False
    log_connection = True

    # MAKE ALL OAUTH CUSTOM SETTING HERE
    oauth_settings = {
        "auth_url": auth_url,
        "token_url": token_url,
        "auth_params": {'response_type': 'code', 'access_type': 'offline', 'prompt': 'consent'},
        "token_params": {'grant_type': 'authorization_code'},
        "token_headers": None,
        "token_data": None, # set to None if no token data is required
    }

    authhandler = utils.Lyftrondata_authHandler()

    ##########################################################################
    #####   INITS    ####
    ##########################################################################

    def __init__(self, LicenseKey):
        self.LicenseKey = LicenseKey
        self.abs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ''))
        self.schema_path = f'{self.abs_path}/schema/{Connector_name}.json'
        endpointjson = f'{self.abs_path}/config/{Connector_name}_endpoints.json'
        
        with open(endpointjson, "r") as readEndpoints:
            self.endpoints = json.load(readEndpoints)
    
    
    def replacement(self, x): 
        return x.replace('"', '').replace("'", '')

    ##########################################################################
    #####   SCHEMA AND OBJECT LISTING   ####
    ##########################################################################

    def schema_generator(self, table, jsn):
        filename = Connector_name.split("_")[1]
        tables = []

        if os.path.exists(self.schema_path):
            with open(self.schema_path) as sch:
                schema = json.load(sch)
            tables = list(schema['Tables'].keys())
            
        if bool(tables) and bool(jsn) and table not in tables:
            cleaned_response = AutoSchema.clean_null(jsn)
            AutoSchema.create_schema(filename, cleaned_response)
            AutoSchema.addConstraint(filename)


    def getMetadata(self):
        response = {'tables': {}}
        jsn = pd.read_json(self.schema_path, orient="records", typ="records")
        for k,v in jsn['Tables'].items():
            if k.__contains__('sys.'):
                pass
            else:
                response['tables'][k] = v

        return response


    def getConnectorDefinition(self,param):
        
        if isinstance(param, str):
            csv = pd.read_csv(param)
            return csv.to_json(orient='records')
        else:
            engine = param['engine']
            db = param['db']
            name = param['name']
            user = param['user']
            password = param['password']
            host = param['host']
            port = param['port']
            engine = create_engine(
                engine+'://'+user+':'+password+'@'+host+':'+port+'/'+db)

            query = engine.execute(
                'select * from "Lyftrondata_Connector_Definition"')

            df = pd.DataFrame(query, columns=query.keys())
            return df.to_json(orient='records')


    def get_schema_tables(self):
        self.StartTime = time.time()

        """
        Returns a list of tables in the schema

        Returns: list of tables in the schema
        """
        try:
            tablelist = self.execute_query("select * from sys.tables")[1]
            tablelist = tablelist.loc[tablelist['datatype'] == 'table']
            data = tablelist.to_dict(orient='records')
            status = {
                'Status':'Success!'
                }
        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            data = e
        self.payasyougo_check(self.get_schema_tables,status)
        return data


    def get_table_columns(self, tables=[]):
        self.StartTime = time.time()

        """
        Get the columns of the table from the schema

        Parameters:
            tables (list): List of tables

        Returns:
            list: List of columns of the table
        """
        res = []
        try:
            jsn = json.load(open(self.schema_path))["Tables"]
            for k in jsn:
                if k in tables:
                    res.append(jsn[k])
            status = {
                'Status':'Success!'
                }

        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            res = e

        self.payasyougo_check(self.get_table_columns,status)
        return res


    def get_schema_list(self,con=''):
        StartTime = time.time()
        schema_list = []
        try :
            schema_list.append(f'{Connector_name}')
            status = {
                'Status':'Success!',
                "Result": schema_list
                }
            self.payasyougo_check(self.get_table_columns,status)
            return True, schema_list

        except Exception as e :
            status = {
                'Status':'Failed!',
                "Error": str(e)
                }
            self.payasyougo_check(self.get_table_columns,status)
            return False, str(e)


    def get_schema_objects(self,con,schemas):
        self.StartTime = time.time()
        schema_obj = dict()
        flag = False
        error_msg = ""
        for sch in schemas:
            tables_in_schema = list()

            try:
                with open(self.schema_path, "r") as schema:
                    schema_json = json.loads(schema.read())
                flag = True
                tables_in_schema = list(schema_json['Tables'].keys())
                schema_obj[sch['schema_name']] = {'TABLE':tables_in_schema, 'VIEW':[]}
                status = {
                    'Status':'Success!',
                    "Result": schema_obj
                }
            except Exception as e :
                status = {
                    'Status':'Failed!',
                    "Error": str(e)
                }
                flag, error_msg = False, str(e)

        self.payasyougo_check(self.get_schema_objects,status)

        return (flag, schema_obj) if flag else (flag, error_msg)


    def get_object_columns(self,con,obj):
        self.StartTime = time.time()
        obj_columns = dict()
        flag = False
        msg = str()

        for schema in obj:
            schema_name = schema['schema_name'].replace('_',' ')
            for objects in schema['object_list']:
                if 'TABLE' in objects:
                    tables = list()
                    views = list()

                    for table in objects['TABLE']:
                        column_list = list()
                        try:
                            with open(self.schema_path, "r") as schema:
                                schema = json.load(schema)

                            for obj in schema['Tables'][table]['columns']:
                                column_list.append({"column":obj['column'],"datatype":obj["datatype"],"description":obj["description"]})
                            status = {

                                'Status':'Success!',
                                }

                            flag = True
                        except Exception as e:
                            flag = False
                            msg = str(e)
                            status = {
                                'Status':'Failed!',
                                "Error": str(e)
                            }
                        tables.append({table:{'columns': column_list}})

            schema_name = schema_name.replace(' ', "_")
            obj_columns[schema_name] = {'TABLE' : tables,'VIEW': views}

        self.payasyougo_check(self.get_object_columns,status)

        return (flag, obj_columns) if flag else (flag, msg)

    ##########################################################################
    ####   MAKE CONNECTOR REQUESTS FROM API   ####
    ##########################################################################
    
    def makeView(self,required_parameter,baseUrl,replaced_parameter,col=None,val=None,jsn=None,endpoint=None):
        """
        Description:
        this method will be used when a person wants to filter per id(showing detailed explanantion). 
        It will find key and then get responses of each record

        Parameters:
            jsn ([list]): [contains the response of the main table ]
            required_parameter ([string]): [key so that we can filter against it ]
            base_url ([string]): [url to hit the main model/table]
            replaced_parameter ([string]) : key which have to be replaced by required parameter.
            endpoint ([string], optional): endpoint if required. default is None.
            
        """
        
        finalresponse=list()
        required_parameter=required_parameter.split('.')
        if col != None:          
            if replaced_parameter in col:
                a = val[col.index(replaced_parameter)]
                value = str(a)
                url = baseUrl + endpoint.replace(replaced_parameter, self.replacement(value))
                response = self.req(url)[1].json()
                if type(response) == list:
                    for i in response:
                        i[replaced_parameter]= self.replacement(str(a))
                else:
                    response[replaced_parameter] = self.replacement(str(a))
                
                finalresponse.append(response)
            return finalresponse         

        a = jsn
        b = []
        urls = list()
        for item in jsn:
            a=item
            for k in required_parameter:
                if k in a:
                    a = a[k]
                    url = baseUrl + endpoint.replace(replaced_parameter,str(a))
                    urls.append(url)
                    b.append(a)
                else:
                    raise KeyError(f"Unproper Response or {k} not found in response - contact help@lyftrondata.com")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.worker) as executor:
            futures =  executor.map(self.req, urls)
            futures = list(futures)
        
        for i, d in zip(futures, b):
            i = i[1].json()
            if type(i) == list:
                for j in i:
                    j[replaced_parameter]= self.replacement(str(d))
            else:
                i[replaced_parameter] = self.replacement(str(d))
            
            finalresponse.append(i)
            
        return finalresponse


    def return_error(self, status_code, req):
        print(req.status_code, req.url)
        emptyjson = dict()
        
        if isinstance(status_code, str):
            status_code = int(status_code)

        if status_code == 200:
            print("Connection to table [Success]")
            try:
                return True , req
            except:
                raise Exception("Connection to table [Success] but response is not in json format")
        
        elif status_code in utils.request_exceptions:
            custom_exception = utils.request_exceptions[status_code]
            raise requests.exceptions.RequestException(custom_exception)
        
        else:
            raise requests.exceptions.RequestException(f"{str(status_code)} AN UNKNOWN ERROR OCCURED")


    def req(self,url,headers=None,params=None):
        
        """ This Function is used for making request on endpoints.

        Args:
            url (string): endpoint url
            headers (dict, optional): headers for the request if required. Defaults to None.
            params (dict, optional):  params for the request if required. Defaults to None.

        Returns:
            json: response from the endpoint in form of json/dict
        """
        if self.expired_time != None:
            isExpired = self.authhandler.check_expire_time(self.expired_time, self.fetched_time)
            print(f'is token expired ? {isExpired}')
            
            if isExpired == True and self.refresh_token != None:
                self.refreshtoken_url = self.refreshtoken_url.replace("SUBDOMAIN", self.subdomain)
                
                refreshtoken_data = {
                    'grant_type': 'refresh_token',
                    'refresh_token': self.refresh_token,
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'scope': self.scope
                }
                
                refresh = self.authhandler.refreshToken(
                    self.token_file,
                    refreshtoken_url=self.refreshtoken_url,
                    refreshtoken_params=None,
                    refreshtoken_data=refreshtoken_data
                )

                self.expired_time = refresh.get('expires_in')
                self.fetched_time = refresh.get('fetched_at')
                self.refresh_token = refresh.get('refresh_token')
                self.token = refresh.get('access_token')
                
            elif isExpired == True and self.refresh_token == None:
                os.remove(self.token_file)
                raise Exception("Token expired and refresh token not found")

                
        headers= {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.token}',
        }

        req = self.session.get(url, headers=headers,data=data )
        return self.return_error(req.status_code,req)

    ##########################################################################
    ####   INTIALIZE AND LOAD USER CREDIENTIALS   ####
    ##########################################################################

    def test_connection(self, obj):
        """
        Make a test connection to the API.

        Args:
            endpoint_path: 

        Returns:
            Message indicating the connection status.
        """
        if obj is not None:
            return True, ""
        else:
            return False, "Connection Failed"


    def token_file_handler(self, token_file):
        with open(token_file, "r") as tokenfile:
            tokenjson = json.load(tokenfile)
        
        self.token = tokenjson.get('access_token')
        self.expired_time = tokenjson.get('expires_in')
        self.refresh_token = tokenjson.get('refresh_token')
        self.fetched_time = tokenjson.get('fetched_at')
        
        return self.token
    

    def initializeJson(self, creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        self.StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'

        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            status = {
                    'Connection String':'',
                    'Status': f'Failed! {str(e)}'
                        }

            self.payasyougo_check(self.initialize, str(e))
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : utils.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : utils.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : utils.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : utils.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : utils.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : utils.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : utils.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : utils.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : utils.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : utils.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : utils.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : utils.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : utils.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "environment" : utils.dict_mapping(init_jsn,connection_type).get('environment'),
            "logging_options" : utils.dict_mapping(init_jsn,connection_type).get('logging_options') or init_jsn.get('logging_options') or False
        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            status = {
                'Connection String' : init_params,
                'Status': 'Success!'
            }
            self.payasyougo_check(self.initializeJson,status)
            return init

        except Exception as e:
            status = {
                'Connection String' : init_params,
                'Status': f'Failed! {str(e)}'
            }

            self.payasyougo_check( self.initializeJson,status)

            raise Exception(e)


    def initialize(self,connection_type=None, personal_token=None, client_id=None, client_secret=None, redirect_uri=None,
                        subdomain=None, username=None, password=None, lyft_token_email=None, environment=None,
                        access_key_id=None, secret_access_key=None, region_name=None, bucket=None,
                        aggregate=False,logging_options=False):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            connection_type ([string], required): [provide the connection type "personalToken" if you want to access by personal token generated by API.
                                        or "OAuth2" if you want to provide credentials to get access].
            personal_token ([string], optional): [do provide personaltoken if you selected Connection_type as personalToken]. Defaults to None.
            client_id ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            client_secret ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            redirect_uri ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            subdomain ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None. (If Required)
            username ([string], optional): [provided by API it is required if connection type is "basicAuth"]. Defaults to None.
            password ([string], optional): [provided by API it is required if connection type is "basicAuth"]. Defaults to None.

        Returns:
            token: access token which will be used as to make requests.
        """

        self.StartTime = time.time()
        self.logging_options = logging_options
        self.__environment = environment or None

        self.__environment = environment or None
        if lyft_token_email != '':
            self.token_file = f'{self.abs_path}/{lyft_token_email}_{Connector_name}_token.json'
        else:
            if self.__environment == "development":
                self.token_file = f'{self.abs_path}/{Connector_name}_token.json'
            else:
                raise ValueError("Kindly Provide lyft_token_email")

        self.aggregate = aggregate or ""
        self.subdomain = subdomain or ""
        self.client_id = client_id or ""
        self.client_secret = client_secret or ""
        redirect_uri = redirect_uri or ""
        username = username or ""
        password = password or ""
        personal_token = personal_token or ""
        connection_type = connection_type or ""
        connection_string = str({
            'connection_type':connection_type,
            "personal_token":personal_token,
            "client_id":client_id,
            "client_secret":client_secret,
            'redirect_uri':redirect_uri,
            "subdomain":subdomain,
            "username":username,
            "password":password,
            "lyft_token_email":lyft_token_email,
            'access_key_id':access_key_id,
            "secret_access_key":secret_access_key,
            "region_name":region_name,
            'bucket':bucket,
            "aggregate":aggregate,
            "logging_options":self.logging_options
            })
        
        if connection_type.lower() == "personaltoken":
            self.token = personal_token

        elif connection_type.lower() == "basicauth":
            self.token = base64.b64encode(f"{username}:{password}".encode('utf-8')).decode('utf-8')

        elif connection_type.lower() == "oauth2":
            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file)

            else:
                token_params = {'client_id': self.client_id, 'client_secret': self.client_secret, 'redirect_uri': redirect_uri}
                auth_params = {'client_id': self.client_id, 'scope': self.scope, 'redirect_uri': redirect_uri}

                self.oauth_settings['auth_url'] = self.auth_url.replace("SUBDOMAIN", self.subdomain)
                self.oauth_settings['token_url'] = self.token_url.replace("SUBDOMAIN", self.subdomain)
                self.oauth_settings['token_params'].update(token_params)
                self.oauth_settings['auth_params'].update(auth_params)

                if self.code is not None:
                    self.oauth_settings['token_params']['code'] = self.code

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    with open(self.token_file, "w") as tokenjson:
                        json.dump(resp, tokenjson)
                else:
                    status = {
                        'Connection String':connection_string,
                        'Status': f'Failed! {str(resp)}'
                        }

                    self.payasyougo_check(self.initialize,status)
                    return False, resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        elif connection_type.lower() == "oauth2_client_credentials":

            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file)

            else:
                self.oauth_settings['auth_url'] = self.auth_url.replace("SUBDOMAIN", self.subdomain)
                self.oauth_settings['token_url'] = self.token_url.replace("SUBDOMAIN", self.subdomain)
                
                self.oauth_settings['token_params'] = {
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'grant_type': 'client_credentials',
                    'redirect_uri': redirect_uri
                }

                self.oauth_settings['auth_params'] = {}
                self.oauth_settings['token_headers'] = {'Content-Type': 'application/x-www-form-urlencoded'}

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    with open(self.token_file, 'w') as f:
                        json.dump(resp, f)
                else:
                    status = {
                    'Connection String':connection_string,
                    'Status': f'Failed! {str(resp)}'
                        }

                    self.payasyougo_check(self.initialize,status)
                    return False, resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        else:
            print("Provide the Connection Type: 'personalToken' or 'OAuth2' ")
            self.token = None
            status = {
                    'Connection String':connection_string,
                    'Status': 'Failed!',
                    'Error': 'Invalid connection_type'
                }
            self.payasyougo_check(self.initialize,status)
            return False , self.token
        
        status = {
                'Connection String':connection_string,
                'Status': 'Success!'
                }
        self.payasyougo_check(self.initialize,status)
        return True, self.token

    
    def fetchDataFromAPI(self,table,parameter=None,parameterValue=None):
        """
        Description:
            This Method is used to fetch data from API specific endpoint.
            
        Parameters:
            table(string): table name or endpoint name.
            col(list[string]): contains the column names 'SELECT * FROM table Where col = value'.
            value(list[string]): contains the value of specified column.
        
        Returns:
            jsn(json) : json file contains the complete response fetched from endpoint 
        """
        
        self.StartTime = time.time()
        fetchedData = dict()
        base = self.base_url.replace("SUBDOMAIN", self.subdomain)

        params = None
        response_json = dict()
        error_msg = None
        
        endpoint = self.endpoints.get('endpoints')
        views = self.endpoints.get('views')
        nested_endpoints = self.endpoints.get('nested_endpoints')

        if table.lower() in views.keys():
            tab = views[table.lower()]
            response = self.req(base+tab['from_endpoint'], params=params)
            parser = utils.Lyftrondata_Stripe_Parser(tab['from_endpoint_name'], response[1].json())
            parsed_parameters_json = parser.parse()

            response_json = self.makeView(
                jsn=parsed_parameters_json,
                required_parameter=tab['replace_from'],
                baseUrl=base,
                endpoint=tab['view_endpoint'],
                replaced_parameter=tab['replace_to'],
                col=parameter,
                val=parameterValue
            )

            status = {
                'Table': table,
                response[1].request.method:base+table,
                'Status': 'Success!',
                'Headers': response[1].headers,
                'Result': response_json
                }

        elif table.lower() in endpoint.keys():
            url = endpoint[table.lower()]
            complete_url = base+url
            complete_url = self.replacement(complete_url)
            response = self.req(complete_url, params=params)
            response_json = response[1].json()
            
            status = {
                'Table': table,
                response[1].request.method:complete_url,
                'Status': 'Success!',
                'Headers': response[1].headers,
                'Result': response_json
                }

        elif table.lower() in nested_endpoints.keys():
            nest_para = nested_endpoints[table.lower()]['parameters']
            tableurl = nested_endpoints[table.lower()]['url']
            for i in nest_para:
                
                if not parameter:
                    error_msg = ValueError(f"{nest_para} is not Given in query")
                
                if i in parameter:
                    tableurl = tableurl.replace(i, parameterValue[parameter.index(i)])
                else:
                    error_msg = ValueError(f"{i} is not Given in query")

            complete_url = base+tableurl
            response = self.req(self.replacement(complete_url), params=params)
            response_json = response[1].json()
            parser = utils.Lyftrondata_Stripe_Parser(table, response_json)
            parsedResponse = parser.parse()

            for i in nest_para:
                if not parsedResponse:
                    error_msg = Exception("No data found")
                else:
                    if type(parsedResponse) == list:
                        for l in parsedResponse:
                            l[i] = self.replacement(
                                parameterValue[parameter.index(i)])
                            parsedResponse[parsedResponse.index(l)] = l
                    else:
                        parsedResponse[i] = self.replacement(
                            parameterValue[parameter.index(i)])

            fetchedData = {table: parsedResponse}
            
            status = {
                'Table': table,
                response[1].request.method:response[1].url,
                'Status': 'Success!',
                'Headers': response[1].headers,
                'Body': response[1].content,
                'Result': response_json
            }

            self.payasyougo_check(self.fetchDataFromAPI,status)
            
            if error_msg: 
                status = {
                    'Table': table,
                    response[1].request.method:response[1].url,
                    'Status': f'Failed {str(error_msg)}'
                }            
            else: 
                return fetchedData
            
        else:
            response = self.req(base+table, params=params)
            response_json = response[1].json()
            status = {
                'Table': table,
                response[1].request.method:response[1].url,
                'Status': 'Success!',
                'Headers': response[1].headers,
                'Body': response[1].content,
                'Result': response_json
            }
            
        parser = utils.Lyftrondata_Stripe_Parser(table, response_json)

        parsedResponse = parser.parse()
        fetchedData = {table: parsedResponse}
        self.schema_generator(table, fetchedData)
        
        
        if error_msg:
            status = {
                'Table': table,
                response[1].request.method:response[1].url,
                'Status': f'Failed! {str(error_msg)}',
            }
            self.payasyougo_check(self.fetchDataFromAPI,status)
            return fetchedData

        else:
            self.payasyougo_check(self.fetchDataFromAPI,status)
            return fetchedData


    def json_parse(self,jsn, main_table_name):

        """
        Description:
            This method is used to parse/Normalize the Json Response fetched from endpoint in a way where
            object and array will be consider as separate Dataframes.

        Parameters:
            jsn(json): json response which have to be normalize.
            main_table_name: Main endpoint Name where the response is fetched from.

        Return:
            dataframes(dict) : dictionary which contains all the key as tablename and value as Dataframes.
        """
        dataframe = None
        simple = dict()
        dataFrames = dict()
        for key in jsn:
            val = jsn[key]
            if type(val) == list:
                dataFrames[key] = pd.DataFrame(val)
            elif type(val) == dict:
                dataframe = pd.DataFrame.from_dict(
                    val, orient="index")
                dataFrames[key] = dataframe.transpose()
            else:
                simple[key] = val
        if not simple:
            return dataFrames
        else:
            datafr = pd.DataFrame.from_dict(simple,orient="index")
            dataFrames[main_table_name] =datafr.transpose()
            return dataFrames

##########################################################################
            ####   SCHEMA GENERATION AND SYSTEMS QUERIES   ####
##########################################################################
 
    def execute_query(self, query,provider_obj=None):
        """
        Description:
            This method is used to break the query such as tablename, column,values

        Parameter:
            query(string): Takes Query in String Format.

        Returns:
            Table(pandas.DataFrame): Returns the dataframe contains the queried table data.

        """

        self.StartTime = time.time()
        parameter = list()
        parameterValue = list()
        columnsPart = list()
        select = list()
        subselect = list()
        subcol = list()
        col = list()
        table = list()
        updated = list()
        limit = list()
        new = list()
        offset = list()
        subtable = list()
        parsed = sqlparse.parse(query)
        stmt = parsed[0]
        where = str(stmt.tokens[-1])


        def __execute(table,parameter,parametervalue):
            if not bool(parameter) and not bool(parametervalue):
                parameter, parametervalue = None, None
            jsonres = self.fetchDataFromAPI(table,parameter,parametervalue)
            list_df = self.json_parse(jsonres, table)
            for df_name, df in list_df.items():
                self.dataToTable(df, df_name)

            try:
                r = engine.execute(query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True,df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        def __execute_sys(table,col):
            try :
                data = self.sysQueries(table,col)
                tablename = table.replace('.','_')
                self.dataToTable(data,tablename)
                modified_query = query.replace(table,tablename)
                r = engine.execute(modified_query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True , df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        if query.__contains__("Describe"):
            try:
                
                t =query.split("Describe ")
                data = self.sysQueries("sys.Describe", t[1])
                status = {"Status": "Success!",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return True , data

            except Exception as e:

                status = {"Status": f"Failed! {str(e)}",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        if re.search('select', where, re.IGNORECASE):

            columnsPart = where.split(
                'in ')[1] if where.__contains__("in ") else ""
            columnsPart = where.split('= ')[1] if len(
                columnsPart) < 1 else columnsPart
            columnsPart = (columnsPart.replace('(', ''))
            columnsPart = (columnsPart.replace(')', ''))
            parse = sqlparse.parse(columnsPart)

            stmts = parse[0]
            subselect = str(stmts.tokens[0])
            subcol = str(stmts.tokens[2])
            subtable = str(stmts.tokens[6])
            select = str(stmt.tokens[0])
            col = str(stmt.tokens[2])
            table = str(stmt.tokens[6])

            if query.lower().__contains__("sys."):
                return __execute_sys(table,col)
            else:
                return __execute(table,parameter,parameterValue)


        elif (re.search('=', where)):     # for query which has where clause
            select = str(stmt.tokens[0])
            col = str(stmt.tokens[2])
            table = str(stmt.tokens[6])
            where = str(stmt.tokens[8])
            where = where.split(" ")
            for i in where:
                if i == '=':
                    where.remove(i)
                elif i == 'or':
                    where.remove(i)
                elif i == 'and':
                    where.remove(i)

            where.pop(0)
            for j in where:
                if(re.search('=', j, re.IGNORECASE)):
                    t = j
                    where.remove(t)
                    j = j.replace('=', ' ')
                    where.append(j)

            for j in where:
                if (where.index(j) % 2) == 0:
                    parameter.append(j)
                else:
                    parameterValue.append(j)

            if query.lower().__contains__("sys."):
                return __execute_sys(table,col)

            else:
                return __execute(table,parameter,parameterValue)

        else:
            parsed = sqlparse.parse(query)
            stmt = parsed[0]
            select = str(stmt.tokens[0])
            col = str(stmt.tokens[2])
            table = str(stmt.tokens[6])
            jsonres = None

            if query.lower().__contains__("sys."):
                return __execute_sys(table,col)

            else:
                return __execute(table,parameter,parameter)


    def sysQueries(self,query,table):
        """
        Description:
            System Queries Method is used to fetch information schema from the system query.
                following are tableName:
                    (sys.table, sys.contraint, sys.delta, sys.methods, sys.logs, sys.usage, sys.license
                    sys.connectionstring, sys.version)
        Parameters:
            query: System table name.
        """

        qury = query.split(".")
        command = qury[1]
        jsn = pd.read_json(self.schema_path, orient="records", typ="records")

        if command == "tables":
            tablenames = jsn['Tables'].keys()
            tables = []
            tablestype = []
            for i in tablenames:
                tables.append(i)
                tablestype.append(jsn['Tables'][i]['datatype'])
            df = pd.DataFrame(tables, columns=["TableName"])
            df["DataType"] = tablestype
            return df

        elif command == "constraints":

            tables = []
            fk = []
            pk = []
            colname = []
            tablenames = jsn['Tables'].keys()

            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            tables.append(i)
                            colname.append(col['column'])
                            if col['constraint'].__contains__("PRIMARY"):
                                fk.append("NULL")
                                pk.append(col['constraint'])
                            else :
                                fk.append(col['constraint'])
                                pk.append("NULL")

            df = pd.DataFrame(tables, columns=["TableName"])

            df["PrimayKey"] = pk
            df["ForeignKey"] = fk
            df["ColumnName"] = colname
            return df

        elif command == "methods":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic['MethodName'] = i
                dic["return"] = jsn['Methods'][i]['return']
                dic["returntype"] = jsn['Methods'][i]['returntype']
                dic["description"] = jsn['Methods'][i]['description']
                para = jsn['Methods'][i]['parameters']
                dic["parameters"] =str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "logs":
            col = ["Logs"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "delta":
            jsn = pd.read_json(self.schema_path, orient="records", typ="records")
            tables = []
            deltafield = []

            tablenames = jsn['Tables'].keys()
            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            if col['constraint'].__contains__("PRIMARY"):
                                tables.append(i)
                                deltafield.append(col['column'])
            df = pd.DataFrame(tables, columns=["tablename"])
            df["DeltaField"] = deltafield
            return df

        elif command == "connectionstring":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic["Target"] = i
                para = jsn['Methods'][i]['parameters']
                dic["ConnectinParameters"] =  str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "version":
            return pd.DataFrame({'ConnectorVersion' : ["0.0.1"]})

        elif command == "limit":
            return pd.DataFrame({'ApiLimit' : ["100"]})

        elif command == "usage":
            #[licensekey	remaining_time	total_allowed_time	total_time_spent	start_time	end_time	total_time_taken	rows_allowed	rows_fetched	month	machine_name	mac	ip)
            col = ["Total Time Spent ", "Remaining Time", " Total Time alloted"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "license":
            col = ["LicenseKey", "ActivateDate", "ExpireDate", "Total Time Spent", "Remaining Time"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col,index=None)

        elif command == 'Describe':
            tables = jsn['Tables'][table]
            data = []
            constraints = []
            pk = ""
            fk = ""
            Statement = 'CREATE TABLE '+ table+'('
            for i in tables['columns']:
                Statement = Statement+i['column']+" "+i['datatype']+",\n"
                if i['constraint'].__contains__("PRIMARY"):
                    pk = "PRIMARY KEY ("+i['column']+"),\n"
                elif i['constraint'].__contains__("FOREIGN "):
                    fk = i['constraint']
                else:
                    pass
            describedtable = Statement[:-2]+",\n"+pk+fk+');'

            return describedtable
        else:
            return pd.DataFrame({'Error' : ["INVALID SYS QUERY"]})


##########################################################################
                    ########### UTILITIES ##############
##########################################################################

    def dataToTable(self,results,table,query=None):
        """
        Description:
            This Method is used to convert the Given Dataframe into SQL Table
        Parameters:
            results(pandas.DataFrame): dataframe which have to be convert into SQL TABLE .
            table(string) : Name of the DataFrame.
            query(string): Query to get the Specific data from the given dataframe.
        """

        if 'index' in results.columns:
            results = results.drop(['index'], axis=1)
        d = results.to_sql(table, con=engine, if_exists='replace')


    def scheduler_task(self,data, rows, file_name=""):
        """
        Description:
            This Method is used to Schedule the task for given data.
        Parameters:
            rows(int): number of rows each schedule data have.
            data(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """

        self.StartTime = time.time()

        # assuming.......data's type is pandas framework.......
        global END, START, STOP
        START = 0
        END = START + rows

        if END > len(data):
            END = len(data)
            STOP = 1

        print(data.iloc[START: END])
        START += rows
        try:
            if len(file_name) > 1:
                data.to_csv(file_name)
            else:
                print('')
                print(data)
            status = {'Status': "Success! Task Scheduled"}
        except Exception as e:
            status = {'Status': f"Failed! {str(e)}"}
        self.payasyougo_check(self.scheduler_task,status)


    def schedule_data(self,sec, rows, df,filename):
        """
        Description:
            This Method is used to Schedule the data for given amount of time.
        Parameters:
            sec(int): Seconds for data to schedule again.
            rows(int): number of rows each schedule data have.
            df(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """
        self.StartTime = time.time()
        print("Total rows : ", len(df))
        schedule.every(sec).seconds.do(
            lambda: self.scheduler_task(data=df, rows=rows, file_name=filename))  # file_name is optional

        while True:
            schedule.run_pending()
            if STOP:
                schedule.clear()
                break

        status = {'Status': "Success"}
        self.payasyougo_check(self.schedule_data,status)


    def connectEngine(self,username, password, server, database, tableName, df):
        """
        Description:
            This Method is used to Connect user with Databases using sql Alchemy and upload the dataframe.

        Parameters:
            username(string): database username.
            password(string): password of the database.
            server(string): server address of the database.
            database(string): Database name.
            tableName(string): Name of table you have to upload.
            df(pandas.DataFrame): Dataframe of the table which have to be upload.

        """
        self.StartTime = time.time()
        alchemyEngine = create_engine(
        f"postgresql+psycopg2://"+username+":"+password+"@"+server+"/"+database+", pool_recycle=3600")

        try:
            con = alchemyEngine.connect()
            df.to_sql(
                tableName, con, if_exists='replace')
            con.close()
            print("Data uploaded to table "+tableName)
            status = {'Status':"Success!",
                "Connection String":f'(postgresql+psycopg2://{username}:{password}@{server}/{database})'}

        except Exception as e:
            print (getattr(e, 'message', repr(e)))
            status = {
                'Status':'failed!',
                'error': str(e)
                }
        self.payasyougo_check(self.connectEngine,status)


    def Pagination(self,data, number_of_page=0):

        """
        Description:
            This Method is used to Perform pagination on the responses.
        Parameters:
            data(pandas.DataFrame): Response of in form of dataFrame
            Number_of_page: Number of pages data split into.

        """

        self.StartTime = time.time()
        per_page = 0
        total_page = 0

        if number_of_page > 0:
            per_page = math.ceil(len(data) / number_of_page)
            total_page = number_of_page
        count = 1
        print("Enter page number to show its data. \n")
        while True:
            print(data.iloc[((count - 1) * per_page): (count * per_page)])
            print("Showing page : ", count, " / ", total_page,"\n")
            key = input("Press 'A' or 'D' to navigate or jump to page no: ")
            if (key.isdigit()):
                page = int(key)
                if page > total_page:
                    print('Page doesnot exist')
                else:
                    count = page
            elif(key.lower() in ['a','d']):
                lower = key.lower()
                if lower == 'a':
                    if count > 1:
                        count -= 1
                elif lower == 'd':
                    if count < total_page:
                        count += 1
            else:
                print("Invalid page number")
                
            status = {'Status':"Success!",
                    'Page Number': number_of_page,
                    'data': data}
            self.payasyougo_check(self.Pagination,status)


    def payasyougo_check(self,method,status):
        try:
            pg.measure_execution_time(
                LicenseKey= self.LicenseKey,
                Function = method,
                StartTime = self.StartTime,
                EndTime = time.time(),
                connectername=Connector_name,
                status=status,
                logging=self.logging_options,
                log_connection=self.log_connection)
            self.log_connection = False
        except Exception as e:
            if self.__environment != 'development':
                raise Exception("Server Error - contact help@lyftrondata.com")