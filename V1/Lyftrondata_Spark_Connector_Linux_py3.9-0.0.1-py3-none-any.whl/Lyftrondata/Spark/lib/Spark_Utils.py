from sqlalchemy import create_engine
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import lit
from sqlalchemy.engine.url import URL
import collections
import sys
from connector.utils import get_update_source_schema, get_target_datatypes, create_run_target_alter_statement, get_spark_mapping

def get_dtype(df, columns):
    dataTypes = []
    for colname in columns:
        for name, dtype in df.dtypes:
            if name.lower() == colname.lower():
                dataTypes.append(dtype)
    return dataTypes

def get_dtype_from_metadata(table_metadata, columns):
    dataTypes = []
    for colname in columns:
        for columns in table_metadata:
            if columns['column'] == colname:
                dataTypes.append(columns['datatype'])
    return dataTypes


def compare_column(table_metadata, source_provider_type, target_provider_type, target_provider_name, target_schema_name,
                   target_db_name, provider, license_key, column_list, actual_target_table_name, target, target_db_credentials_without_mapping,
                   spark_df, type_mapping, type_mapping_json, integration_id, source_schema_name, source_table_name, column_casing, target_begin_identifier, target_end_identifier, table_load_action):

    df1 = [columns["column"] for columns in table_metadata if columns['column'].lower() not in [column['column'].lower() for column in column_list]]
    # df1 = df1 + ['Lyft_date', 'Lyft_error', 'Lyft_description']

    df2 = spark_df.schema.names

    result = None
    return_value = None
    cond = True

    is_df1_larger = True if len(df1) > len(df2) else False
    are_equal = True if set(df1) == set(df2) else False
    len_equal = True if len(df1) == len(df2) else False

    if are_equal:
        print("Both are completely equal")
        return_value = spark_df

    # elif len_equal:
    else:
        print("Both are of same length but different columns")
        df1_val = []  # values in target/table metadata but not in data read
        df2_val = []  # values in data read but not in target/table metadata

        for d in df1:
            if d not in df2:
                df1_val.append(d)
        for d in df2:
            if d not in df1:
                df2_val.append(d)

        if len(df1_val):
            datatypes = get_dtype_from_metadata(table_metadata, df1_val)
            for index, datatype in enumerate(datatypes):
                spark_mapping = get_spark_mapping(datatype, target_provider_name, type_mapping, type_mapping_json)
                if not spark_mapping[0]:
                    print(spark_mapping[1])
                class_name = getattr(sys.modules[__name__], spark_mapping[1])
                spark_df = spark_df.withColumn(
                    df1_val[index], lit(None).cast(class_name()))
            return_value = spark_df
            print("Adding missing columns to spark df"+str(df1_val))

        if len(df2_val):
            datatypes = get_dtype(spark_df, df2_val)
            table_metadata = get_update_source_schema(df2_val, datatypes, table_metadata, source_provider_type, provider, type_mapping, type_mapping_json, integration_id, source_schema_name, source_table_name, column_list)
            target_column_types = get_target_datatypes(df2_val, datatypes, target_provider_name, type_mapping, type_mapping_json)
            query = create_run_target_alter_statement(df2_val, target_column_types, target_schema_name, target_db_name,
                                                      actual_target_table_name, target_provider_type, target_provider_name,
                                                      target_db_credentials_without_mapping, license_key, integration_id, column_casing, target_begin_identifier, target_end_identifier)
            print("Adding missing columns to target table: " + query)
            if table_load_action in ['Overwrite Type1 Update', 'Overwrite Type1 Replace', 'Overwrite Type2']:
                query = create_run_target_alter_statement(df2_val, target_column_types, target_schema_name,
                                                          target_db_name,
                                                          f"LYFTSTG_{actual_target_table_name}", target_provider_type,
                                                          target_provider_name,
                                                          target_db_credentials_without_mapping, license_key,
                                                          integration_id, column_casing, target_begin_identifier,
                                                          target_end_identifier)
                print("Adding missing columns to stage target table: " + query)
            return_value = spark_df

    return True , {"spark_df": return_value, "update_table_metadata": table_metadata}


def main(table_metadata, source_provider_type, target_provider_type, target_provider_name, target_schema_name,
         target_db_name, provider, license_key, column_list, actual_target_table_name, target, target_db_credentials_without_mapping,
         df, type_mapping, type_mapping_json, integration_id, source_schema_name, source_table_name, column_casing, target_begin_identifier, target_end_identifier, table_load_action):
    print("CHECKING COLUMNS FROM MISMATCH")
    try:
        response = compare_column(table_metadata, source_provider_type, target_provider_type, target_provider_name, target_schema_name,
                                  target_db_name, provider, license_key, column_list, actual_target_table_name, target, target_db_credentials_without_mapping,
                                  df, type_mapping, type_mapping_json, integration_id, source_schema_name, source_table_name, column_casing, target_begin_identifier, target_end_identifier, table_load_action)
        return True, response[1]
    except Exception as e:
        return False, str(e)

