import random
from asyncore import loop
from cgitb import handler
import glob
from os.path import exists
import re
from sqlite3 import paramstyle
from numpy import source
import pandas as pd
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark.conf import SparkConf
from pyspark.sql.functions import lit
from pyspark.sql.types import *
from datetime import datetime
import os
import sys
import shutil
import time
import math
import importlib
import threading
import copy
from Lyftrondata import payasyougo as pg
from os.path import exists
import sqlalchemy as sa
import pytz
import json as js
import collections
import functools
import operator
import json
from pyspark.sql.functions import col, udf
from pydoc import locate
import Lyftrondata.Spark.lib.Spark_Utils as spu
from Lyftrondata.Lyftrondata_Connector_Handler import Connect as Lyftrondata_Connector_Handler
from integration.utils import add_entry_in_batch_json_file, update_entry_in_batch_json_file, update_parent_batch_in_json_file, update_super_parent_batch, add_update_delta_field_for_api, get_volume


class Connect:
    global Connector_name
    Connector_name = "Lyftrondata_spark_connector"
    LicenseKey = ""
    error = False
    error_message = ""
    th = []
    returnDict = []
    row_dict = []
    read_row_dict = []
    next_page_cursor = ""

    def __init__(self, licenseKey, credsFile=''):
        self.LicenseKey = licenseKey
        self.Connector_name = Connector_name
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = credsFile

    def initialize(self, appName, memory, config):
        """Initialize your spark instant to be used with the flow. The instance
        will work with your provided config dict. SparkSession has been used to
        create a spark working instance.


        Args:
            appName (string): The name you want to give this app. E.g LyftrondataSpark.
            memory(string) : Amount of memory you want Spark to use. For e.g: 2g
            config (dict): See https://spark.apache.org/docs/latest/configuration.html for more.

        Returns:
            object: Your spark session.
        """
        StartTime = time.time()
        spark_conf = SparkConf()
        self.returnDict = []
        # spark_conf.set("spark.executor.memory", memory)

        # Override with any task specific configuration
        for (name, value) in config.items():
            spark_conf.set(name, value)

        spark = SparkSession \
            .builder \
            .appName(appName) \
            .config(conf=spark_conf) \
            .config('spark.executor.memory', memory) \
            .config('spark.jars.packages',
                    'com.vertica.jdbc:vertica-jdbc:10.1.1-0,com.oracle.database.jdbc:ojdbc11:21.5.0.0,net.snowflake:snowflake-jdbc:3.12.17,net.snowflake:spark-snowflake_2.12:2.8.4-spark_3.0,com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.22.0,com.google.cloud.bigdataoss:gcs-connector:hadoop3-1.9.5,com.google.guava:guava:r05') \
            .getOrCreate() if memory else \
            SparkSession \
                .builder \
                .appName(appName) \
                .config(conf=spark_conf) \
                .config('spark.jars.packages',
                        'com.vertica.jdbc:vertica-jdbc:10.1.1-0,com.oracle.database.jdbc:ojdbc11:21.5.0.0,net.snowflake:snowflake-jdbc:3.12.17,net.snowflake:spark-snowflake_2.12:2.8.4-spark_3.0,com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.22.0,com.google.cloud.bigdataoss:gcs-connector:hadoop3-1.9.5,com.google.guava:guava:r05') \
                .getOrCreate()

        EndTime = time.time()
        # pg.measure_execution_time(
        #     self.LicenseKey, self.initialize.__name__, StartTime, EndTime, self.Connector_name)

        return spark

    def dict_mapping(self, jsn, provider, connection_string_mapping):
        if isinstance(connection_string_mapping, dict):
            for m in connection_string_mapping.keys():
                if jsn.get(m) is not None:
                    jsn[connection_string_mapping[m]] = jsn.pop(m)
        return jsn

    def sethadoop(self, spark, config):
        StartTime = time.time()
        conf = spark.sparkContext._jsc.hadoopConfiguration()
        for (name, value) in config.items():
            conf.set(name, value)

        EndTime = time.time()
        # pg.measure_execution_time(
        #     self.LicenseKey, self.sethadoop.__name__, StartTime, EndTime, self.Connector_name)

    def setreturndic(self, table, write_table, row_count, updRow, status, StartTime, EndTime, time_elapsed, threadID,
                     error_message, actual_target_table_name, batch_id):
        return {"source_table_name": table,
                "target_table_name": write_table,
                "row_selected": row_count,
                "row_inserted": math.ceil(updRow),
                "status": status,
                "started_at": StartTime,
                "finished_at": EndTime,
                "time_elapsed": time_elapsed,
                "total_thread_processed": threadID,
                "error_message": error_message,
                "actual_target_table_name": actual_target_table_name,
                "batch_id": batch_id}

    def read(self, spark, source, load, read_format, options, pipeline_batch_id):
        if 'oracle' in source.get('driver', ''):
            del source['database']

        df = spark.read.format(read_format).options('header', 'true') \
            .load(load) if len(load) > 1 else spark.read.format(read_format).options(**source).load()
        self.read_row_dict.append({options['read_table']: df.count()})
        return df

    def upload(self, df, target, write_format, mode, options, pipeline_batch_id, pipeline, table_load_action, source_database_name,
               target_database_name, source_schema_name, target_schema_name, delta_field, delta_value, file_size, pipeline_start_time, plan_subscription, pipeline_start_time_for_calculation):
        try:
            calc = df.count()
            val = df.write.format(write_format) \
                .options(**target) \
                .option('column_mapping', 'name') \
                .option('keep_column_case', 'on') \
                .mode(mode) \
                .options(header=True).save()
            self.row_dict.append(
                {target['dbtable'] if 'dbtable' in target.keys() else target['table']: calc})
            
            volume = get_volume(plan_subscription, pipeline_start_time, datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"), file_size, pipeline_start_time_for_calculation)
            # Update count for pipeline batch
            pipeline_batch_obj = {
                "id": pipeline_batch_id,
                "created_at": pipeline_start_time,
                "updated_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                "status": 'Success',
                "version": "1.0",
                "started_at": pipeline_start_time,
                "finished_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                "next_execution_at": "",
                "row_select": calc,
                "row_insert": calc,
                "total_pipeline_processed": 1,
                "error_message": "",
                "parent_batch_id": options['parent_batch_id'],
                "source_table_name": options["read_table"],
                "target_table_name": options["actual_target_table_name"],
                "is_super_parent": False,
                "runtime_log_file_path": "",
                "created_by_id": options['created_by'],
                "environment_id": options['environment_id'],
                "integration_id": options['integration_id'],
                "project_id": options['project_id'],
                "started_by_id": options['started_by'],
                "tenant_id": options['tenant_id'],
                "updated_by_id": options['updated_by'],
                "pipeline": pipeline,
                "delta_field": delta_field,
                "delta_value": delta_value,
                "row_update": 0,
                "source_database_name": source_database_name,
                "source_schema_name": source_schema_name,
                "target_database_name": target_database_name,
                "target_schema_name": target_schema_name,
                "volume": volume,
                "unit": plan_subscription["rate_unit"] if plan_subscription else ""
            }
            row_insert = calc if table_load_action not in ['Overwrite Type1 Update', 'Overwrite Type1 Replace', 'Overwrite Type2'] else 0
            # Update count for pipeline json
            batch_response = update_entry_in_batch_json_file(options["batch_json_file_path"], pipeline_batch_obj, calc, row_insert, volume, "Success")
            if not batch_response[0]:
                print("=========error in updating entry=======")
                print(batch_response[1])

            # Update count for parent batch json
            batch_response = update_parent_batch_in_json_file(options["batch_json_file_path"], options["parent_batch_id"],
                                                              calc, row_insert, volume)
            if not batch_response[0]:
                print("=========error in updating parent entry=======")
                print(batch_response[1])

            # Update count for super parent batch in db
            batch_response = update_super_parent_batch(options["super_parent_batch_id"], calc, row_insert, volume=volume)
            if not batch_response[0]:
                print("=========error in updating super parent entry=======")
                print(batch_response[1])

            print("=========uploaded df=========")

            return True
        except Exception as upload_err:
            print("======here in exception of upload=============")
            print(upload_err)
            print("========================")
            pipeline_batch_obj = {
                "id": pipeline_batch_id,
                "created_at": pipeline_start_time,
                "updated_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                "status": 'Failed',
                "version": "1.0",
                "started_at": pipeline_start_time,
                "finished_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                "next_execution_at": "",
                "row_select": calc,
                "row_insert": 0,
                "total_pipeline_processed": 1,
                "error_message": json.dumps(str(upload_err)),
                "parent_batch_id": options['parent_batch_id'],
                "source_table_name": options["read_table"],
                "target_table_name": options["actual_target_table_name"],
                "is_super_parent": False,
                "runtime_log_file_path": "",
                "created_by_id": options['created_by'],
                "environment_id": options['environment_id'],
                "integration_id": options['integration_id'],
                "project_id": options['project_id'],
                "started_by_id": options['started_by'],
                "tenant_id": options['tenant_id'],
                "updated_by_id": options['updated_by'],
                "pipeline": pipeline,
                "delta_field": delta_field,
                "delta_value": delta_value,
                "row_update": 0,
                "source_database_name": source_database_name,
                "source_schema_name": source_schema_name,
                "target_database_name": target_database_name,
                "target_schema_name": target_schema_name,
                "volume": 0,
                "unit": plan_subscription["rate_unit"] if plan_subscription else ""
            }
            # Update count for pipeline json
            batch_response = update_entry_in_batch_json_file(options["batch_json_file_path"], pipeline_batch_obj,
                                                             calc, 0, 0, "Failed", error_message=str(upload_err))
            if not batch_response[0]:
                print(batch_response[1])

            # Update count for parent batch json
            batch_response = update_parent_batch_in_json_file(options["batch_json_file_path"],
                                                              options["parent_batch_id"],
                                                              calc, 0, 0)
            if not batch_response[0]:
                print(batch_response[1])

            # Update count for super parent batch in db
            batch_response = update_super_parent_batch(options["super_parent_batch_id"], calc, 0, volumne=0)
            if not batch_response[0]:
                print(batch_response[1])
            return False


    def equivalent_type(self, f):
        if f == 'datetime64[ns]':
            return TimestampType()
        elif f == 'int64':
            return LongType()
        elif f == 'int32':
            return IntegerType()
        elif f == 'float64':
            return FloatType()
        else:
            return StringType()

    def define_structure(self, string, format_type):
        try:
            typo = self.equivalent_type(format_type)
        except:
            typo = StringType()
        EndTime = time.time()

        return StructField(string, typo)

    def pandas_to_spark(self, pandas_df, spark):
        """convert pandas dataframe to spark dataframe

        Args:
            pandas_df (pandas.Dataframe): pandas dataframe to convert
            spark (Object): Spark session object

        Returns:
            Spark.DataFrame: Spark dataframe
        """
        StartTime = time.time()
        columns = list(pandas_df.columns)
        types = list(pandas_df.dtypes)
        struct_list = []
        for column, typo in zip(columns, types):
            struct_list.append(self.define_structure(column, typo))
        p_schema = StructType(struct_list)
        EndTime = time.time()
        # pg.measure_execution_time(
        #    self.LicenseKey, self.pandas_to_spark.__name__, StartTime, EndTime, self.Connector_name)

        return spark.createDataFrame(pandas_df, p_schema)

    def fillNa(self, metadata, table, df):
        subset = []
        for c in metadata:
            col_list = []
            col_list.append(c["column"])
            if 'default_value' in c.keys():
                js = {"val": c['default_value'], "col": col_list}
                subset.append(js)
        for j in subset:
            df = df.na.fill(j["val"], subset=j["col"])
        return df

    def read_by_page(self, provider, source_db_credentials, license_key, actual_target_table_name, subdomain,
                     api_request_limit, from_page, to_page, spark, table_metadata, column_list, source_schema_name, integration_id,
                     batch_id, source_table_name, column_casing, delta_value, is_incremental):

        handler_params = {
            'class_import': provider,
            'command': 'initialize',
            'variables': source_db_credentials
        }

        handler_obj = Lyftrondata_Connector_Handler(license_key)
        provider_engine_obj = handler_obj.runcommand(handler_params)
        if not provider_engine_obj[0]:
            print(provider_engine_obj[1])

        fetch_variables = {
            # 'token': connector_token,
            'table': actual_target_table_name
        }
        if subdomain:
            fetch_variables["subdomain"] = subdomain
        if api_request_limit:
            fetch_variables["api_request_limit"] = api_request_limit
        if from_page:
            fetch_variables["from_page"] = from_page
        if to_page:
            fetch_variables["to_page"] = to_page
        if self.next_page_cursor and provider == "Gorgias":
            fetch_variables["cursor"] = self.next_page_cursor
        if source_schema_name:
            fetch_variables['parameter'] = source_schema_name

        FETCH_DATA = {
            'class_import': provider,
            'command': 'fetchDataFromAPI',
            'variables': fetch_variables,
            'provider_engine_obj': provider_engine_obj[1]
        }
        json = handler_obj.runcommand(FETCH_DATA)
        JSON_PARSE = {
            'class_import': provider,
            'command': 'json_parse',
            'variables': {
                'jsn': json,
                'main_table_name': actual_target_table_name
            }
        }
        list_df = {}
        list_df = handler_obj.runcommand(JSON_PARSE)
        df_result = None
        for df_name, df in list_df.items():
            DATA_TO_TABLE = {
                'class_import': provider,
                'command': 'dataToTable',
                'variables': {
                    'results': df,
                    'table': df_name
                }
            }
            handler_obj.runcommand(DATA_TO_TABLE)
            ENGINE = {
                'class_import': provider,
                'command': 'import_engine',
                'variables': {
                }
            }
            eng = handler_obj.runcommand(ENGINE)
            r = eng.execute("select * from " + df_name)
            df_result = pd.DataFrame(r, index=None, columns=r.keys())
            del df_result['index']
            if provider == "Gorgias":
                if "lyft_error" in df_result:
                    df_result = df_result[~(df_result.lyft_error.notnull())]
                    del df_result["lyft_error"]
                if "next_cursor" in df_result:
                    if is_incremental:
                        self.next_page_cursor = df_result.iloc[-1]["next_cursor"] if df_result.iloc[-1]["next_cursor"] else df_result.iloc[-1]["cursor"]
                    else:
                        self.next_page_cursor = df_result.iloc[-1]["next_cursor"]
                    if is_incremental:
                        from_page =  from_page + (len(df_result) // 30)
                        delta_response = add_update_delta_field_for_api(self.next_page_cursor, source_schema_name, integration_id, batch_id, source_table_name, from_page, column_casing, "page")
                        if not delta_response[0]:
                            print(delta_response[1])
                    del df_result["cursor"]
                    del df_result["next_cursor"]
            df_result.columns = df_result.columns.str.replace(' ', '_')
            df = self.pandas_to_spark(df_result, spark)
            self.read_row_dict.append({actual_target_table_name: df.count()})
        return df

    def write_by_page(self, provider, column_list, df, batch_size, spark, parquet_folder, target, write_format,
                      write_mode,
                      threads, count, table_metadata, source_provider_type, target_provider_type, target_provider_name,
                      target_schema_name, target_db_name, license_key, actual_target_table_name,
                      target_db_credentials_without_mapping, type_mapping, type_mapping_json, integration_id, source_schema_name,
                      source_table_name, options, pipeline_batch_id, column_casing, pipeline, target_begin_identifier, target_end_identifier,
                      table_load_action, source_database_name, target_database_name, delta_field, delta_value, pipeline_start_time, plan_subscription):
        df.printSchema()
        castquery = []
        response = spu.main(table_metadata, source_provider_type, target_provider_type, target_provider_name,
                            target_schema_name, target_db_name, provider, license_key, column_list,
                            actual_target_table_name,
                            target, target_db_credentials_without_mapping, df, type_mapping, type_mapping_json, integration_id,
                            source_schema_name, source_table_name, column_casing, target_begin_identifier, target_end_identifier, table_load_action)
        if not response[0]:
            print(response[1])
        else:
            has_custom_lyftron_columns = False
            df = response[1]['spark_df']
            print("After comparing dataframes")
            df.printSchema()
            table_metadata = response[1]['update_table_metadata']
            copied_table_metdata = copy.deepcopy(table_metadata)
            for columns in copied_table_metdata:
                if columns['column'].lower() in [column['column'].lower() for column in column_list]:
                    has_custom_lyftron_columns = True
            if not has_custom_lyftron_columns:
                copied_table_metdata = copied_table_metdata + column_list
            for c in copied_table_metdata:
                name = c['column']
                if name.lower() in [column['column'].lower() for column in column_list]:
                    df = df.withColumn(c['column'], lit(c['value'] if 'value' in c else "").cast((c["spark_short_datatype"])))
                # else:
                #     castquery.append(f"cast({name} as {c['spark_short_datatype']}) {name} ")
            for c in copied_table_metdata:
                name = c['column']
                castquery.append(f"cast({name} as {c['spark_short_datatype']}) {name} ")
            df2 = df.selectExpr(castquery)
            df = df2
            df2 = None
            print("Filling NAN values")
            df = self.fillNa(table_metadata, actual_target_table_name, df)
            print("After Casting")
            df.printSchema()
            loop = df.count() / batch_size
            loop = math.ceil(loop)
            if not loop:
                loop = 1
            df.repartition(loop).write.parquet(parquet_folder)

            for file in glob.glob(parquet_folder + '/*.parquet'):
                count = count + 1
                print(file)
                file_size = float("{:0.2f}".format(os.stat(file).st_size / (1024 * 1024)))
                print("size of file", file_size)
                print("Running batch no: " + str(count))
                pipeline_start_time_for_calculation = ''
                if plan_subscription and plan_subscription['rate_unit'].lower() == 'time' and count > 1:
                    pipeline_start_time_for_calculation = datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
                df = spark.read.parquet(file)
                t1 = threading.Thread(target=self.upload, args=(
                    df, target, write_format, write_mode, options, pipeline_batch_id, pipeline, table_load_action, source_database_name, target_database_name,
                    source_schema_name, target_schema_name, delta_field, delta_value, file_size, pipeline_start_time, plan_subscription, pipeline_start_time_for_calculation))
                threads.append(t1)
                t1.start()
            for t in threads:
                t.join()

            shutil.rmtree(parquet_folder)
            return table_metadata

    def simultaneous_load(self, spark, JSON, parquet_folder, source, options, target, batch_size, query, load,
                          source_provider_type, page_number, subdomain, api_request_limit, provider, target_provider_type,
                          target_provider_name, target_schema_name, target_db_name, license_key,
                          table_metadata, read_format, write_format, write_mode, batch_id,
                          actual_target_table_name, column_list, source_db_credentials,
                          target_db_credentials_without_mapping, page_limit, type_mapping, type_mapping_json, integration_id,
                          source_schema_name, source_table_name,  pipeline_batch_id, column_casing, pipeline, target_begin_identifier,
                          target_end_identifier, table_load_action, source_database_name, target_database_name, delta_field, delta_value,
                          from_page, is_incremental, pipeline_start_time, plan_subscription):

        StartTime = time.time()
        threads = []
        # query = ""
        load = ""
        count = 0
        list_df = {}
        # from_page = 0
        to_page = 0
        max_pages = 0
        # page_limit = 10

        # if len(query) > 1:
        if source_provider_type == "Python":
            if page_limit:
                if actual_target_table_name not in ("messages"):
                    handler_params = {
                        'class_import': provider,
                        'command': 'initialize',
                        'variables': source_db_credentials
                    }

                    handler_obj = Lyftrondata_Connector_Handler(license_key)
                    provider_engine_obj = handler_obj.runcommand(handler_params)
                    if not provider_engine_obj[0]:
                        raise Exception(provider_engine_obj[1])

                    query_params = {
                        'class_import': provider,
                        'command': 'execute_query',
                        'query': 'select * from sys.pages',
                        'provider_engine_obj': provider_engine_obj[1]
                    }
                    query_response = handler_obj.runcommand(query_params)
                    if not query_response[0]:
                        raise Exception(query_response[1])
                    df = query_response[1]
                    actual_target_table_name_without_vw = actual_target_table_name
                    if "vw_" in actual_target_table_name:
                        actual_target_table_name_without_vw = actual_target_table_name.replace("vw_", "")
                        # if "ticket" in actual_target_table_name_without_vw:
                        #     actual_target_table_name_without_vw = "tickets"
                    max_pages = df.loc[df['Table'] == actual_target_table_name_without_vw, 'TotalPages'].iloc[0]
                counter = 1
                while True:
                    if to_page > int(max_pages) and provider != 'Gorgias':
                        break
                    if not self.next_page_cursor and counter > 1:
                        break
                    if from_page and counter <= 1 and is_incremental:
                        to_page = from_page - 1
                        self.next_page_cursor = delta_value
                    from_page = to_page + 1
                    to_page = to_page + page_limit

                    df = self.read_by_page(provider, source_db_credentials, license_key, actual_target_table_name,
                                           subdomain, api_request_limit, from_page, to_page, spark, table_metadata,
                                           column_list, source_schema_name, integration_id, batch_id, source_table_name, column_casing, delta_value, is_incremental)
                    if not df.rdd.isEmpty():
                        updated_table_metadata = self.write_by_page(provider, column_list, df, batch_size, spark,
                                                                    parquet_folder, target, write_format,
                                                                    write_mode, threads, count, table_metadata,
                                                                    source_provider_type, target_provider_type,
                                                                    target_provider_name, target_schema_name,
                                                                    target_db_name, license_key,
                                                                    actual_target_table_name,
                                                                    target_db_credentials_without_mapping, type_mapping, type_mapping_json, integration_id,
                                                                    source_schema_name, source_table_name,
                                                                    options, pipeline_batch_id, column_casing, pipeline, target_begin_identifier, target_end_identifier,
                                                                    table_load_action, source_database_name, target_database_name, delta_field, delta_value, pipeline_start_time, plan_subscription)
                        table_metadata = updated_table_metadata
                    counter += 1

            else:
                df = self.read_by_page(provider, source_db_credentials, license_key, actual_target_table_name,
                                       subdomain, api_request_limit, None, None, spark, table_metadata, column_list, source_schema_name,
                                       integration_id, batch_id, source_table_name, column_casing, delta_value, is_incremental)
                updated_table_metadata = self.write_by_page(provider, column_list, df, batch_size, spark,
                                                            parquet_folder,
                                                            target, write_format, write_mode,
                                                            threads, count, table_metadata, target_provider_type,
                                                            source_provider_type, target_provider_name,
                                                            target_schema_name,
                                                            target_db_name, license_key, actual_target_table_name,
                                                            target_db_credentials_without_mapping, type_mapping,
                                                            type_mapping_json, integration_id, source_schema_name,
                                                            source_table_name, options, pipeline_batch_id,
                                                            column_casing, pipeline, target_begin_identifier,
                                                            target_end_identifier, table_load_action,
                                                            source_database_name, target_database_name, delta_field,
                                                            delta_value, pipeline_start_time, plan_subscription)
                table_metadata = updated_table_metadata
        else:
            df = self.read(spark, source, load, read_format, options, pipeline_batch_id)

            updated_table_metadata = self.write_by_page(provider, column_list, df, batch_size, spark, parquet_folder,
                                                        target, write_format, write_mode,
                                                        threads, count, table_metadata, target_provider_type,
                                                        source_provider_type, target_provider_name, target_schema_name,
                                                        target_db_name, license_key, actual_target_table_name,
                                                        target_db_credentials_without_mapping, type_mapping, type_mapping_json, integration_id, source_schema_name,
                                                        source_table_name, options, pipeline_batch_id, column_casing, pipeline, target_begin_identifier, target_end_identifier,
                                                        table_load_action, source_database_name, target_database_name, delta_field, delta_value, pipeline_start_time, plan_subscription)
            table_metadata = updated_table_metadata

        # # Perform truncate and insert action on backup table
        # target_table_full_name = target["table"].split(".")
        # if 'LYFTSTG' in target_table_full_name[2]:
        #     target_table_full_name[2] = target_table_full_name[2].split("LYFTSTG_")[1]
        # bakcup_table_name = f"{target_table_full_name[1]}.CLONE_{target_table_full_name[2]}"
        #
        # print(f"=========Performing truncate action on backup table {bakcup_table_name}========")
        # target["dataset"] = "Lyftrondata"
        # with open(target["serviceaccountjson"]) as file:
        #     target["serviceaccountjson"] = json.loads(file.read())
        # handler_params = {
        #     'class_import': "BigQuery",
        #     'command': 'initialize',
        #     'variables': target
        # }
        # handler_obj = Lyftrondata_Connector_Handler(license_key)
        # provider_engine_obj = handler_obj.runcommand(handler_params)
        # target.pop("dataset")
        # if not provider_engine_obj[0]:
        #     print(f"Error while initializing target engine object {provider_engine_obj[1]}")
        # else:
        #     count_query = f"SELECT COUNT(*) FROM {target_table_full_name[1]}.{target_table_full_name[2]}"
        #     # truncate_backup_table_query = f"truncate table {bakcup_table_name}"
        #     handler_params = {
        #         'class_import': target_provider_name,
        #         'command': 'execute_query',
        #         'query': count_query,
        #         'provider_engine_obj': provider_engine_obj[1]
        #     }
        #     count_query_response = handler_obj.runcommand(handler_params)
        #     if not count_query_response[0]:
        #         print(f"Error while executing count query on clone table: {count_query_response[1]}")
        #     else:
        #         if not count_query_response[1].empty:
        #             truncate_backup_table_query = f"CREATE OR REPLACE TABLE {bakcup_table_name} CLONE {target_table_full_name[1]}.{target_table_full_name[2]}"
        #             # truncate_backup_table_query = f"truncate table {bakcup_table_name}"
        #             handler_params = {
        #                 'class_import': target_provider_name,
        #                 'command': 'execute_query',
        #                 'query': truncate_backup_table_query,
        #                 'provider_engine_obj': provider_engine_obj[1]
        #             }
        #             truncate_query_response = handler_obj.runcommand(handler_params)
        #             if not truncate_query_response[0]:
        #                 print(f"Error while executing Create/Replace query on Clone table: {truncate_query_response[1]}")
        #     # else:
            #     print(f"=========Performing insert action on backup table {bakcup_table_name}========")
            #     insert_backup_table_query = f"insert into {bakcup_table_name} select * from {target_table_full_name[1]}.{target_table_full_name[2]}"
            #     handler_params = {
            #         'class_import': target_provider_name,
            #         'command': 'execute_query',
            #         'query': insert_backup_table_query,
            #         'provider_engine_obj': provider_engine_obj[1]
            #     }
            #     insert_query_response = handler_obj.runcommand(handler_params)
            #     if not insert_query_response[0]:
            #         print(f"Error while executing insert query on backup table: {insert_query_response[1]}")

    def run_load(self, spark, JSON):

        StartTime = datetime.now(pytz.utc)
        strt = time.time()
        sets = len(JSON)
        self.returnDict = []
        read_tables = []
        tables = []
        th = []
        exception = ""
        total = []
        continueonerror = None

        print('Found {COUNT} number of tables in JSON. Making equivalent threads.'.format(
            COUNT=sets))

        try:
            for k in JSON:
                source = k['source']
                target = k['target']
                options = k['options']
                source_table_name = options["read_table"]
                read_tables.append(options["read_table"])
                tables.append(target["table"]) if "table" in target.keys(
                ) else tables.append(target["dbtable"])

                # get this from batch size param
                batch_size = options['batch_size']
                query = source['query']
                load = options.get('load', '')
                source_provider_type = options.get('source_provider_type', '')
                page_number = options.get('page_number', '')
                subdomain = options.get('subdomain', '')
                api_request_limit = options.get('api_request_limit', '')
                provider = options.get('provider', '')
                target_provider_type = options.get('target_provider_type', '')
                target_provider_name = options.get('target_provider_name', '')
                target_schema_name = options.get('target_schema_name', '')
                target_db_credentials_without_mapping = options.get('target_db_credentials_without_mapping', '')
                target_db_name = options.get('target_db_name', '')
                license_key = options['license_key']
                table_metadata = options.get('table_metadata', '')
                read_format = options['read_format']
                write_format = options['write_format']
                write_mode = options['write_mode']
                actual_target_table_name = options.get(
                    'actual_target_table_name', '')
                column_list = options['column_list']
                parquet_folder = options['parquet_folder']
                source_db_credentials = options['source_db_credentials']
                page_limit = options['page_limit']
                isMultiThreading = options["isMultiThreading"]
                type_mapping = options.get('type_mapping', '')
                type_mapping_json = options.get('type_mapping_json', '')
                integration_id = options.get('integration_id', '')
                source_schema_name = options.get('source_schema_name', '')
                column_casing = options.get('column_casing', '')
                target_begin_identifier = options.get('target_begin_identifier', '')
                target_end_identifier = options.get('target_end_identifier', '')
                pipeline = f"{options.get('pipeline', '')}"
                table_load_action = options["table_load_action"]
                source_database_name = options["source_database_name"]
                target_database_name = options["target_database_name"]
                delta_field = options["delta_field"]
                delta_value = options["delta_value"]
                source_connection_string_mapping = options.get('source_connection_string_mapping', {})
                target_connection_string_mapping = options.get('target_connection_string_mapping', {})
                from_page = options.get("from_page", 0)
                is_incremental = options.get('is_incremental', False)
                batch_id = ""
                continueonerror = options['continueonerror']
                plan_subscription = options['plan_subscription']
                for opt in options['column_list']:
                    if opt['column'] == 'Lyft_BatchId':
                        batch_id = opt['value']
                        break

                source = self.dict_mapping(source, read_format, source_connection_string_mapping)
                target = self.dict_mapping(target, write_format, target_connection_string_mapping)

                # Add in_progess status for pipeine batch in json.
                date_string = datetime.now(pytz.utc).strftime("%Y%m%d%H%M%S%f")
                random_number = random.randint(0, 10000)
                pipeline_batch_id = f"{options['integration_id']}_{date_string}_{random_number}"
                pipeline_start_time = datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")
                pipeline_batch_obj = {
                    "id": pipeline_batch_id,
                    "created_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "updated_at": datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "status": 'In Progress',
                    "version": "1.0",
                    "started_at": pipeline_start_time,
                    "finished_at": "",
                    "next_execution_at": "",
                    "row_select": 0,
                    "row_insert": 0,
                    "total_pipeline_processed": 1,
                    "error_message": "",
                    "parent_batch_id": options['parent_batch_id'],
                    "source_table_name": options["read_table"],
                    "target_table_name": options["actual_target_table_name"],
                    "is_super_parent": False,
                    "runtime_log_file_path": "",
                    "created_by_id": options['created_by'],
                    "environment_id": options['environment_id'],
                    "integration_id": options['integration_id'],
                    "project_id": options['project_id'],
                    "started_by_id": options['started_by'],
                    "tenant_id": options['tenant_id'],
                    "updated_by_id": options['updated_by'],
                    "pipeline": pipeline,
                    "delta_field": delta_field,
                    "delta_value": delta_value,
                    "row_update": 0,
                    "source_database_name": source_database_name,
                    "source_schema_name": source_schema_name,
                    "target_database_name": target_database_name,
                    "target_schema_name": target_schema_name,
                    "volume": 0,
                    "unit": plan_subscription["rate_unit"] if plan_subscription else ""
                }
                # Add sub batch id value in lyftron columns
                column_list[1]['value'] = pipeline_batch_id

                batch_response = add_entry_in_batch_json_file(options["batch_json_file_path"], pipeline_batch_obj)
                if not batch_response[0]:
                    print(batch_response[1])

                if isMultiThreading:
                    th.append(threading.Thread(target=self.simultaneous_load, args=(
                        spark, k, parquet_folder, source, options, target, batch_size, query, load,
                        source_provider_type,
                        page_number, subdomain, api_request_limit, provider, target_provider_type, target_provider_name,
                        target_schema_name, target_db_name, license_key,
                        table_metadata, read_format, write_format, write_mode, batch_id,
                        actual_target_table_name, column_list, source_db_credentials,
                        target_db_credentials_without_mapping, page_limit, type_mapping, type_mapping_json, integration_id, source_schema_name, source_table_name,
                        pipeline_batch_id, column_casing, pipeline, target_begin_identifier, target_end_identifier, table_load_action, source_database_name,
                        target_database_name, delta_field, delta_value, from_page, is_incremental, pipeline_start_time, plan_subscription)))
                else:
                    self.simultaneous_load(spark, k, parquet_folder, source, options, target, batch_size, query, load,
                                           source_provider_type,
                                           page_number, subdomain, api_request_limit, provider, target_provider_type,
                                           target_provider_name, target_schema_name, target_db_name, license_key,
                                           table_metadata, read_format, write_format, write_mode, batch_id,
                                           actual_target_table_name, column_list, source_db_credentials,
                                           target_db_credentials_without_mapping, page_limit, type_mapping, type_mapping_json, integration_id,
                                           source_schema_name, source_table_name, pipeline_batch_id, column_casing, pipeline, target_begin_identifier, target_end_identifier,
                                           table_load_action, source_database_name, target_database_name, delta_field, delta_value, from_page, is_incremental, pipeline_start_time, plan_subscription)
            if isMultiThreading:
                for t in th:
                    t.start()
                for t in th:
                    t.join()

        except Exception as e:
            print("===========================")
            print("here in exception of run_load")
            print("===========================")
            print(e)
            exception = str(e)
            if continueonerror == False:
                total = dict(functools.reduce(operator.add,
                                              map(collections.Counter, self.row_dict))) \
                    if len(self.row_dict) > len(read_tables) \
                    else self.row_dict
                for index, t in enumerate(tables):
                    if type(total) == dict:
                        val = total[t] if total else 0
                    else:
                        val = [element[t]
                               for element in total if t in element][0] if total else 0

                    self.returnDict.append(self.setreturndic(read_tables[tables.index(t)],
                                                             t, self.read_row_dict[tables.index(t)][
                                                                 list(self.read_row_dict[tables.index(t)].keys())[0]]
                                                             if self.read_row_dict else 0,
                                                             val, "Failed", StartTime, EndTime, time_elapsed, None,
                                                             exception, t.split(".")[-1], batch_id))
                # pg.measure_execution_time(
                #     self.LicenseKey, self.run_load.__name__, StartTime, EndTime, self.Connector_name)
                return self.returnDict

        finally:
            EndTime = datetime.now(pytz.utc)
            end = time.time()
            time_elapsed = (EndTime - StartTime).total_seconds()

            total = dict(functools.reduce(operator.add,
                                          map(collections.Counter, self.row_dict))) \
                if len(self.row_dict) > len(read_tables) \
                else self.row_dict
            for index, t in enumerate(tables):
                if type(total) == dict:
                    val = total[t] if total else 0
                else:
                    val = [element[t]
                           for element in total if t in element][0] if total else 0
                self.returnDict.append(self.setreturndic(read_tables[tables.index(t)],
                                                         t, self.read_row_dict[tables.index(t)][
                                                             list(self.read_row_dict[tables.index(t)].keys())[0]]
                                                         if self.read_row_dict else 0, val,
                                                         "Success", StartTime, EndTime, time_elapsed, None, exception,
                                                         t.split(".")[-1], batch_id))
        # pg.measure_execution_time(
        #     self.LicenseKey, self.run_load.__name__, strt, EndTime, self.Connector_name)

        return self.returnDict
