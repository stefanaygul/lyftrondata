MAPPING = {
    "personaltoken":{

        },

    "oauth2" : {
    },
    
}