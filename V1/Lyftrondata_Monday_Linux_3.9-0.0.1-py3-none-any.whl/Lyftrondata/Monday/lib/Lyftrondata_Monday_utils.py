import requests
from requests.auth import HTTPBasicAuth
import time
import webbrowser
import json
import sys
from collections import OrderedDict
from collections import abc
TimeStringFormat = "%a %b %d %H:%M:%S %Y"

class Lyftrondata_authHandler:
    
    def __init__(self):
        pass
        
    def url_maker(self,url,parameters):
        from urllib.parse import urlencode
        
        URL = url+"?"+urlencode(parameters)
        
        return URL
    
    def OAuthentication2(self,auth_url=None,
                        token_url=None,
                        auth_params=None,
                        auth_headers=None,
                        token_params=None,
                        token_headers=None,
                        token_data=None
        ):
        
        """This Method is used when the Authorization 2.0 is required.
            passing the required parameters and headers will lead you to the Authorization page where you have to authorization you app. 
            after authorization you have to copy the code from the redirected page url and paste it into
            Authorization message Box which will lead you toward the final json response contain access token or other parameters depends on API response.

        Args:
            auth_url (string, required): Authorization url of the App. Defaults to None.
            token_url (string, required): Token url of the App. Defaults to None.
            auth_params (dict, optional): Authorization Required parameters. Defaults to None.
            auth_headers (dict, optional): Authorization Required Headers. Defaults to None.
            token_params (dict, optional): Token Url Required parameters. Defaults to None.
            token_headers (dict, optional): Token Url  Required parameters. Defaults to None.

        Returns:
            dict/json: response from the successfull Authorization contains token or other parameters depend on API
        """
        if token_params['grant_type'] == 'authorization_code':          
            auth_resp = self.url_maker(auth_url,auth_params)    
            webbrowser.open(auth_resp)
            
            from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit
            
            class App(QWidget):
                # don't Override or change the parameters in this class
                
                """ This Class if used for gui purpose to over come CLI based inputs.
                Args:
                    QWidget : Message box which takes code or access_token for input
                """
                def __init__(self):
                    super().__init__()
                    self.title = 'Authorization Form'
                    self.left = 10
                    self.top = 10
                    self.width = 640
                    self.height = 100
                    self.initUI()
                
                def initUI(self):
                    self.setWindowTitle(self.title)
                    self.setGeometry(self.left,self.top, self.width, self.height)
                    self.geturl()
                    self.show()
                    
                def geturl(self):
                    code, okPressed = QInputDialog.getText(self, "Enter code/Access Token","URL:", QLineEdit.Normal, "")
                    if okPressed and code != '':
                        token_params['code'] = code
            
            app = QApplication(sys.argv)
            msg = App()
        else:   
            pass
            
        token_resp = requests.post(
                                    url=token_url,
                                    params=token_params,
                                    headers=token_headers,
                                    data=token_data
                                )
        print(token_resp.url)
        token_json = token_resp.json()
        
        token_json['fetched_at'] = time.asctime(time.localtime(time.time()))
        
        if 'access_token' in token_json:

            return token_json
        else:
            print("invalid request",token_json)

    def basicAuth(self,url,
                username,
                password,
                basicauth_params=None,
                basicauth_headers=None
        ):
        """ This Method is call when the API follows the Basic Authorization process

        Args:
            url (string): url where your Basic auth is required
            username (string): username/email given by API 
            password (string): password/client_secret given by API
            basicauth_params (dict, optional): other Required parameters. Defaults to None.
            basicauth_headers (dict, optional): other Required Headers. Defaults to None.

        Returns:
            dict: contains response contains information depends on API
        """
        access_token = requests.post(   
                                    url,
                                    headers=basicauth_headers,
                                    params=basicauth_params,
                                    auth=HTTPBasicAuth(username,password)
                                    ).json()
        
        access_token['fetched_at'] = time.asctime(time.localtime(time.time()))
        return access_token

    def refreshToken(self,token_json,
                    refreshtoken_url,
                    refreshtoken_params=None,
                    refreshtoken_headers=None,
                    client_id=None,
                    client_secret=None
                    
        ):
        """[summary]

        Args:
            token_json (dict): token file which have to be override. eg. file which generated at after of authentication 'token.json'
            refreshtoken_url (string): refresh token url provided by API
            refreshtoken_params (dict, optional): other required parameters if needed . Defaults to None.
            refreshtoken_headers (dict, optional): other required headers if needed. Defaults to None.
            client_id (string, optional): client_id/username/email if provied by API for refresh token. Defaults to None.
            client_secret (string, optional): client_secret/password if provied by API for refresh token. Defaults to None.

        Returns:
            dict: contains the updated token with new expiretime , fetched time & other parameters provied by API
        """
        if client_id == None and client_secret == None:
            basicAuthentication =None
        else:
            basicAuthentication = HTTPBasicAuth(client_id,client_secret)
                    
        token_response = requests.post(
                                        refreshtoken_url,
                                        params=refreshtoken_params,
                                        auth=basicAuthentication
                                    ).json()
        
        token_response['fetched_at'] = time.asctime(time.localtime(time.time()))
        token_response['refresh_token'] = refreshtoken_params['refresh_token']
        
        with open(token_json,"w") as f:
                json.dump(token_response,f)
                
        return token_response
        
    def check_expire_time(self,expired_time_key,fetched_time_key):
        
        """ The Method is used to check the expiry time of token with comparing to current time.
        
        Args:
            expired_time_key (int): expired time of the token given by the response must be converted to int before passing to this function.
            fetched_time_key (string): fetched time of the token written under token response as 'fetched_at'

        Returns:
            boolean: if time is expired return 'True' else return 'False'
        """
        
        fetched_time = time.mktime(time.strptime(fetched_time_key,TimeStringFormat))
        time_now = time.time()
        time_elapsed = time_now - fetched_time
        print(f'Token Validity Time : {expired_time_key} seconds')
        print(f'Total Time Elapsed: {time_elapsed} seconds')
        return True if time_elapsed >= expired_time_key else False




class Lyftrondata_Monday_Parser:
    """ This Class is used to parse the response from the API and return the required data.
    
    Args:
        response (dict): response from the API
    
    Returns:
        dict: contains the required data
    """
    
    empty = dict()
    
    def __init__(self,table,jsn):
        self.table = table
        self.jsn = jsn
                  
    def parse(self):
        resp = self.jsn
        
        # ViewKeys is used to get the keys of the response which is required to be parsed
        viewskey = {
          'activity_log_view':['data','boards', '', 'activity_logs'],
            "board_view":['data', 'boards', '', "views"],
            "board_views_view":['data', 'boards', '',"views"],
            "column_view":['data', 'boards','', "columns"],
            "group_view":['data', 'boards', "","groups"]
        }
        
        # EndpointKey is used to get the keys of the response which is required to get Id of the response
        DatainKey = {
            'activity_logs':['data', 'boards', '', 'activity_logs'],
            'boards': ['data', 'boards'],
            "board_views":["data","boards", "" ,"views"],
            'columns': ['data', 'boards',"", "columns"],
            "column_values": ['data', 'boards'],
            "complexity": ['data', 'boards'],
            "workspaces": ['data', 'boards','','workspace'],
            "tags": ['data', 'tags'],
            "teams": ['data', 'teams'],
            "updates":['data','updates'],
            "groups":['data', 'boards', "", "groups"],
            "me":['data', 'me'],
            "items":['data', 'items'],
            "users":['data', 'users'],
            "subitems":['data', 'boards', "", "subitems"],
            "files":['data', 'assets'],
            "item_view":['data', 'items'],
            "item_by_column":[],
            "item_by_columns":[]
        }

        if self.table.lower() in viewskey.keys():
            global viewkey
            viewkey = viewskey.get(self.table.lower(), "")
            resp = self.views_parser(self.jsn)
            
        elif self.table.lower() in DatainKey.keys():
            global endpoint_key
            endpoint_key = DatainKey.get(self.table.lower(), "")
            if type(endpoint_key) == list:
                for l in endpoint_key: 
                    if isinstance(self.jsn, list) and endpoint_key.index(l) < len(endpoint_key):
                        if bool(self.jsn):
                            self.jsn = self.jsn[0]
                        else: 
                            self.jsn = self.jsn
                    else:
                        self.jsn = self.jsn.get(l, {})
                resp = self.Endpoint_parse(self.jsn)
            else:
                try:    
                    resp = self.Endpoint_parse(self.jsn[endpoint_key])
                except:
                    resp = self.Endpoint_parse(self.jsn) # if endpoint_key is not present in the response

        else:
            resp = self.Endpoint_parse(self.jsn)

        return resp
    
    def views_parser(self,jsn):
        parsed = list()
        
        for i in jsn:
            if type(i) == list:
                for j in i:
                    if viewkey == "":
                        res = self.Endpoint_parse(j)
                    
                    elif isinstance(viewkey,list):
                        for l in viewkey: 
                            if isinstance(j, list) and viewkey.index(l) < len(viewkey):
                                j = j[0]
                            else:
                                j = j.get(l, {})

                        res = self.Endpoint_parse(j)
                    else:
                        res = self.Endpoint_parse(j[viewkey])
                         
                    for k in res:
                            parsed.append(k)
            else:
                if viewkey == "":
                    res = self.Endpoint_parse(i)
                
                elif isinstance(viewkey,list):
                    for l in viewkey: 
                        if isinstance(i, list) and viewkey.index(l) < len(viewkey):
                            i = i[0]
                        else:
                            i = i.get(l, {})
                    res = self.Endpoint_parse(i)
                else:
                    res = self.Endpoint_parse(i[viewkey])
                for j in res:
                    parsed.append(j)
                        
        return parsed
    
    def Endpoint_parse(self,jsn):
        response = list()
        
        if not jsn:
            return self.empty
        
        if type(jsn) == dict:
            jsn = self.sort_dict(jsn)
            response.append(self.__flatten(jsn))
            
        else:
            for i in jsn:
                if not i:
                    return self.empty
                i = self.sort_dict(i)
                response.append(self.__flatten(i))
                
        return response

    def __flatten(self, d, parent_key='', sep='_'):
        items = []
        for k, v in d.items():
            new_key = parent_key + sep + k if parent_key else k
            if isinstance(v, abc.MutableMapping):
                items.extend(self.__flatten(v, new_key, sep=sep).items())
            elif isinstance(v, abc.MutableSequence):
                items.append((new_key, str(v)))
            else:
                items.append((new_key, v))
        return dict(items)
    
    def sort_dict(self, item: dict):
        return {k: self.sort_dict(v) if isinstance(v, dict) else v for k, v in sorted(item.items())}
    

def dict_mapping(jsn, connection_type):
    import Lyftrondata.Monday.config.mapping as Monday
    
    mapping = Monday.MAPPING[connection_type]
    for m in mapping.keys():
        if jsn.get(m) is not None:
            jsn[mapping[m]] = jsn.pop(m)
    return jsn

