from sqlalchemy import create_engine
from sql_metadata import Parser
import pandas as pd
import sqlparse
import requests
import math
import schedule
import time
import os
import re
import json
import concurrent.futures
import base64 

from Lyftrondata.ADP_SmartCompliance.lib import Lyftrondata_ADP_SmartCompliance_utils as utils
from Lyftrondata.ADP_SmartCompliance.config import config, mapping
from Lyftrondata import payasyougo as pg, AutomatedSchema as AutoSchema

global Connector_name
Connector_name = "Lyftrondata_ADP_SmartCompliance_Connector"

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

data = []
gs = None
dt = None
lookUp = None
engine = create_engine('sqlite://')
engines = [['PostgreSQL','postgresql://scott:tiger@localhost/mydatabase'],['Sql Server','mssql+pyodbc://scott:tiger@mydsn'],['Oracle','oracle://scott:tiger@127.0.0.1:1521/sidname'],['MySQL','mysql://scott:tiger@localhost/foo'],['SQLite','sqlite:///foo.db']]
supportedEngines = pd.DataFrame(columns=['Engine Name','Example Connection'],data=engines,index=None)

##########################################################################
            ####   CONNECTIONS DATA PARSER FETCH DATA    ####
##########################################################################

class Connect:
    ##########################################################################
    #####   ALL CLASS VARIABLES    ####
    ##########################################################################


    dirname = os.path.dirname(__file__)
    endpoints = dict()

    # CALLOUT PARAMS
    StartTime = time.time()
    CONNECTOR_VERSION = '0.0.1'
    API_LIMIT = 100
    worker = 10
    req_resp = None
    is_auto = False
    code = None
    __environment = ''
    timeout = 10
    view = False
    headers = {'Content-Type': 'application/json'}

    # AUTH PARAMS
    token = None
    expired_time = None
    fetched_time = None
    client_id = None
    client_secret = None
    refresh_token = None
    refreshtoken_url = ""
    base_url = "https://api.adp.com/"
    auth_url = ""
    token_url =  "https://accounts.adp.com/auth/oauth/v2/token"
    scope = ""
    subdomain = ""

    # LOG PARAMS
    logging_options = False
    log_connection = True

    # MAKE ALL OAUTH CUSTOM SETTING HERE
    oauth_settings = {
        "auth_url": auth_url,
        "token_url": token_url,
        "auth_params": {'response_type': 'code', 'access_type': 'offline', 'prompt': 'consent'},
        "token_params": {'grant_type': 'client_credentials'},
        "token_headers": {'Content-Type': 'application/x-www-form-urlencoded'},
        "token_data": None, # set to None if no token data is required
    }

    authhandler = utils.Lyftrondata_authHandler()

    ##########################################################################
    #####   INITS    ####
    ##########################################################################

    def __init__(self, LicenseKey):
        self.LicenseKey = LicenseKey
        self.abs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ''))
        self.schema_path = f'{self.abs_path}/schema/{Connector_name.replace("_Connector", "")}.json'
        self.endpointjson = f'{self.abs_path}/config/{Connector_name}_endpoints.json'
        
        with open(self.endpointjson, "r") as readEndpoints:
            self.endpoints = json.load(readEndpoints)
    
    
    @staticmethod
    def replacement(x): 
        return x.replace('"', '').replace("'", '')

    ##########################################################################
    #####                  SCHEMA AND OBJECT LISTING                      ####
    ##########################################################################

    def schema_generator(self, table: str, jsn: dict) -> bool:
        """ generate dynamic schema whenever this function is called

        Args:
            table (string): name of the table
            jsn (dict): response of the table in dict

        """
        tables = []

        if os.path.exists(self.schema_path):
            with open(self.schema_path) as sch:
                schema = json.load(sch)
            sch.close()
            tables = list(schema['Tables'].keys())
        

        if table in tables and self.is_auto == True:
            list_columns = []
            not_present = []

            for cols in schema['Tables'][table]['columns']:
                list_columns.append(cols['column'])
                
            df = self.json_parse(jsn, table)[table]
            
            for res_col in df.columns:
                if res_col not in list_columns:
                    not_present.append(res_col) 
                    
            if not_present:                
                jsn_data = df.to_dict(orient='records')
                cleaned_response = AutoSchema.clean_null({table:jsn_data})
                AutoSchema.create_schema(cleaned_response,self.schema_path)
                AutoSchema.addConstraint(schema_path = self.schema_path,endpoint_path = self.endpointjson)
                print(f"Added following Columns in Schema {not_present}")
            return True
        
        elif bool(jsn) and table not in tables:
            if type(jsn[table]) == list:
                jsn[table] = jsn[table][0]

            cleaned_response = AutoSchema.clean_null(jsn)
            AutoSchema.create_schema(cleaned_response,self.schema_path)
            AutoSchema.addConstraint(schema_path = self.schema_path,endpoint_path = self.endpointjson)
            return True
        else:
            return False

    def getMetadata(self):
        response = {'tables': {}}
        jsn = pd.read_json(self.schema_path, orient="records", typ="records")
        for k,v in jsn['Tables'].items():
            if k.__contains__('sys.'):
                pass
            else:
                response['tables'][k] = v

        return response

    def getConnectorDefinition(self,param):
        
        if isinstance(param, str):
            csv = pd.read_csv(param)
            return csv.to_json(orient='records')
        else:
            engine = param['engine']
            db = param['db']
            name = param['name']
            user = param['user']
            password = param['password']
            host = param['host']
            port = param['port']
            engine = create_engine(
                engine+'://'+user+':'+password+'@'+host+':'+port+'/'+db)

            query = engine.execute(
                'select * from "Lyftrondata_Connector_Definition"')

            df = pd.DataFrame(query, columns=query.keys())
            return df.to_json(orient='records')

    def get_schema_tables(self) -> tuple:

        """
        Returns a list of tables in the schema

        Returns: list of tables in the schema
        """
        self.StartTime = time.time()

        try:
            nested = self.endpoints['nested_endpoints'].keys()
            tablelist = self.execute_query("select * from sys.tables")[1]
            tablelist = tablelist.loc[tablelist['DataType'] == 'table']
            data = tablelist['TableName'].tolist()
            new_data = list()
            for table in data:
                if table not in nested:
                    new_data.append(table)
            status = {
                'Status':'Success!'
                }
            flag = True
        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            data = e
            flag = False
        self.payasyougo_check(self.get_schema_tables,status)
        return flag, new_data

    def get_schema_view_list(self,schema_list=[]) -> tuple:

        """
        Returns a list of views in the schema

        Returns: list of views in the schema
        """
        self.StartTime = time.time()

        try:
            tablelist = self.execute_query("select * from sys.tables")[1]
            tablelist = tablelist.loc[tablelist['DataType'] == 'view']
            data = tablelist['TableName'].tolist()
            status = {
                'Status':'Success!'
                }
            flag = True
        
        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            data = e
            flag = False
        
        self.payasyougo_check(self.get_schema_tables,status)
        return flag, data

    def get_table_columns(self, tables=[]) -> tuple:
        """
        Get the columns of the table from the schema

        Parameters:
            tables (list): List of tables

        Returns:
            list: List of columns of the table
        """
        self.StartTime = time.time()
        res = []
        nested = self.endpoints['nested_endpoints']
        try:
            jsn = json.load(open(self.schema_path))["Tables"]
            for k in jsn:
                if k in tables and k not in nested:
                    res.append(jsn[k])
            status = {
                'Status':'Success!'
                }
            flag = True
        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            flag = False
            res = e

        self.payasyougo_check(self.get_table_columns,status)
        return flag, res

    def get_schema_list(self,con='') -> tuple:
        """ This Fucntion returns list of schema.

        Args:
            con (ConnectorObj, required): _description_.

        Returns:
            tuple: (Boolen , schema_list: list)
        """


        self.StartTime = time.time()
        schema_list = []

        try :
            schema_list.append(f'{Connector_name.replace("_Connector", "")}')

            status = {
                'Status':'Success!',
                "Result": schema_list
                }
            
            self.payasyougo_check(self.get_table_columns,status)
            return True, schema_list

        except Exception as e :
            status = {
                'Status':'Failed!',
                "Error": str(e)
                }
            
            self.payasyougo_check(self.get_table_columns,status)
            return False, str(e)

    def get_schema_objects(self,con,schemas) -> tuple:
        """ This Function returns the schema objects for given schema list.

        Args:
            con (Connector.initialize()): takes Connector initialzie object 
            schemas (list): list of schema to fetch the Objects inside schema

        Returns:
            tuple: (Boolen , schema_obj : dict)
        """

        self.StartTime = time.time()
        schema_obj = dict()
        flag = False
        error_msg = ""
        nested = self.endpoints['nested_endpoints']

        for sch in schemas:
            
            tables_in_schema = list()
            views_in_schema = list()
            
            try:
                with open(self.schema_path, "r") as schema:
                    schema_json = json.loads(schema.read())
                
                tablenames = schema_json['Tables'].keys()

                for table in tablenames:
                    if table.__contains__("sys."):
                        pass
                    else:
                        datatype = schema_json['Tables'][table]['datatype'] 
                        if datatype == 'view':
                            views_in_schema.append(table)
                        else:
                            if table not in nested:
                                tables_in_schema.append(table)
                            
                schema_obj[sch['schema_name']] = {'TABLE':tables_in_schema, 'VIEW':views_in_schema}
                status = {
                    'Status':'Success!',
                    "Result": schema_obj
                }
                flag = True

            except Exception as e :
                status = {
                    'Status':'Failed!',
                    "Error": str(e)
                }
                flag, error_msg = False, str(e)

        self.payasyougo_check(self.get_schema_objects,status)

        return (flag, schema_obj) if flag else (flag, error_msg)

    def get_object_columns(self,con,obj:list,no_of_page=10,read_json=False):

        """ This Function returns all the columns of the provided schema objects

        Args:
            con (connector.initialize()): connector initialze method object
            obj (list): schema object
            no_of_page (int, optional): _description_. Defaults to 10.

        Returns:
            tuple(boolean, object_columns:dict): return the tuple containing boolean for status of object and
            columns info of the provided objects
        """

        self.StartTime = time.time()
        obj_columns = dict()
        flag = False
        msg = str()

        for schema in obj:
            schema_name = schema['schema_name'].replace('_',' ')
            tables = list()
            views = list()
            nested = self.endpoints['nested_endpoints']

            for objects in schema['object_list']:
        
                if 'TABLE' in objects:
                    list_table = list()
                    for table in objects['TABLE']:
                        if table not in nested:
                            list_table.append(table)

                    if read_json:
                        with open(self.schema_path, "r") as schema:
                            schema_json = json.loads(schema.read())
                        schema = schema_json['Tables']
                    else:
                        schema = self.__get_updated_schema(list_tables=list_table,no_of_page=no_of_page)
                    
                    for table in list_table:
                        column_list = list()
                        try:        
                            for obj in schema[table]['columns']:
                                column_list.append({"column":obj['column'],"datatype":obj["datatype"],"description":obj["description"]})

                            status = {
                                'Status':'Success!',
                                }
                                
                            flag = True

                        except Exception as e:
                            flag = False
                            msg = str(e)
                            status = {
                                'Status':'Failed!',
                                "Error": str(e)
                            }

                        tables.append({table:{'columns': column_list}})

                if 'VIEW' in objects:
                    if read_json:
                        with open(self.schema_path, "r") as schema:
                            schema_json = json.loads(schema.read())
                        schema = schema_json['Tables']
                    else:
                        schema = self.__get_updated_schema(list_tables=objects['VIEW'])

                    for table in objects['VIEW']:
                        column_list = list()
                        try:        
                            for obj in schema[table]['columns']:
                                column_list.append({"column":obj['column'],"datatype":obj["datatype"],"description":obj["description"]})

                            status = {
                                'Status':'Success!',
                                }
                                
                            flag = True

                        except Exception as e:
                            flag = False
                            msg = str(e)
                            status = {
                                'Status':'Failed!',
                                "Error": str(e)
                            }

                        views.append({table:{'columns': column_list}})

            schema_name = schema_name.replace(' ', "_")
            obj_columns[schema_name] = {'TABLE' : tables,'VIEW': views}

        self.payasyougo_check(self.get_object_columns,status)

        return (flag, obj_columns) if flag else (flag, msg)

    def __get_updated_schema(self,tables=False,views=False,
                    list_tables=False ,list_views=False,no_of_page=10) -> dict:
        """ This is private function to call all the tables and views for provided schema

        Args:
            tables (bool, optional): if true returns all the tables. Defaults to False.
            views (bool, optional): if true returns all the views . Defaults to False.
            list_tables (bool, optional): returns the response on provided tables. Defaults to False.
            list_views (bool, optional): returns the response on provided views. Defaults to False.
            no_of_page (int): no of pages for provided schema.
        Returns:
            dict: updated Schema response.
        """
        schema_response = dict()
        
        def __get_colums(df) -> list:
           
            def __checkdtype(val):
                val = str(val)

                if val == 'int64':
                    datatype = "int"

                elif val == 'bool':
                    datatype = "boolean"

                elif val == "object":
                    return "varchar(255)"

                elif val == 'datetime64':
                    datatype = "datetime"

                elif val == 'float64' :
                    datatype = "float"

                else:
                    datatype = "varchar(255)"

                return datatype

            columns_list = []

            for col in df.columns:
                column = dict()
                column['column'] = col
                column['datatype'] = __checkdtype(df[col].dtype)
                column['description'] = ''
                columns_list.append(column)

            return columns_list
        
        if views:            
            for table in self.endpoints['views'].keys():

                data = self.fetchDataFromAPI(table,
                        from_page=1,
                        to_page=no_of_page)
                        
                if data[table]:
                    data = self.json_parse(data,table)
                    cols = __get_colums(data[table])

                    updated_response = {
                        table:{
                        "datatype": "view",
                        "columns": cols
                        }
                    }
                    schema_response.update(updated_response)
        
        if list_views:
            for table in list_views:
            
                data = self.fetchDataFromAPI(table,
                    from_page=1,
                    to_page=no_of_page)

                if data[table]:
                    data = self.json_parse(data,table)
                    cols = __get_colums(data[table])
                    updated_response = {
                        table:{
                        "datatype": "view",
                        "columns": cols
                        }
                    }
                    schema_response.update(updated_response)

        if tables:
            for table in self.endpoints['endpoints'].keys():
                data = self.fetchDataFromAPI(table,
                        from_page=1,
                        to_page=no_of_page)
                        
                if data[table]:
                    data = self.json_parse(data,table)
                    cols = __get_colums(data[table])
                    updated_response = {
                        table:{
                        "datatype": "table",
                        "columns": cols
                        }
                    }
                    schema_response.update(updated_response)

        if list_tables:
            for table in list_tables:
                data = self.fetchDataFromAPI(table,
                        from_page=1,
                        to_page=no_of_page)
               
                if data[table]:
                    data = self.json_parse(data,table)
                    cols = __get_colums(data[table])
                    updated_response = {
                        table:{
                        "datatype": "table",
                        "columns": cols
                        }
                    }
                    schema_response.update(updated_response)
        
        return schema_response
 
    ##########################################################################
    ####                MAKE CONNECTOR REQUESTS FROM API                  ####
    ##########################################################################
    
    def makeView(self,required_parameter,baseUrl,replaced_parameter,col=None,val=None,jsn=None,endpoint=None):
        """
        Description:
        this method will be used when a person wants to filter per id(showing detailed explanantion). 
        It will find key and then get responses of each record

        Parameters:
            jsn ([list]): [contains the response of the main table ]
            required_parameter ([string]): [key so that we can filter against it ]
            base_url ([string]): [url to hit the main model/table]
            replaced_parameter ([string]) : key which have to be replaced by required parameter.
            endpoint ([string], optional): endpoint if required. default is None.
            
        """
        
        finalresponse=list()
        required_parameter=required_parameter.split('.')
        if col != None:          
            if replaced_parameter in col:
                a = val[col.index(replaced_parameter)]
                value = str(a)
                url = baseUrl + endpoint.replace(replaced_parameter, self.replacement(value))
                response = self.req(url)[1].json()
                if type(response) == list:
                    for i in response:
                        i[replaced_parameter]= self.replacement(str(a))
                else:
                    response[replaced_parameter] = self.replacement(str(a))
                
                finalresponse.append(response)
            return finalresponse         

        a = jsn
        b = []
        urls = list()
        for item in jsn:
            a=item
            for k in required_parameter:
                if k in a:
                    a = a[k]
                    url = baseUrl + endpoint.replace(replaced_parameter,str(a))
                    urls.append(url)
                    b.append(a)
                else:
                    raise KeyError(f"Unproper Response or {k} not found in response - contact help@lyftrondata.com")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.worker) as executor:
            self.view = True
            futures =  executor.map(self.req, urls)
            futures = list(futures)
            self.view = False

        for i, d in zip(futures, b):
            if  i != None:
                i = i[1].json()
                if type(i) == list:
                    for j in i:
                        j[replaced_parameter]= self.replacement(str(d))
                else:
                    i[replaced_parameter] = self.replacement(str(d))
                
                finalresponse.append(i)
            
        return finalresponse

    def return_error(self, status_code, req):
        print(req.status_code, req.url)
        emptyjson = dict()
        
        if isinstance(status_code, str):
            status_code = int(status_code)

        if status_code == 200:
            print("Connection to table [Success]")
            try:
                req.json()
            except json.decoder.JSONDecodeError as e:
                return False, {"Lyft_error": f"Unproper Response or {e}"}
            except:
                return True, {"Lyft_error": "Connection to table [Success] but response is not in json format"}
            else:
                return True, req
        
        elif status_code in utils.request_exceptions:
            custom_exception = utils.request_exceptions[status_code]
            if self.view:
                return None
            else:
                return False, {"Lyft_error": custom_exception}
        
        else:
            return False, {"Lyft_error": requests.exceptions.RequestException(f"{str(status_code)} AN UNKNOWN ERROR OCCURED")}

    def req(self,url,headers=None,params=None):
        
        """ This Function is used for making request on endpoints.

        Args:
            url (string): endpoint url
            headers (dict, optional): headers for the request if required. Defaults to None.
            params (dict, optional):  params for the request if required. Defaults to None.

        Returns:
            json: response from the endpoint in form of json/dict
        """
        if self.expired_time != None:
            isExpired = self.authhandler.check_expire_time(self.expired_time, self.fetched_time)
            print(f'is token expired ? {isExpired}')
            
            if isExpired == True and self.refresh_token != None:
                self.refreshtoken_url = self.refreshtoken_url.replace("SUBDOMAIN", self.subdomain)
                
                refreshtoken_data = {
                    'grant_type': 'refresh_token',
                    'refresh_token': self.refresh_token,
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'scope': self.scope
                }
                
                refresh = self.authhandler.refreshToken(
                    self.token_file,
                    refreshtoken_url=self.refreshtoken_url,
                    refreshtoken_params=None,
                    refreshtoken_data=refreshtoken_data
                )

                self.expired_time = refresh.get('expires_in')
                self.fetched_time = refresh.get('fetched_at')
                self.refresh_token = refresh.get('refresh_token')
                self.token = refresh.get('access_token')
                self.headers.update({"Authorization":f"Bearer {self.token}"})
                
            elif isExpired == True and self.refresh_token == None:
                self.oauth_settings['token_url'] = self.token_url

                cred_token = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode('utf-8')).decode('utf-8')
                self.oauth_settings['token_headers'].update({"Authorization":f"Basic {cred_token}"})
                self.oauth_settings['token_cert'] = self.cert

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    self.headers.update({"Authorization":f"Bearer {self.token}"})
                    with open(self.token_file, 'w') as f:
                        json.dump(resp, f)
                else:
                    raise Exception("Token expired and refresh token not found")

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']

                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']

                self.fetched_time = resp['fetched_at']


        with requests.Session() as s:
            req = s.get(url, headers=self.headers, data=data, cert=self.cert, timeout=self.timeout)
            self.req_resp = req
        return self.return_error(req.status_code,req)

    ##########################################################################
    ####             INTIALIZE AND LOAD USER CREDIENTIALS                 ####
    ##########################################################################

    def test_connection(self, obj):
        """
        Make a test connection to the API.

        Args:
            endpoint_path: 

        Returns:
            Message indicating the connection status.
        """
        if obj is not None:
            return True, ""
        else:
            return False, "Connection Failed"

    def token_file_handler(self, token_file):
        with open(token_file, "r") as tokenfile:
            tokenjson = json.load(tokenfile)
        
        self.token = tokenjson.get('access_token')
        self.expired_time = tokenjson.get('expires_in')
        self.refresh_token = tokenjson.get('refresh_token')
        self.fetched_time = tokenjson.get('fetched_at')
        
        return self.token
    
    def initializeJson(self, creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        self.StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'

        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            status = {
                    'Connection String':'',
                    'Status': f'Failed! {str(e)}'
                        }

            self.payasyougo_check(self.initialize, str(e))
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : utils.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : utils.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : utils.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : utils.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : utils.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : utils.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : utils.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : utils.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : utils.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : utils.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : utils.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : utils.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : utils.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "is_auto": utils.dict_mapping(init_jsn,connection_type).get('is_auto') or False,
            "logging_options" : utils.dict_mapping(init_jsn,connection_type).get('logging_options') or init_jsn.get('logging_options') or False
        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            status = {
                'Connection String' : init_params,
                'Status': 'Success!'
            }
            self.payasyougo_check(self.initializeJson,status)
            return init

        except Exception as e:
            status = {
                'Connection String' : init_params,
                'Status': f'Failed! {str(e)}'
            }

            self.payasyougo_check( self.initializeJson,status)

            raise Exception(e)

    def initialize(self,connection_type=None, personal_token=None, client_id=None, client_secret=None, redirect_uri=None, subdomain=None, username=None, password=None, lyft_token_email=None, access_key_id=None, secret_access_key=None, region_name=None, bucket=None, aggregate=False,logging_options=False, pem_key=None,crt_key=None,is_auto=False, **kwargs):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            connection_type ([string], required): [type of connection] - enum: ['personalToken', 'OAuth2', 'basicAuth', 's3', 'oauth_client_credentials']
            personal_token ([string], optional): [personal token] - personal token generated by API
            client_id ([string], optional): [client id] - provided by API it is required if connection type is "OAuth2"
            client_secret ([string], optional): [client secret] -  provided by API it is required if connection type is "OAuth2"
            redirect_uri ([string], optional): [redirect uri] - provided by API it is required if connection type is "OAuth2"
            subdomain ([string], optional): [subdomain] (If Required)
            username ([string], optional): [username] - provided by API it is required if connection type is "basicAuth"
            password ([string], optional): [password] - provided by API it is required if connection type is "basicAuth"
            lyft_token_email ([string], required): [lyft token email] - provided by API it is required if connection type is "OAuth2"
            access_key_id ([string], optional): [access key id] - provided by API it is required if connection type is "s3"
            secret_access_key ([string], optional): [secret access key] - provided by API it is required if connection type is "s3"
            region_name ([string], optional): [region name] - provided by API it is required if connection type is "s3"
            bucket ([string], optional): [bucket] - provided by API it is required if connection type is "s3"
            aggregate ([boolean], optional): [aggregate]
            logging_options ([boolean], optional): [logging options] 
            is_auto ([boolean], optional): [is auto] - if true then it will automatically generate schema based on the response.
            **kwargs: [keyword arguments] - other arguments

        Returns:
            token: access token which will be used as to make requests.
        """

        self.StartTime = time.time()
        self.logging_options = logging_options
        self.is_auto = is_auto
        self.__environment == kwargs.get('environment')

        self.__environment = kwargs.get('environment', None)
        if lyft_token_email != '' and lyft_token_email != None:
            self.token_file = f'{self.abs_path}/{lyft_token_email}_{Connector_name}_token.json'
        else:
            if self.__environment == "development":
                self.token_file = f'{self.abs_path}/{Connector_name}_token.json'
            else:
                raise ValueError("Kindly Provide lyft_token_email")

        self.is_auto = is_auto
        self.aggregate = aggregate or ""
        self.subdomain = subdomain or ""
        self.client_id = client_id or ""
        self.client_secret = client_secret or ""
        redirect_uri = redirect_uri or ""
        username = username or ""
        password = password or ""
        personal_token = personal_token or ""
        connection_type = connection_type or ""
        connection_string = str({
            'connection_type':connection_type,
            "personal_token":personal_token,
            "client_id":client_id,
            "client_secret":client_secret,
            'redirect_uri':redirect_uri,
            "subdomain":subdomain,
            "username":username,
            "password":password,
            "lyft_token_email":lyft_token_email,
            'access_key_id':access_key_id,
            "secret_access_key":secret_access_key,
            "region_name":region_name,
            'bucket':bucket,
            "aggregate":aggregate,
            "logging_options":self.logging_options
        })
        
        if connection_type.lower() == "personaltoken":
            self.token = personal_token
            self.headers.update({"Authorization":f"Bearer {self.token}"})

        elif connection_type.lower() == "basicauth":
            self.token = base64.b64encode(f"{username}:{password}".encode('utf-8')).decode('utf-8')
            self.headers.update({"Authorization":f"Basic {self.token}"})

        elif connection_type.lower() == "oauth2":

            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file)
                self.headers.update({"Authorization":f"Bearer {self.token}"})

            else:
                token_params = {'client_id': self.client_id, 'client_secret': self.client_secret, 'redirect_uri': redirect_uri}
                auth_params = {'client_id': self.client_id, 'scope': self.scope, 'redirect_uri': redirect_uri}

                self.oauth_settings['auth_url'] = self.auth_url.replace("SUBDOMAIN", self.subdomain)
                self.oauth_settings['token_url'] = self.token_url.replace("SUBDOMAIN", self.subdomain)
                self.oauth_settings['token_params'].update(token_params)
                self.oauth_settings['auth_params'].update(auth_params)

                if self.code is not None:
                    self.oauth_settings['token_params']['code'] = self.code

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    self.headers.update({"Authorization":f"Bearer {self.token}"})
                    with open(self.token_file, "w") as tokenjson:
                        json.dump(resp, tokenjson)
                else:
                    status = {
                        'Connection String':connection_string,
                        'Status': f'Failed! {str(resp)}'
                        }

                    self.payasyougo_check(self.initialize,status)
                    return False, resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        elif connection_type.lower() == "oauth2_client_credentials":
            self.pem_key = pem_key
            self.crt_key = crt_key

            self.cert = (self.pem_key, self.crt_key)
            
            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file)
                self.headers.update({"Authorization":f"Bearer {self.token}"})

            else:
                self.oauth_settings['token_url'] = self.token_url
                
                cred_token = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode('utf-8')).decode('utf-8')

                self.oauth_settings['token_headers'].update({"Authorization":f"Basic {cred_token}"})
                self.oauth_settings['token_cert'] = self.cert

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    self.headers.update({"Authorization":f"Bearer {self.token}"})
                    with open(self.token_file, 'w') as f:
                        json.dump(resp, f)
                else:
                    status = {
                    'Connection String':connection_string,
                    'Status': f'Failed! {str(resp)}'
                        }

                    self.payasyougo_check(self.initialize,status)
                    return False, resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        else:
            print("Provide the Connection Type: 'personalToken' or 'OAuth2' ")
            self.token = None
            status = {
                    'Connection String':connection_string,
                    'Status': 'Failed!',
                    'Error': 'Invalid connection_type'
                }
            self.payasyougo_check(self.initialize,status)
            return False , self.token
        
        status = {
                'Connection String':connection_string,
                'Status': 'Success!'
                }
        self.payasyougo_check(self.initialize,status)
        return True, self.token

    ##########################################################################
    ####                      PAGINATION METHODS                          ####
    ##########################################################################
    
    @staticmethod
    def __generate_paginated_url(url, l, u):
        """
        This method is used to generate paginated url.

        Args:
            url ([string], required): [url]
            l ([int], required): [lower limit]
            u ([int], required): [upper limit]

        Returns:
            url: paginated url
        """

        if url.__contains__("?"):
            urls = [url + f"&page={i}" for i in range(l, u)]
        else:
            urls = [url + f"?page={i}" for i in range(l, u)]
        
        return urls
    
    @staticmethod
    def __multi_execution_response(responses, table):
        """This method is used to get the response of multiple requests.
        
        Args:
            responses ([list], required): [list of responses]]
            table ([string], required): [table name]

        Returns:
            response: response of multiple requests.
        """
        
        resp = list()
        cond = True
        endpoints_keys = {}
        for i in responses:
            actual_resp = i[1].json()
            try:
                if table in endpoints_keys:
                    key_value = endpoints_keys[table]
                    if i[1].status_code != 200:
                        cond = False
                    if not bool(actual_resp):
                        cond = False
                    else:
                        i = actual_resp
                        resp.append(i[key_value])
                else:
                    if not bool(actual_resp):
                        cond = False
                    else:
                        resp.append(i)

            except Exception as e:
                cond = False
                
        return resp, cond
    
    def __pagination_loop(self, url, lower_limit, upper_limit, total_page, table, resp, per_api_calls = 5, limit = None):
        """
        This function is used to paginate the data.
        
        Args:
            url (str): The url to be paginated.
            lower_limit (int): The lower limit of the pagination.
            upper_limit (int): The upper limit of the pagination.
            total_page (int): The total number of pages.
            table (str): The table name.
            resp (list): The list of the response.
            
        Returns:
            resp (list): The list of the response.
            count (int): The count of the response.
        """
        count = 1
        while True:
            urls = self.__generate_paginated_url(url, lower_limit, upper_limit)
            r, cond = self.__multi_execution(urls, table)
            resp.extend(r)

            if total_page is not None:
                if limit != None and len(resp) >= limit[0] + limit[1]: 
                    break
                elif upper_limit > total_page or cond == False:
                    break
                else:
                    lower_limit = upper_limit
                    upper_limit += per_api_calls if (total_page  - lower_limit) >= 5 else (total_page - lower_limit) + 1
                    count += 1
            else:
                if limit != None and len(resp) >= limit[0] + limit[1]: 
                    break
                if cond == False:
                    break
                else:
                    lower_limit = upper_limit
                    upper_limit += per_api_calls
                    count += 1
                
        return resp
     
    def __multi_execution(self, urls, table, api_request_limit=5):
        """
        This function is used to to execute multiple requests in parallel.

        Args:
            urls (list): The list of the urls.
            table (str): The table name.
            api_request_limit (int, optional): The number of requests to be executed in parallel. Defaults to 5.

        Returns:
            resp (list): The list of the response.
            cond (bool): The condition of the response.
        """
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=api_request_limit) as executor:
            r = executor.map(self.req, urls)
            time.sleep(6)
        
        return self.__multi_execution_response(r, table)
    
    def url_pagination(self, url, table, from_page=None, to_page=None, total_page=None, request_limit = 5, limit = None):
        """ Pagination function for getting the data from the API
            Args:
                url (str): URL of the API
                table (str): Table name of the API
                from_page (int): Starting page number
                to_page (int): Ending page number
                total_page (int): Total number of pages
                request_limit (int): Number of requests to be made at a time (default: 5)
                response_json (dict): Response JSON

            Returns:
                list: List of the data
        """
        resp = list() 
        
        if from_page is not None and to_page is not None:
            try:
                l = from_page
                u = l + 5
                resp = self.__pagination_loop(url, l, u, to_page, table, resp, limit = limit)
                return resp
            except Exception as e:
                raise e
            
        else:
            try:
                l, u = 1, request_limit                 
                resp = self.__pagination_loop(url, l, u, total_page, table, resp, limit = limit)
                return resp
            except Exception as e:
                raise e

    ##########################################################################
    ####                     FETCHING METHODS                            ####
    ##########################################################################

    def fetchDataFromAPI(self,table,parameter=None,parameterValue=None,from_page=None,to_page=None, limit = None):
        """
        Description:
            This Method is used to fetch data from API specific endpoint.
            
        Parameters:
            table(string): table name or endpoint name.
            col(list[string]): contains the column names 'SELECT * FROM table Where col = value'.
            value(list[string]): contains the value of specified column.
        
        Returns:
            jsn(json) : json file contains the complete response fetched from endpoint 
        """
        
        self.StartTime = time.time()
        fetchedData = dict()
        base = self.base_url.replace("SUBDOMAIN", self.subdomain)

        params = None
        response_json = dict()
        error_msg = None
        
        endpoint = self.endpoints.get('endpoints')
        views = self.endpoints.get('views')
        nested_endpoints = self.endpoints.get('nested_endpoints')

        if table.lower() in views.keys():
            tab = views[table.lower()]

            paginated_enpoint = [
                # add table if pagination is required
            ]

            response = self.req(base+tab['from_endpoint'], params=params)
            response_json = response[1].json() if response[0] == True else response[1]
            if from_page is None and to_page is None:
                pass
                ## APPLY YOUR LOGIC ACCORDINGLY IF  NUMBER OF PAGES IS PROVIDED IN RESPONSE OF TABLE 
                # if "nb_pages" in response_json['meta']:
                #    self.total_page = response_json['meta']['nb_pages']
                # else:
                #    self.total_page = 1

            if tab['from_endpoint_name'] in paginated_enpoint:
                response_json = self.url_pagination(base+tab['from_endpoint'], 
                                                tab['from_endpoint_name'],
                                                from_page=from_page,
                                                to_page=to_page,
                                                total_page=self.total_page, limit=limit)

            parser = utils.Lyftrondata_ADP_SmartCompliance_Parser(tab['from_endpoint_name'], response_json)
            parsed_parameters_json = parser.parse()

            response_json = self.makeView(
                jsn=parsed_parameters_json,
                required_parameter=tab['replace_from'],
                baseUrl=base,
                endpoint=tab['view_endpoint'],
                replaced_parameter=tab['replace_to'],
                col=parameter,
                val=parameterValue
            )

            status = {
                'Table': table,
                self.req_resp.request.method: base+table,
                'Status': 'Success!',
                'Headers': self.req_resp.headers,
                'Result': response_json
            }

        elif table.lower() in endpoint.keys():
            url = endpoint[table.lower()]
            complete_url = base+url
            complete_url = self.replacement(complete_url)

            paginated_enpoint = [
                # Add endpoint name here if it contain pagination.   
            ]
            
            response = self.req(complete_url, params=params)
            
            if from_page is None and to_page is None and table in paginated_enpoint:
                response_json = response[1].json() if response[0] == True else response[1]
                # self.total_page = response_json['meta']['nb_pages']

            if table.lower() in paginated_enpoint:
                response_json = self.url_pagination(complete_url, table.lower(),
                                            from_page=from_page,
                                            to_page=to_page,
                                            total_page=self.total_page, limit = limit)
            else:
                response_json = response[1].json() if response[0] == True else response[1]
            status = {
                'Table': table,
                self.req_resp.request.method: complete_url,
                'Status': 'Success!',
                'Result': response_json
            }

        elif table.lower() in nested_endpoints.keys():
            nest_para = nested_endpoints[table.lower()]['parameters']
            tableurl = nested_endpoints[table.lower()]['url']
            for i in nest_para:
                
                if not parameter:
                    error_msg = ValueError(f"{nest_para} is not Given in query")
                
                if i in parameter:
                    tableurl = tableurl.replace(i, parameterValue[parameter.index(i)])
                else:
                    error_msg = ValueError(f"{i} is not Given in query")

            complete_url = base+tableurl
            response = self.req(self.replacement(complete_url), params=params)
            response_json = response[1].json() if response[0] == True else response[1]
            parser = utils.Lyftrondata_ADP_SmartCompliance_Parser(table, response_json)
            parsedResponse = parser.parse()

            if not parsedResponse:
                parsedResponse = []
                for i in nest_para:
                    if i in parameter:
                        parsedResponse.append({i:parameterValue[parameter.index(i)]})
                    else:
                        parsedResponse.append({i: None})
            else:       
                for i in nest_para:
                    if type(parsedResponse) == list and bool(parsedResponse):
                        for l in parsedResponse:
                            l[i] = self.replacement(
                                parameterValue[parameter.index(i)])
                            parsedResponse[parsedResponse.index(l)] = l
                    else:
                        parsedResponse[i] = self.replacement(
                            parameterValue[parameter.index(i)])

            if error_msg: 
                status = {
                    'Table': table,
                    response[1].request.method:response[1].url,
                    'Status': f'Failed {str(error_msg)}'
                }
                self.payasyougo_check(self.fetchDataFromAPI,status)
                raise error_msg
        
            else: 
                fetchedData = {table: parsedResponse}
                self.schema_generator(table, fetchedData)
            
                status = {
                    'Table': table,
                    response[1].request.method:response[1].url,
                    'Status': 'Success!',
                    'Headers': response[1].headers,
                    'Body': response[1].content,
                    'Result': response_json
                }
                
                self.payasyougo_check(self.fetchDataFromAPI,status)
                return fetchedData
            
        else:
            response = self.req(base+table, params=params)
            response_json = response[1].json() if response[0] == True else response[1]
            status = {
                'Table': table,
                self.req_resp.request.method: self.req_resp.url,
                'Status': 'Success!',
                'Headers': self.req_resp.headers,
                'Body': self.req_resp.content,
                'Result': response_json
            }
            
        parser = utils.Lyftrondata_ADP_SmartCompliance_Parser(table, response_json)

        parsedResponse = parser.parse()
        fetchedData = {table: parsedResponse}
        self.schema_generator(table, fetchedData)
        
        
        if from_page != None:
            limit=30
            top = 0 if from_page==1 else limit * from_page
            data = self.json_parse(fetchedData,table)[table]

            if to_page != None:
                skip = limit * to_page
                var = data[top:skip]

            else:
                var = data[top:]
                
            fetchedData = {table:json.loads(var.to_json(orient="records"))}
            
        if error_msg:
            status = {
                'Table': table,
                self.req_resp.request.method: self.req_resp.url,
                'Status': f'Failed! {str(error_msg)}',
            }
            self.payasyougo_check(self.fetchDataFromAPI,status)
            return fetchedData

        else:
            self.payasyougo_check(self.fetchDataFromAPI,status)
            return fetchedData

    def json_parse(self,jsn, main_table_name):

        """
        Description:
            This method is used to parse/Normalize the Json Response fetched from endpoint in a way where
            object and array will be consider as separate Dataframes.

        Parameters:
            jsn(json): json response which have to be normalize.
            main_table_name: Main endpoint Name where the response is fetched from.

        Return:
            dataframes(dict) : dictionary which contains all the key as tablename and value as Dataframes.
        """
        dataframe = None
        simple = dict()
        dataFrames = dict()
        for key in jsn:
            val = jsn[key]
            if type(val) == list:
                dataFrames[key] = pd.DataFrame(val)
            elif type(val) == dict:
                dataframe = pd.DataFrame.from_dict(
                    val, orient="index")
                dataFrames[key] = dataframe.transpose()
            else:
                simple[key] = val
        if not simple:
            return dataFrames
        else:
            datafr = pd.DataFrame.from_dict(simple,orient="index")
            dataFrames[main_table_name] =datafr.transpose()
            return dataFrames

    ##########################################################################
    ####            SCHEMA GENERATION AND SYSTEMS QUERIES                 ####
    ##########################################################################
 
    def execute_query(self, query,provider_obj=None):
        """
        Description:
            This method is used to break the query such as tablename, column,values

        Parameter:
            query(string): Takes Query in String Format.

        Returns:
            Table(pandas.DataFrame): Returns the dataframe contains the queried table data.

        QueryFormat:
            select (* | COMMA_SEPERATED_COLUMNS_LIST) from TABLENAME [where KEY = VALUE (and|or) KEY = VALUE] 
            [limit NO_OF_ROWS:INT] [offset NO_OF_STARTING_ROWS_NEGLECTED:INT] 
            [lyftpagestart STARTING_PAGE_NO:INT] [lyftpageend ENDING_PAGE_NO:INT]

            SQUARE_BRACKET fields are optional

        """
        query = query.lower()
        self.StartTime = time.time()

        def __execute(table,parameter,parametervalue, from_page = None, to_page = None, limit = None):
            if not bool(parameter) and not bool(parametervalue):
                parameter, parametervalue = None, None

            jsonres = self.fetchDataFromAPI(table,parameter,parametervalue, from_page, to_page, limit=limit)
            list_df = self.json_parse(jsonres, table)
            for df_name, df in list_df.items():
                self.dataToTable(df, df_name)

            try:
                r = engine.execute(query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True,df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        def __execute_sys(table, col):
            try:
                data = self.sysQueries(table,col)
                tablename = table.replace('.','_')
                self.dataToTable(data,tablename)
                modified_query = query.replace(table,tablename)
                r = engine.execute(modified_query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True , df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        def __sql_query_tokenizer(query):
            """ Tokenize SQL query and return a list of tokens."""

            query = query.replace('\n', '').replace('  ', ' ')
            re_where_clause = re.compile(r'((\"|\')?([A-Za-z0-9_]+)(\"|\')?(\s+)?=(\s+)?(\"|\')?[A-Za-z0-9_]+(\"|\')?(\s+)?(and|or)?)+')
            re_lyftpage_clause = re.compile(r'(lyftpage(start|end)\s+[0-9]+)')

            where_clause = {}
            lyftpage_clause = {}

            columns = Parser(query).columns
            tables = Parser(query).tables
            limit = Parser(query).limit_and_offset or None

            for j in re.findall(re_where_clause, query):
                k = j[0]
                k = k.replace('"', '').replace("'", '')\
                    .replace(' and', "").replace(' or', '')\
                    .replace(' ', '')
                k = k.split('=')
                where_clause[k[0]] = k[1]

            lyft_page = re.findall(re_lyftpage_clause, query)
            is_pages = bool(lyft_page)

            if is_pages:
                query = re.sub(re_lyftpage_clause, '', query)
                    
            for j in lyft_page:
                k = j[0]
                k = k.replace('  ', '')
                k = k.split(' ')
                lyftpage_clause[k[0]] = k[-1]
                
            return columns, tables, where_clause, lyftpage_clause, limit, query
   
        if query.__contains__("Describe"):
            try:
                
                t =query.split("Describe ")
                data = self.sysQueries("sys.Describe", t[1])
                status = {"Status": "Success!",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return True , data

            except Exception as e:

                status = {"Status": f"Failed! {str(e)}",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        
        que = query.split()
        if que[0].lower() =="select":
            columns, tables, where_clause, lyftpage_clause, limit, query = __sql_query_tokenizer(query)
            
            if query.lower().__contains__("sys."):
                return __execute_sys(tables[0],columns)

            else:
                if bool(lyftpage_clause) and bool(where_clause):
                    try:
                        if (lyftpage_clause.get('lyftpagestart', None) is not None):
                            from_page = lyftpage_clause['lyftpagestart']
                            from_page = int(from_page)
                            
                        if lyftpage_clause.get('lyftpageend', None) is not None:
                            to_page = lyftpage_clause['lyftpageend']
                            to_page = int(to_page)
                            
                        return __execute(
                            tables[0],
                            list(where_clause.keys()), 
                            list(where_clause.values()), 
                            from_page, 
                            to_page, 
                            limit = limit
                        )
                    except Exception as e:
                        status = {
                            "Status": f"Failed! {str(e)}",
                            "Exceuted query" : f'[{query}]'
                        } 
                        self.payasyougo_check(self.execute_query,status)
                        return False, str(e)       
                elif bool(lyftpage_clause):
                    try:
                        if (lyftpage_clause.get('lyftpagestart', None) is not None):
                            from_page = lyftpage_clause['lyftpagestart']
                            from_page = int(from_page)
                            
                        if lyftpage_clause.get('lyftpageend', None) is not None:
                            to_page = lyftpage_clause['lyftpageend']
                            to_page = int(to_page)

                        return __execute(
                            tables[0],
                            list(), 
                            list(),
                            from_page, 
                            to_page, 
                            limit = limit
                        )
                    except Exception as e:
                        status = {
                            "Status": f"Failed! {str(e)}",
                            "Exceuted query" : f'[{query}]'
                        }
                        self.payasyougo_check(self.execute_query,status)
                        return False, str(e)              
                elif bool(where_clause):
                    return __execute(
                        tables[0],
                        list(where_clause.keys()), 
                        list(where_clause.values()), 
                        limit = limit
                    )
                else:
                    return __execute(tables[0],list(), list(), limit = limit)
                
    def sysQueries(self,query,table):
        """
        Description:
            System Queries Method is used to fetch information schema from the system query.
                following are tableName:
                    (sys.table, sys.contraint, sys.delta, sys.methods, sys.logs, sys.usage, sys.license
                    sys.connectionstring, sys.version)
        Parameters:
            query: System table name.
        """

        qury = query.split(".")
        command = qury[1]
        jsn = pd.read_json(self.schema_path, orient="records", typ="records")

        if command == "tables":
            tablenames = jsn['Tables'].keys()
            tables = []
            tablestype = []
            for i in tablenames:
                tables.append(i)
                tablestype.append(jsn['Tables'][i]['datatype'])
            df = pd.DataFrame(tables, columns=["TableName"])
            df["DataType"] = tablestype
            return df

        elif command == "constraints":

            tables = []
            fk = []
            pk = []
            colname = []
            tablenames = jsn['Tables'].keys()

            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            tables.append(i)
                            colname.append(col['column'])
                            if col['constraint'].__contains__("PRIMARY"):
                                fk.append("NULL")
                                pk.append(col['constraint'])
                            else :
                                fk.append(col['constraint'])
                                pk.append("NULL")

            df = pd.DataFrame(tables, columns=["TableName"])

            df["PrimayKey"] = pk
            df["ForeignKey"] = fk
            df["ColumnName"] = colname
            return df
        
        elif command == 'columns':
            data = list()
            schema_respone = self.__get_updated_schema(tables=True,views=True)
            for table,table_meta in schema_respone.items():
                for i in table_meta["columns"]:
                    data.append({"TableName":table,
                                "ColumnName":i['column'],
                                "dtype":i['datatype']
                                }
                    )
            return pd.DataFrame(data)
            
        elif command == "methods":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic['MethodName'] = i
                dic["return"] = jsn['Methods'][i]['return']
                dic["returntype"] = jsn['Methods'][i]['returntype']
                dic["description"] = jsn['Methods'][i]['description']
                para = jsn['Methods'][i]['parameters']
                dic["parameters"] =str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "logs":
            col = ["Logs"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "delta":
            jsn = pd.read_json(self.schema_path, orient="records", typ="records")
            tables = []
            deltafield = []

            tablenames = jsn['Tables'].keys()
            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            if col['constraint'].__contains__("PRIMARY"):
                                tables.append(i)
                                deltafield.append(col['column'])
            df = pd.DataFrame(tables, columns=["tablename"])
            df["DeltaField"] = deltafield
            return df

        elif command == "connectionstring":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic["Target"] = i
                para = jsn['Methods'][i]['parameters']
                dic["ConnectinParameters"] =  str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "version":
            return pd.DataFrame({'ConnectorVersion' : [self.CONNECTOR_VERSION]})

        elif command == "limit":
            return pd.DataFrame({'ApiLimit' : [self.API_LIMIT]})

        elif command == "usage":
            #[licensekey	remaining_time	total_allowed_time	total_time_spent	start_time	end_time	total_time_taken	rows_allowed	rows_fetched	month	machine_name	mac	ip)
            col = ["Total Time Spent ", "Remaining Time", " Total Time alloted"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "license":
            col = ["LicenseKey", "ActivateDate", "ExpireDate", "Total Time Spent", "Remaining Time"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col,index=None)

        elif command == "pages":
            data = list()

            endpoint = self.endpoints.get('endpoints')
            for i in endpoint:
                try:
                    response = self.fetchDataFromAPI(i)
                    result = self.json_parse(response,i)
                    data.append({"Table":i,"TotalPages":int(len(result[i])/30)})
                except Exception as e:
                    data.append({"Table":i,"TotalPages":"No pagination"})
                    
            return pd.DataFrame(data)

        elif command == 'Describe':
            tables = jsn['Tables'][table]
            data = []
            constraints = []
            pk = ""
            fk = ""
            Statement = 'CREATE TABLE '+ table+'('
            for i in tables['columns']:
                Statement = Statement+i['column']+" "+i['datatype']+",\n"
                if i['constraint'].__contains__("PRIMARY"):
                    pk = "PRIMARY KEY ("+i['column']+"),\n"
                elif i['constraint'].__contains__("FOREIGN "):
                    fk = i['constraint']
                else:
                    pass
            describedtable = Statement[:-2]+",\n"+pk+fk+');'

            return describedtable
        
        else:
            return pd.DataFrame({'Error' : ["INVALID SYS QUERY"]})

    def dataToTable(self,results,table,query=None):
        """
        Description:
            This Method is used to convert the Given Dataframe into SQL Table
        Parameters:
            results(pandas.DataFrame): dataframe which have to be convert into SQL TABLE .
            table(string) : Name of the DataFrame.
            query(string): Query to get the Specific data from the given dataframe.
        """

        if 'index' in results.columns:
            results = results.drop(['index'], axis=1)
        d = results.to_sql(table, con=engine, if_exists='replace')

    ##########################################################################
    ####                          UTILITIES                               ####
    ##########################################################################

    def scheduler_task(self,data, rows, file_name=""):
        """
        Description:
            This Method is used to Schedule the task for given data.
        Parameters:
            rows(int): number of rows each schedule data have.
            data(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """

        self.StartTime = time.time()

        # assuming.......data's type is pandas framework.......
        global END, START, STOP
        START = 0
        END = START + rows

        if END > len(data):
            END = len(data)
            STOP = 1

        print(data.iloc[START: END])
        START += rows
        try:
            if len(file_name) > 1:
                data.to_csv(file_name)
            else:
                print('')
                print(data)
            status = {'Status': "Success! Task Scheduled"}
        except Exception as e:
            status = {'Status': f"Failed! {str(e)}"}
        self.payasyougo_check(self.scheduler_task,status)

    def schedule_data(self,sec, rows, df,filename):
        """
        Description:
            This Method is used to Schedule the data for given amount of time.
        Parameters:
            sec(int): Seconds for data to schedule again.
            rows(int): number of rows each schedule data have.
            df(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """
        self.StartTime = time.time()
        print("Total rows : ", len(df))
        schedule.every(sec).seconds.do(
            lambda: self.scheduler_task(data=df, rows=rows, file_name=filename))  # file_name is optional

        while True:
            schedule.run_pending()
            if STOP:
                schedule.clear()
                break

        status = {'Status': "Success"}
        self.payasyougo_check(self.schedule_data,status)

    def connectEngine(self,username, password, server, database, tableName, df):
        """
        Description:
            This Method is used to Connect user with Databases using sql Alchemy and upload the dataframe.

        Parameters:
            username(string): database username.
            password(string): password of the database.
            server(string): server address of the database.
            database(string): Database name.
            tableName(string): Name of table you have to upload.
            df(pandas.DataFrame): Dataframe of the table which have to be upload.

        """
        self.StartTime = time.time()
        alchemyEngine = create_engine(
        f"postgresql+psycopg2://"+username+":"+password+"@"+server+"/"+database+", pool_recycle=3600")

        try:
            con = alchemyEngine.connect()
            df.to_sql(
                tableName, con, if_exists='replace')
            con.close()
            print("Data uploaded to table "+tableName)
            status = {'Status':"Success!",
                "Connection String":f'(postgresql+psycopg2://{username}:{password}@{server}/{database})'}

        except Exception as e:
            print (getattr(e, 'message', repr(e)))
            status = {
                'Status':'failed!',
                'error': str(e)
                }
        self.payasyougo_check(self.connectEngine,status)

    def Pagination(self,data, number_of_page=0):

        """
        Description:
            This Method is used to Perform pagination on the responses.
        Parameters:
            data(pandas.DataFrame): Response of in form of dataFrame
            Number_of_page: Number of pages data split into.

        """

        self.StartTime = time.time()
        per_page = 0
        total_page = 0

        if number_of_page > 0:
            per_page = math.ceil(len(data) / number_of_page)
            total_page = number_of_page
        count = 1
        print("Enter page number to show its data. \n")
        while True:
            print(data.iloc[((count - 1) * per_page): (count * per_page)])
            print("Showing page : ", count, " / ", total_page,"\n")
            key = input("Press 'A' or 'D' to navigate or jump to page no: ")
            if (key.isdigit()):
                page = int(key)
                if page > total_page:
                    print('Page doesnot exist')
                else:
                    count = page
            elif(key.lower() in ['a','d']):
                lower = key.lower()
                if lower == 'a':
                    if count > 1:
                        count -= 1
                elif lower == 'd':
                    if count < total_page:
                        count += 1
            else:
                print("Invalid page number")
                
            status = {'Status':"Success!",
                    'Page Number': number_of_page,
                    'data': data}
            self.payasyougo_check(self.Pagination,status)

    def payasyougo_check(self,method,status: str) -> None:

        try:
            pg.measure_execution_time(
                LicenseKey= self.LicenseKey,
                Function = method,
                StartTime = self.StartTime,
                EndTime = time.time(),
                connectername=Connector_name,
                status=status,
                logging=self.logging_options,
                log_connection=self.log_connection)
            self.log_connection = False
        except Exception as e:
            if self.__environment != 'development':
                raise Exception("Server Error - contact help@lyftrondata.com")