

"""
    # USER NOTE
    "Connection Type" :{
        "your parameter " : "connector parameter "
    }
"""
MAPPING = {
    "basicauth": {
        "username": "username",
        "password": "password",
        "source_api_key": "source_api_key",  # HARDCODED
        "source_ip": "source_ip",  # USR SOURCE IP
        "target_ip": "target_ip",
        "port": "port",
        "org_id": "org_id",
        "site_id": "site_id",
        "itemset_id": "itemset_id"

    }
}
