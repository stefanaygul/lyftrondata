import re
import time

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy import inspect

from Lyftrondata.Snowflake.config.config import CONNECTION_KEY_MAPPING
from Lyftrondata import payasyougo as pg
import json


engine = create_engine('sqlite://')
engines = [['PostgreSQL','postgresql://scott:tiger@localhost/mydatabase'],['Sql Server','mssql+pyodbc://scott:tiger@mydsn'],['Oracle','oracle://scott:tiger@127.0.0.1:1521/sidname'],['MySQL','mysql://scott:tiger@localhost/foo'],['SQLite','sqlite:///foo.db']]
supportedEngines = pd.DataFrame(columns=['Engine Name','Example Connection'],data=engines,index=None)

class Connect:
    license_key = ""
    connector_name = "Lyftrondata_Snowflake_Connector"
    logging = False
    logs_attenuation = 0
    logging_options = False
    log_connection = True
    __environment = 'development'
    StartTime = time.time()

    def __init__(self, license_key):
        self.license_key = license_key

    def dict_mapping(jsn, connection_type):
        from Lyftrondata.Snowflake.config import mapping
        
        mapping = mapping.MAPPING[connection_type]
        for m in mapping.keys():
            if jsn.get(m) is not None:
                jsn[mapping[m]] = jsn.pop(m)
        return jsn

    def initializeJson(self,creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'
        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            EndTime = time.time()
            status = {
                'Status':'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.initializeJson, status)
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : self.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : self.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : self.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : self.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : self.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : self.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : self.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : self.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : self.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : self.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : self.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : self.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : self.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "environment" : self.dict_mapping(init_jsn,connection_type).get('environment'),
            "logs_attenuation" : self.dict_mapping(init_jsn,connection_type).get('logs_attenuation') or init_jsn.get('logs_attenuation') or 0,
            "logging" : self.dict_mapping(init_jsn,connection_type).get('logging') or init_jsn.get('logging') or False

        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            status = f'Connection Successful!! \t Connection String ({str(init_jsn)})'
            EndTime = time.time()
            self.payasyougo_check(self.initializeJson,status)
            return init

        except Exception as e:
            status = f'Failed! \t Error ({str(e)}) '
            EndTime = time.time()
            self.payasyougo_check(self.initializeJson,status)
            raise Exception(e)

    def initialize(self, logging=False , logs_attenuation = 0,**credentials):
        """This method will validate database credentials and return sqlalchemy engine

        :param credentials: json object containing all information for database connection
        (host,port, username, c and database name)
        :return: tuple containing True/False and sqlalchemy engine object
        """
        self.logging = logging
        self.logs_attenuation = logs_attenuation
        try:
            start_time = time.time()

            account = credentials[CONNECTION_KEY_MAPPING[2]['lyftron_key']].split("//")[1].split(".snowflakecomputing")[0]
            connection_string = f"snowflake://{credentials[CONNECTION_KEY_MAPPING[0]['lyftron_key']]}:" \
                                f"{credentials[CONNECTION_KEY_MAPPING[1]['lyftron_key']]}" \
                                f"@{account}/{credentials[CONNECTION_KEY_MAPPING[3]['lyftron_key']]}/" \
                                f"{credentials[CONNECTION_KEY_MAPPING[4]['lyftron_key']]}?warehouse=" \
                                f"{credentials[CONNECTION_KEY_MAPPING[5]['lyftron_key']]}&role=" \
                                f"{credentials[CONNECTION_KEY_MAPPING[6]['lyftron_key']]}"
            
            engine = create_engine(connection_string)

            end_time = time.time()
            status = {
                'Status':'Success!'
            }
            self.payasyougo_check(self.initialize, status)
            return True, engine
        except KeyError as e:
            end_time = time.time()
            status = {
                'Status':'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.initialize, status)
            return False, f'Missing following key in credentials json: {str(e)}'
        except Exception as err:
            end_time = time.time()
            status = {
                'Status':'Failed!',
                'Error': str(err)
            }
            self.payasyougo_check(self.initialize, status)
            return False, str(err)

    def test_connection(self, engine_obj):
        """This method will connect to database

        :param engine_obj: sqlAlchemy engine object
        :return: tuple containing True/False at zero index and empty/error string at first index
        """
        try:
            start_time = time.time()

            engine_obj.connect()

            end_time = time.time()
            status = {
                'Status':'Success!'
            }
            # self.payasyougo_check(self.test_connection, status)
            return True, ''
        except Exception as e:
            end_time = time.time()
            status = {
                'Status':'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.test_connection,status)
            return False, str(e)
    
    def json_parse(self,jsn, main_table_name):

        """
        Description:
            This method is used to parse/Normalize the Json Response fetched from endpoint in a way where
            object and array will be consider as separate Dataframes.

        Parameters:
            jsn(json): json response which have to be normalize.
            main_table_name: Main endpoint Name where the response is fetched from.

        Return:
            dataframes(dict) : dictionary which contains all the key as tablename and value as Dataframes.
        """
        dataframe = None
        simple = dict()
        dataFrames = dict()
        for key in jsn:
            val = jsn[key]
            if type(val) == list:
                dataFrames[key] = pd.DataFrame(val)
            elif type(val) == dict:
                dataframe = pd.DataFrame.from_dict(
                    val, orient="index")
                dataFrames[key] = dataframe.transpose()
            else:
                simple[key] = val
        if not simple:
            return dataFrames
        else:
            datafr = pd.DataFrame.from_dict(simple,orient="index")
            dataFrames[main_table_name] =datafr.transpose()
            return dataFrames

    def fetchDataFromAPI(self,table,engine_obj=None):
        """
        Description:
            This Method is used to fetch data from API specific Table.
            
        Parameters:
            table(string): table name.
            engine_obj: sqlalchemy engine object
        
        Returns:
            jsn(json) : json file contains the complete response fetched from endpoint 
        """
        response_json = ""
        response_list = list()
        try:
            query = f"select * from {table}"
            query_result = engine_obj.execute(query)
            column_names = list(query_result.keys())

            if query_result.rowcount > 0:
                response = query_result.fetchall()

                for each_record in response:
                    response_dict = dict(zip(column_names, each_record))
                    response_list.append(response_dict)

                response_json = {table:response_list}

            return response_json

        except Exception as err:
            return False, str(err)

    def execute_query(self,query,engine_obj=None):
        """This method will execute given query on provided sqlalchemy connection and will return its response

        :param engine_obj: sqlalchemy engine object
        :param query: query string
        :return: tuple containing True/False at zero index and dataframe/error string at first index
        """
        try:
            query_result = engine_obj.execute(query)
            query_result_keys = list(query_result.keys())
            if query_result.rowcount > 0:
                query_result = query_result.fetchall()
                df = pd.DataFrame(query_result, columns=query_result_keys)
                return True, df
            else:
                return True, 0
        except Exception as err:
            return False, str(err)

    def dataToTable(self,results,table,query=None):
        """
        Description:
            This Method is used to convert the Given Dataframe into SQL Table
        Parameters:
            results(pandas.DataFrame): dataframe which have to be convert into SQL TABLE .
            table(string) : Name of the DataFrame.
            query(string): Query to get the Specific data from the given dataframe.
        """

        if 'index' in results.columns:
            results = results.drop(['index'], axis=1)
        d = results.to_sql(table, con=engine, if_exists='replace')

    def get_schema_list(self, engine_obj):
        """This method will return list of all schema in given sql alchemy engine object

        :param engine_obj: sqlalchemy engine object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        try:
            inspector = inspect(engine_obj)
            schemas = inspector.get_schema_names()
            return True, schemas
        except Exception as err:
            return False, str(err)

    def get_schema_objects(self, engine_obj, schema_and_object_list):
        """This method will return list of all objects in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema
        :return: tuple containing True/False at zero index and list of schema tables at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema name in array"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"
                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        [response_data[schema_and_object_dict["schema_name"]][schema_object].append(table_name) for
                         table_name in schema_table_list]
                    elif schema_object == "VIEW":
                        # Get list of all views for schema and append in response dict
                        schema_table_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        [response_data[schema_and_object_dict["schema_name"]][schema_object].append(view_name) for
                         view_name in schema_table_list]
            return True, response_data
        except Exception as err:
            return False, str(err)

    def get_object_columns(self, engine_obj, schema_and_object_list,read_json=None):
        """This method will return lst of columns in given schema objects

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    object_key = list(schema_object.keys())[0]
                    response_data[schema_and_object_dict["schema_name"]][object_key] = []

                    if object_key == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if not column["comment"]:
                                    description = ""
                                else:
                                    description = column["comment"]
                                if column["name"].islower():
                                    column["name"] = column["name"].upper()
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][table_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]),
                                        "description": description,
                                    })
                    elif object_key == "VIEW":
                        schema_view_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if not column["comment"]:
                                    description = ""
                                else:
                                    description = column["comment"]
                                if column["name"].islower():
                                    column["name"] = column["name"].upper()
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]),
                                        "description": description,
                                    })
                    # elif object_key == "INDEX":
                    #     schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                    #     for table_name in schema_table_list:
                    #         schema_index_list = inspector.get_indexes(table_name)
                    #         [
                    #             response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                    #                 index_name["name"]
                    #             )
                    #             for index_name in schema_index_list
                    #         ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def get_schema_object_and_columns(self, engine_obj, schema_and_object_list):
        """This method will return lst of all tables in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            if table_name.islower():
                                table_name = table_name.upper()
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {table_name: {"columns": []}}
                            )

                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            if table_name.islower():
                                table_name = table_name.upper()
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if not column["comment"]:
                                    description = ""
                                else:
                                    description = column["comment"]
                                if column["name"].islower():
                                    column["name"] = column["name"].upper()
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][table_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]),
                                        "description": description,
                                    })
                    elif schema_object == "VIEW":
                        schema_view_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        for view_name in schema_view_list:
                            if view_name.islower():
                                view_name = view_name.upper()
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {view_name: {"columns": []}}
                            )

                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            if view_name.islower():
                                view_name = view_name.upper()
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if not column["comment"]:
                                    description = ""
                                else:
                                    description = column["comment"]
                                if column["name"].islower():
                                    column["name"] = column["name"].upper()
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]),
                                        "description": description,
                                    })
                    elif schema_object == "INDEX":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = inspector.get_indexes(table_name)
                            [
                                response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                    index_name["name"]
                                )
                                for index_name in schema_index_list
                            ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)
            
    def payasyougo_check(self,method,status):
        try:
            pg.measure_execution_time(
                LicenseKey=  self.license_key,
                Function = method,
                StartTime = self.StartTime,
                EndTime = time.time(),
                connectername=self.connector_name,
                status=status,
                logging=self.logging_options,
                log_connection=self.log_connection)
            self.log_connection = False
        except Exception as e:
         
            if self.__environment != 'development':
                raise Exception("Server Error - contact help@lyftrondata.com")
