CONFIG = {
    'MODE': 0, # 0 is test mode
    'SOURCE_NAME': 'pgsql',
    'SERVER_NAME': 'postgresdb',
    'PACKAGES': 'sudo su && sudo python3 -m venv venv && sudo source venv/bin/activate && sudo pip install kafka-python==2.0.2 && sudo pip install schedule==1.1.0 && sudo pip install requests==2.22.0',
    'INTEGRATION_TARGET_FORMAT': 'snowflake',
    'INTEGRATION_TARGET_MODE': 'append',
    'INTEGRATION_TARGET_TYPE': 'write',
    'INTEGRATION_TARGET_SERVER_DEV' : 'http://192.168.191.95:5001/create_dag',
    'INTEGRATION_TARGET_SERVER_PROD': 'http://192.168.191.141:5001/create_dag',
    'LOG_FILE_BASE_PATH': '/home/ubuntu/kafka_logs'
}

BIGQUERY = 'bigquery'
SNOWFLAKE = 'snowflake'
JDBC = 'jdbc'
SQLALCHEMY = 'sqlalchemy'

CONNECTION_KEY_MAPPING = [
    {
        "lyftron_key": "username",
        "jdbc_key": "username"
    },
    {
        "lyftron_key": "password",
        "jdbc_key": "password"
    },
    {
        "lyftron_key": "hostname",
        "jdbc_key": "host"
    },
    {
        "lyftron_key": "port",
        "jdbc_key": "port"
    },
    {
        "lyftron_key": "database",
        "jdbc_key": "database"
    }
]
SQLAlchemy_CONN_STRING = f"enginename://username:password@hostname:port/database"