from sqlalchemy import create_engine
import sqlalchemy as sa
import pandas as pd
import time
import os
import json
import paramiko
import logging  as logs
from datetime import datetime
from sqlalchemy import inspect

from Lyftrondata.KafkaPostgreSQL.lib import Lyftrondata_KafkaPostgreSQL_utils as utils
from Lyftrondata.KafkaPostgreSQL.config.config import BIGQUERY
from Lyftrondata.KafkaPostgreSQL.config.config import CONFIG
from Lyftrondata.KafkaPostgreSQL.config.config import CONNECTION_KEY_MAPPING
from Lyftrondata import payasyougo as pg

global Connector_name
Connector_name = "Lyftrondata_KafkaPostgreSQL"

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

data = []
gs = None
dt = None
lookUp = None
engine = create_engine('sqlite://')
engines = [['PostgreSQL', 'postgresql://scott:tiger@localhost/mydatabase'], ['Sql Server', 'mssql+pyodbc://scott:tiger@mydsn'],
           ['Oracle', 'oracle://scott:tiger@127.0.0.1:1521/sidname'], ['MySQL', 'mysql://scott:tiger@localhost/foo'], ['SQLite', 'sqlite:///foo.db']]
supportedEngines = pd.DataFrame(columns=['Engine Name', 'Example Connection'], data=engines, index=None)

##########################################################################
####   CONNECTIONS DATA PARSER FETCH DATA    ####
##########################################################################


class Connect:
    ##########################################################################
    #####   ALL CLASS VARIABLES    ####
    ##########################################################################

    dirname = os.path.dirname(__file__)
    logPath = os.path.join(dirname, '../config/topicSync')
    logFileName = f"{datetime.utcnow().strftime('%Y%m%d')}.log"
    logs.basicConfig(filename=f"{logPath}/logs.log", level=logs.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
    endpoints = dict()
    license_key = ""
    logging = False
    connector_name = "Lyftrondata_KafkaPostgreSQL"
    logs_attenuation = 0

    # CALLOUT PARAMS
    StartTime = time.time()
    CONNECTOR_VERSION = '0.0.1'
    API_LIMIT = 100
    worker = 10
    req_resp = None
    is_auto = False
    code = None
    __environment = '' # don't edit it here
    timeout = 120
    view = False
    headers = {'Content-Type': 'application/json'}

    # AUTH PARAMS
    token = None
    expired_time = None
    fetched_time = None
    client_id = None
    client_secret = None
    refresh_token = None
    refreshtoken_url = ""
    base_url = "BASE_URL"
    auth_url = ""
    token_url = ""
    scope = ""
    subdomain = ""

    # LOG PARAMS
    logging_options = False
    log_connection = True

    # MAKE ALL OAUTH CUSTOM SETTING HERE
    oauth_settings = {
        "auth_url": auth_url,
        "token_url": token_url,
        "auth_params": {'response_type': 'code', 'access_type': 'offline', 'prompt': 'consent'},
        "token_params": {'grant_type': 'authorization_code'},
        "token_headers": None,
        "token_data": None,  # set to None if no token data is required
    }

    authhandler = utils.Lyftrondata_authHandler()

    ##########################################################################
    #####   INITS    ####
    ##########################################################################

    def __init__(self, LicenseKey):
        self.LicenseKey = LicenseKey
        self.abs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ''))
        # self.schema_path = f'{self.abs_path}/schema/{Connector_name}.json'
        self.endpointjson = f'{self.abs_path}/config/{Connector_name}_Connector_endpoints.json'

        # with open(self.endpointjson, "r") as readEndpoints:
        #     self.endpoints = json.load(readEndpoints)
        # with open(self.schema_path, "r") as schema:
        #     self.schema_json = json.loads(schema.read())

    def get_schema_list(self, engine_obj):
        """This method will return list of all schema in given sql alchemy engine object

        :param engine_obj: sqlalchemy engine object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        try:
            inspector = inspect(engine_obj)
            schemas = inspector.get_schema_names()
            return True, schemas
        except Exception as err:
            return False, str(err)

    def get_schema_objects(self, engine_obj, schema_and_object_list):
        """This method will return list of all tables in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}
                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"
                
                for schema_object in schema_and_object_dict["object_list"]:
                    # print(schema_and_object_dict["schema_name"])
                    # exit()
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []
                    
                    if schema_object == "TABLE":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(table_name)
                    elif schema_object == "VIEW":
                        schema_view_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        for view_name in schema_view_list:
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(view_name)
                    elif schema_object == "INDEX":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = inspector.get_indexes(table_name)
                            for index_name in schema_index_list:
                                response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                    index_name["name"])
            return True, response_data
        except Exception as err:
            return False, str(err)
    
    def get_object_columns(self, engine_obj, schema_and_object_list, read_json=False):
        """This method will return lst of columns in given schema objects

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    object_key = list(schema_object.keys())[0]
                    response_data[schema_and_object_dict["schema_name"]][object_key] = []

                    if object_key == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][table_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    elif object_key == "VIEW":
                        schema_view_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    # elif object_key == "INDEX":
                    #     schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                    #     for table_name in schema_table_list:
                    #         schema_index_list = inspector.get_indexes(table_name)
                    #         [
                    #             response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                    #                 index_name["name"]
                    #             )
                    #             for index_name in schema_index_list
                    #         ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def get_schema_object_and_columns(self, engine_obj, schema_and_object_list):
        """This method will return lst of all tables in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][table_name]["columns"].append({
                                    "column": column["name"],
                                    "datatype": str(column["type"]).split("(")[0],
                                    "description": str(description)
                                })
                    elif schema_object == "VIEW":
                        schema_view_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    elif schema_object == "INDEX":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = inspector.get_indexes(table_name)
                            [
                                response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                    index_name["name"]
                                )
                                for index_name in schema_index_list
                            ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def test_connection(self, engine_obj, read_json = False):
        """This method will connect to database

        :param engine_obj: sqlAlchemy engine object
        :return: tuple containing True/False at zero index and empty/error string at first index
        """
        start_time = time.time()

        try:
            engine_obj.connect()

            end_time = time.time()
            status = {
                "Status": "Success",
            }
            self.payasyougo_check(start_time, end_time, self.test_connection, status)
            return True, ''
        except Exception as e:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(e)
            }
            self.payasyougo_check(start_time, end_time, self.test_connection, status)
            return False, str(e)

    def initializeJson(self, creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        self.StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'

        try:
            with open(creds, 'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            status = {
                'Connection String': '',
                'Status': f'Failed! {str(e)}'
            }

            self.payasyougo_check(self.initialize, str(e))
            raise (e)
        connection_type = init_jsn.get('connection_type')

        init_params = {
            "access_key_id": utils.dict_mapping(init_jsn, connection_type).get('access_key_id'),
            "secret_access_key": utils.dict_mapping(init_jsn, connection_type).get('secret_access_key'),
            "region_name": utils.dict_mapping(init_jsn, connection_type).get('region_name'),
            "bucket": utils.dict_mapping(init_jsn, connection_type).get('bucket'),
            "lyft_token_email": utils.dict_mapping(init_jsn, connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate": utils.dict_mapping(init_jsn, connection_type).get('aggregate'),
            "username": utils.dict_mapping(init_jsn, connection_type).get('username'),
            "password": utils.dict_mapping(init_jsn, connection_type).get('password'),
            "personal_token": utils.dict_mapping(init_jsn, connection_type).get('personal_token'),
            "subdomain": utils.dict_mapping(init_jsn, connection_type).get('subdomain'),
            "client_id": utils.dict_mapping(init_jsn, connection_type).get('client_id'),
            "client_secret": utils.dict_mapping(init_jsn, connection_type).get('client_secret'),
            "redirect_uri": utils.dict_mapping(init_jsn, connection_type).get('redirect_uri'),
            "is_auto": utils.dict_mapping(init_jsn, connection_type).get('is_auto') or False,
            "logging_options": utils.dict_mapping(init_jsn, connection_type).get('logging_options') or init_jsn.get('logging_options') or False
        }

        try:

            init = self.initialize(connection_type=connection_type, **init_params)
            status = {
                'Connection String': init_params,
                'Status': 'Success!'
            }
            self.payasyougo_check(self.initializeJson, status)
            return init

        except Exception as e:
            status = {
                'Connection String': init_params,
                'Status': f'Failed! {str(e)}'
            }

            self.payasyougo_check(self.initializeJson, status)

            raise Exception(e)

    def initialize(self, logging=False, logs_attenuation = 0, **sourceCreds):

        """This method will validate database credentials and retrun sqlalchemy engine

        :param credentials: json object containing all information for database connection
        (host,port, username, password and database name)
        :return: tuple containing True/False and sqlalchemy engine object
        """
        start_time = time.time()
        self.logging = logging
        self.logs_attenuation = logs_attenuation

        username = sourceCreds[CONNECTION_KEY_MAPPING[0]['lyftron_key']]
        password = sourceCreds[CONNECTION_KEY_MAPPING[1]['lyftron_key']]
        host = sourceCreds[CONNECTION_KEY_MAPPING[2]['lyftron_key']]
        port = sourceCreds[CONNECTION_KEY_MAPPING[3]['lyftron_key']]
        database = sourceCreds[CONNECTION_KEY_MAPPING[4]['lyftron_key']]

        try:
            connection_string = f"postgresql://{username}:{password}@{host}:{port}/{database}"

            engine_obj = sa.create_engine(connection_string)

            end_time = time.time()
            status = {
                "Status": "Success"
            }
            
            logs.info(f"connection to db created with user:{username} password:{password.translate('*'*256)} host:{host}")
            self.payasyougo_check(start_time, end_time, self.initialize, status)

            return True, engine_obj
        except KeyError as key_err:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(key_err)
            }
            self.payasyougo_check(start_time, end_time, self.initialize, status)
            return False, f"Missing following key in credential json: {key_err}"
        except Exception as e:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(e)
            }
            self.payasyougo_check(start_time, end_time, self.initialize, status)
            return False, str(e)

    def execute_query(self, query, engine_obj):
        """This method will execute given query on provided sqlalchemy connection and will return its response

        :param engine_obj: sqlalchemy engine object
        :param query: query string
        :return: tuple containing True/False at zero index and dataframe/error string at first index
        """
        try:
            query_result = engine_obj.execute(query)
            if query_result.rowcount == -1:
                return True, 'Operation performed successfully'
            query_result_keys = list(query_result.keys())
            if query_result.rowcount != 0:
                query_result = query_result.fetchall()
                if len(query_result):
                    df = pd.DataFrame(query_result, columns=query_result_keys)
                    return True, df
                else:
                    return True, 0
            else:
                return True, 0
        except Exception as err:
            return False, str(err)

    def payasyougo_check(self, StartTime, EndTime, method,status):
        
        try:
            pg.measure_execution_time(
                self.LicenseKey, method, StartTime, EndTime, self.connector_name,status,logging=self.logging, log_connection= self.logs_attenuation)
        
        except Exception as e:
            raise Exception("Server Error - contact help@lyftrondata.com")

    def kafkaRead(
        self,
        ssh,
        sourceCreds,
        targetCreds,
        schema,
        tables,
        targetFormat = CONFIG['INTEGRATION_TARGET_FORMAT'],
        tagetMode = CONFIG['INTEGRATION_TARGET_MODE'],
        targetType = CONFIG['INTEGRATION_TARGET_TYPE'],
        isDevMode = CONFIG['MODE']):

        self.logsDirectory = f"{ssh['defaultDirectory']}/{ssh['logsPath']}"
        self.targetFormat = targetFormat
        self.tagetMode = tagetMode
        self.targetType = targetType
        self.isDevMode = isDevMode

        self.targetCreds = targetCreds
        self.tables = tables

        self.username = sourceCreds[CONNECTION_KEY_MAPPING[0]['lyftron_key']]
        self.password = sourceCreds[CONNECTION_KEY_MAPPING[1]['lyftron_key']]
        self.host = sourceCreds[CONNECTION_KEY_MAPPING[2]['lyftron_key']]
        self.port = sourceCreds[CONNECTION_KEY_MAPPING[3]['lyftron_key']]
        self.database = sourceCreds[CONNECTION_KEY_MAPPING[4]['lyftron_key']]
        self.schema = schema

        host = ssh['host']
        username = ssh['username']
        password = ssh['password']
        directory = ssh['defaultDirectory']
        connectorPath = ssh['connectorPath']

        topicDir = f"{directory}/connectors/{connectorPath}"
        ssh = self.sshInit(host, username, password)
        self.appendCred(ssh, topicDir)

        ssh.exec_command("cd " + topicDir + " && " + CONFIG['PACKAGES'])
        ssh.exec_command("cd " + topicDir + " && sudo python3 ./connector.py")
        ssh.close()

        ssh = self.sshInit(host, username, password)
        ssh.exec_command("cd " + topicDir +" && sudo python3 ./main.py")
        ssh.close()

        ssh = self.sshInit(host, username, password)
        ssh.exec_command("cd " + topicDir + "/jobs && sudo python3 ./tasksScheduler.py")
        ssh.close()

        with open(os.path.join(self.dirname, f'../config/topicSync/logs.log'), 'w+') as file:
            file.write('')

    def fileRead(self, file):
        with open(file) as data:
            fileData = data.read()
        return fileData

    def appendCred(self, ssh, topicDir):
        serverName = CONFIG['SERVER_NAME']
        logFilesPath = f"{self.logsDirectory}/{CONFIG['SOURCE_NAME']}/{self.username}@{self.host}"
        connectorTables = ''
        topics = []
        for table in self.tables:
            connectorTables += self.schema + '.' + table + ','
            topics.append(serverName + '.' + self.schema + '.' + table)

        # Connector file
        connectorFile = os.path.join(self.dirname, '../config/topicSync/connector.py')
        connectorFileData = self.fileRead(connectorFile)

        connectorFileData = connectorFileData.replace("@@connectorName@@", CONFIG['SOURCE_NAME'] + "-" + self.database + "-" + self.schema)
        connectorFileData = connectorFileData.replace("@@hostName@@", self.host)
        connectorFileData = connectorFileData.replace("@@port@@", self.port)
        connectorFileData = connectorFileData.replace("@@user@@", self.username)
        connectorFileData = connectorFileData.replace("@@password@@", self.password)
        connectorFileData = connectorFileData.replace("@@dbName@@", self.database)
        connectorFileData = connectorFileData.replace("@@serverName@@", serverName)
        connectorFileData = connectorFileData.replace("@@schema@@", self.schema)
        connectorFileData = connectorFileData.replace("@@tables@@", connectorTables)
        connectorFileData = connectorFileData.replace("@@logFilesPath@@", logFilesPath)

        self.putFile(ssh, topicDir, 'connector.py', connectorFileData)

        # Main file
        mainFile = os.path.join(self.dirname, '../config/topicSync/main.py')
        mainFileData = self.fileRead(mainFile)

        mainFileData = mainFileData.replace("@@topics@@", str(topics))
        mainFileData = mainFileData.replace("@@logFilesPath@@", logFilesPath)
        
        self.putFile(ssh, topicDir, 'main.py', mainFileData)

        # dataSendToSparkJob file
        jobFile = os.path.join(self.dirname, '../config/topicSync/jobs/dataSendToSparkJob.py')
        jobFileData = self.fileRead(jobFile)

        jobFileData = jobFileData.replace("@@topics@@", str(topics))
        jobFileData = jobFileData.replace("@@targetCred@@", str(self.targetCreds))
        jobFileData = jobFileData.replace("@@format@@", self.targetFormat)
        jobFileData = jobFileData.replace("@@mode@@", self.tagetMode)
        jobFileData = jobFileData.replace("@@type@@", self.targetType)
        jobFileData = jobFileData.replace("@@sourceSchema@@", self.schema)
        jobFileData = jobFileData.replace("@@logFilesPath@@", logFilesPath)

        if(self.targetFormat == BIGQUERY):
            jobFileData = jobFileData.replace("@@targetSchema@@", '')
        else:
            jobFileData = jobFileData.replace("@@targetSchema@@", self.targetCreds['schema'])

        if(self.isDevMode == 0):
            jobFileData = jobFileData.replace("@@integrationTargetServerUrl@@", CONFIG['INTEGRATION_TARGET_SERVER_DEV'])
        else:
            jobFileData = jobFileData.replace("@@integrationTargetServerUrl@@", CONFIG['INTEGRATION_TARGET_SERVER_PROD'])

        self.putFile(ssh, topicDir+'/jobs', 'dataSendToSparkJob.py', jobFileData)

        # creating data folder
        self.putFile(ssh, topicDir+'/data')

        # creating tasksScheduler.py file
        tasksSchedulerFile = os.path.join(self.dirname, '../config/topicSync/jobs/tasksScheduler.py')
        tasksSchedulerFileData = self.fileRead(tasksSchedulerFile)
        self.putFile(ssh, topicDir+'/jobs', 'tasksScheduler.py', tasksSchedulerFileData)
        
        # log file
        logFile = os.path.join(self.dirname, f'../config/topicSync/logs.log')
        logFileData = self.fileRead(logFile)
        self.putFile(ssh, logFilesPath, self.logFileName, logFileData)
        
    def putFile(self, ssh, path, filename='', data=''):
        
        sftp = ssh.open_sftp()
        dir  = path.split("/")
        for index, signleDir in enumerate(dir):
            dirname = '/'.join(str(item) for item in dir[0:(index+1)])

            try:
                sftp.mkdir(dirname)
            except Exception as e:
                logs.info(e)
        
        if(filename != '' and data != ''):
            f = sftp.open(path + '/' + filename, 'w')
            f.write(data)
            f.close()
    
    def sshInit(self, server, username, password):

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(server, 22, username, password)
        return ssh