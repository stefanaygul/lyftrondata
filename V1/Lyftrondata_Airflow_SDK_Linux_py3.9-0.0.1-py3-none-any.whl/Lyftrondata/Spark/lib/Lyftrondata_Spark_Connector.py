# UTILITIES
import pandas as pd
import re
import boto3
import time
import pyspark
import os
import json
import datetime ,pytz, random  # libraries for time computation
import logging

#PYSPARK LIBRARY
from pyspark.sql import SparkSession
from pyspark.conf import SparkConf
from pyspark.sql.functions import lit
from pyspark.sql.types import *

# LYFTRONDATA LIBRARY
import Lyftrondata.Spark.lib.Spark_Utils as spu
# import Spark_Utils as spu

from Lyftrondata.Spark.config.mapping import SPARK_MAPPING
from Lyftrondata.Lyftrondata_Connector_Handler import Connect as Lyftrondata_Connector_Handler


class Connect:
    global Connector_name
    Connector_name = "Lyftrondata_Spark_Connector"
    LicenseKey = ""
    dirname = os.path.dirname(__file__)
    row_select = 0
    row_write = 0
    last_log_line = 0
    logging_options = dict()
    integration_id = ''
    pipeline_object = {}
    status = ""
    error_message = ""
    
    
    def __init__(self, licenseKey,**params):
        self.logging_options = params.get('logging_options',None)
        self.integration_id = params.get('integration_id',None)
        self.LicenseKey = licenseKey
        self.Connector_name = Connector_name
        self.lyftrondata_options = params.get('lyftrondata_options',None)
        
######################################
# Spark Essentials Methods
######################################



    def initialize(
        self, 
        appName: str,
        memory: str, 
        config: dict, 
        marquez_host: str = None, 
        marquez_api_port: str = None,
        namespace: str = "default",
        credsFile=None
    ) -> SparkSession:
        
        """Initialize your spark instant to be used with the flow. The instance
        will work with your provided config dict. SparkSession has been used to
        create a spark working instance.


        Args:
            appName (string): The name you want to give this app. E.g LyftrondataSpark.
            memory(string) : Amount of memory you want Spark to use. For e.g: 2g
            config (dict): See https://spark.apache.org/docs/latest/configuration.html for more.

        Returns:
            object: Your spark session.
        """
        
        spark_conf = SparkConf()
        self.returnDict = []
        self.credsFile = credsFile
        
        if marquez_host is not None:
            logging.info("Marquez settings detected. Creating config dicitonary:")
            
            config['spark.extraListeners'] = 'io.openlineage.spark.agent.OpenLineageSparkListener'
            config['spark.openlineage.url'] = f'http://{marquez_host}:{marquez_api_port}/api/v1/namespaces/{namespace}/'
            config['spark.openlineage.host'] = f'http://{marquez_host}:{marquez_api_port}'
            
            logging.info(config)
        # Override with any task specific configuration
        
        for (name, value) in config.items():
            spark_conf.set(name, value)

        spark = SparkSession \
            .builder \
            .master('local[*]') \
            .appName(appName) \
            .config("spark.driver.host", "localhost")\
            .config(conf=spark_conf) \
	        .config('spark.executor.memory', memory) \
            .config('spark.jars.packages', 'io.openlineage:openlineage-spark:0.18.+,org.postgresql:postgresql:42.5.0,com.vertica.jdbc:vertica-jdbc:10.1.1-0,com.oracle.database.jdbc:ojdbc11:21.5.0.0,net.snowflake:snowflake-jdbc:3.12.17,net.snowflake:spark-snowflake_2.12:2.8.4-spark_3.0,com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.22.0,com.google.cloud.bigdataoss:gcs-connector:hadoop3-1.9.5,com.google.guava:guava:31.1-jre') \
            .getOrCreate() if memory else \
            SparkSession \
            .builder \
            .appName(appName) \
            .config(conf=spark_conf) \
            .config('spark.jars.packages', 'io.openlineage:openlineage-spark:0.18.+,com.vertica.jdbc:vertica-jdbc:10.1.1-0,com.oracle.database.jdbc:ojdbc11:21.5.0.0,net.snowflake:snowflake-jdbc:3.12.17,net.snowflake:spark-snowflake_2.12:2.8.4-spark_3.0,com.google.cloud.spark:spark-bigquery-with-dependencies_2.12:0.22.0,com.google.cloud.bigdataoss:gcs-connector:hadoop3-1.9.5,com.google.guava:guava:31.1-jre') \
            .getOrCreate()
            
            
        if credsFile is not None:
            logging.info("Bigquery creds file given. Setting up hadoop and service account")
            spark._jsc.hadoopConfiguration().set(
            'fs.gs.impl', 'com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem')
            spark._jsc.hadoopConfiguration().set(
            'google.cloud.auth.service.account.json.keyfile',
            credsFile)
            
            
        logging.info("Final spark config is:")
        logging.info(spark.sparkContext.getConf().getAll())
        
        return spark

    def sethadooop(self, spark, config):
        conf = spark.sparkContext._jsc.hadoopConfiguration()
        for (name, value) in config.items():
            conf.set(name, value)


##################################
# Dataframe Conversion and mapping
##################################

    def equivalent_type(self, f):

        if f == 'datetime64':
            return TimestampType()
        elif f == 'int64':
            return LongType()
        elif f == 'int32':
            return IntegerType()
        elif f == 'bool':
            return BooleanType()
        else:
            return StringType()


    def define_structure(self, string, format_type):
        try:
            typo = self.equivalent_type(format_type)
        except:
            typo = StringType()

        return StructField(string, typo)


    def pandas_to_spark(self, pandas_df, spark):
        """convert pandas dataframe to spark dataframe

        Args:
            pandas_df (pandas.Dataframe): pandas dataframe to convert
            spark (Object): Spark session object

        Returns:
            Spark.DataFrame: Spark dataframe
        """
        if 'index' in pandas_df.columns:
            pandas_df.reset_index(drop=True, inplace=True)
            
        columns = list(pandas_df.columns)
        types = list(pandas_df.dtypes)
        struct_list = []
        for column, typo in zip(columns, types):
            struct_list.append(self.define_structure(column, typo))
        p_schema = StructType(struct_list)
        return spark.createDataFrame(pandas_df, p_schema)


    def dict_mapping(self, target_type, target_table, target):

        connection_dict = dict()
        
        logging.info(f"TARGET MAPPING {target}")
        
        
        db_type = target_type.lower() if target_type.lower() in SPARK_MAPPING else 'jdbc'

        target_db_creds = SPARK_MAPPING[db_type]['DB_CONNECTIONS']
        
        for key,value in target_db_creds.items():
            if key in target:
                connection_dict[value] = target[key]

        if "query" not in target:
            if target_type.lower() == 'bigquery':
                db_table = 'table'
                connection_dict['parentProject'] = target['serviceaccountjson']['project_id']
                connection_dict['credentialsFile'] = self.credsFile
            else:
                db_table = 'dbtable'
                
            connection_dict[db_table] = target_table
        
        logging.info(f"TARGET MAPPING {connection_dict}")

        return connection_dict

##############################################
# Additional Features for integrations 
###############################################

    def upload_logs(self,integration_id:str, pipeline_id:str, last_log_line:int, cloud_type:str, creds:dict):
        
        """ This Method Upload the last modified log file from the airflow log path of provided integration and their pipeline.

        Args:
            integration_id (str): Integration Name
            pipeline_id (str): Pipeline Name
            cloud_type (str): ['cloudwatch', 'wasabi']
            creds (dict): 'aws_example' 
            ```json
            {
                "aws_access_key_id":"",
                "aws_secret_access_key":"",
                "region_name":""
            }
            ```

            last_log_line (int): line number of last written log

        Returns:
            boolen: True/False
        """
        print("INSIDE UPLOAD LOGS METHOD")
      
        cloud_type = cloud_type.lower()

        def __gettarget__(cloud_type:str,creds:dict):
            """ provide the target of of cloud 

            Args:
                cloud_type (str): cloud name ex. 'cloudwatch','azureblob'
                creds (dict): 'credentials for target'.

            Returns:
                target/False: Return Target Object on success and False on Failure.
            """

            try:
                resourse_type = 'logs' if cloud_type.lower() == 'cloudwatch' else 's3'

                if cloud_type.lower() == 'cloudwatch':
                    btclient = boto3.client(
                        resourse_type,
                        aws_access_key_id=creds['aws_access_key_id'],
                        aws_secret_access_key = creds["aws_secret_access_key"],
                        region_name = creds["region_name"]
                    )
                    
                elif cloud_type == 'wasabi':
                    btclient = boto3.client(
                        resourse_type, 
                        endpoint_url=creds['url'],
                        aws_access_key_id=creds['aws_access_key_id'],
                        aws_secret_access_key = creds["aws_secret_access_key"]
                    )
                    
                return btclient
            
            except Exception as e:
                print(e)
                return False

        def __writelog__(cloud_type:str, target:__gettarget__, log_event:list, filename:str):
            """This Method write log on provided target.

            Args:
                cloud_type (str): 'cloudwatch' ,'azure' etc
                target (__gettarget__): target Object 
                log_event (list): list of all the logs event ( log line)
                filename (str): log file name to be written on cloud

            Returns:
                Bool: True/False
            """

            try:
                if cloud_type == 'cloudwatch':
                    try:
                        target.create_log_group(logGroupName='lyftrondata_integrations')
                    except target.exceptions.ResourceAlreadyExistsException as e:
                        pass
                    try:
                        target.create_log_stream(logGroupName='lyftrondata_integrations', logStreamName=filename)
                    except target.exceptions.ResourceAlreadyExistsException as e:
                        pass
                
                    response = target.describe_log_streams(logGroupName='lyftrondata_integrations', logStreamNamePrefix=filename)

                    next_token = None if 'uploadSequenceToken' not in response['logStreams'][0] \
                                        else response['logStreams'][0]["uploadSequenceToken"]
                    log_event_dict = {
                        'logGroupName':'lyftrondata_integrations',
                        'logStreamName':filename,
                        'logEvents':log_event,
                    }
                    if next_token:
                        log_event_dict.update({'sequenceToken': next_token})
                    target.put_log_events(**log_event_dict)
                    
                    print("Logs Uploaded to Target Successful")
            
                elif cloud_type == 'wasabi':
                    try:
                        target.put_object(Bucket=creds['bucket_name'], Key=filename, Body=json.dumps(log_event))                
                    except Exception as e:
                        raise "UPLOAD LOG ERROR: " + str(e)
                    print("Logs Uploaded to Target Successful")
                return True

            except BaseException as e:
                print(e)
                return False
    
        # airflow log Path
        airflow_home = os.environ.get('AIRFLOW_HOME','/home/lyftrondata/airflow')
        airflow_log_path = f"{airflow_home}/logs/{integration_id}/{pipeline_id}/"
        paths = [os.path.join(airflow_log_path,  basename) for basename in os.listdir(airflow_log_path)]

        # checking last modified log file in path
        logs_path = [os.path.join(max(paths, key=os.path.getctime), basename) \
            for basename in os.listdir(max(paths, key=os.path.getctime))]

        log_filename = max(logs_path,key=os.path.getctime)

        try:
            # open last modified log file
            with open(log_filename,"r") as log_file:
                file_data = log_file.readlines()
            
            # configure variable 
            cloud_target = __gettarget__(cloud_type,creds)
            last_timestamp = ''
            log_line = ''
            last_log_write = False
            stream_name = f'{self.integration_id}/{pipeline_id}{log_filename.split(pipeline_id)[1].replace(":","_")}'

            log_event = []
            
            # reading last written line till current lines in log file 
            # [last_log_line = 0 if written first time ]

            for i in file_data[last_log_line:len(file_data)]:
                timestamp = re.findall(r'(\d+-\d+-\d+ \d+:\d+:\d+,\d+)',i)

                if timestamp:
                    if last_log_write:
                        date = int(round(time.mktime(time.strptime(timestamp[0], "%Y-%m-%d %H:%M:%S,%f")) * 1000))
                        
                        log_event.append({
                            'timestamp': date,
                            'message': log_line.replace(f'[{last_timestamp}]','')
                            }
                        )
                        
                        last_timestamp = timestamp[0]
                        last_log_write = False
                    else: 
                        date = int(round(time.mktime(time.strptime(timestamp[0], "%Y-%m-%d %H:%M:%S,%f")) * 1000))

                        log_event.append({
                            'timestamp': date,
                            'message': i.replace(f'[{timestamp[0]}]','')
                            }
                        )
                        last_timestamp = timestamp[0]
                else:
                    log_line = f"{log_line} \n {i}"
                    last_log_write = True

            __writelog__(cloud_type,cloud_target,log_event,stream_name)
            self.last_log_line = len(file_data)
            status = True

        except Exception as e:
            print(e)
            status = False

        return status


    def add_batch_record(self,pipeline:dict,
                        lyftrondata_options:dict):
        
        print("writing Batches Record!!!!")
        
        date_string = datetime.datetime.now(pytz.utc).strftime("%Y%m%d%H%M%S%f")
        random_number = random.randint(0, 10000)
        child_id = f"{lyftrondata_options['tenant_id']}_{date_string}_{random_number}"

        child ={
            "id": child_id,
            "created_at": lyftrondata_options['batch_object']['lyftron']['created_at'],
            "updated_at": lyftrondata_options['batch_object']['lyftron']['updated_at'],
            "status": self.status,
            "version": "1.0",
            "pipeline": pipeline['pipeline_id'],
            "started_at": lyftrondata_options['batch_object']['lyftron']['started_at'],
            "finished_at": lyftrondata_options['batch_object']['lyftron']['finished_at'],
            "next_execution_at": lyftrondata_options['batch_object']['lyftron']['next_execution_at'],
            "row_select": self.row_select,
            "row_insert": self.row_write,
            "total_pipeline_processed": pipeline['pipeline_count'],
            "error_message": self.error_message,
            "parent_batch_id": lyftrondata_options['batch_object']['lyftron']['id'],
            "source_table_name": pipeline['source_table'],
            "target_table_name": pipeline['target_table'],
            "is_super_parent": False,
            "runtime_log_file_path": "",
            "row_update": 0,
            "source_database_name": lyftrondata_options['source_database_name'],
            "target_database_name": lyftrondata_options['batch_object']['lyftron']['target_database_name'],
            "source_schema_name": pipeline['source_schema'],
            "target_schema_name": pipeline['target_schema'],
            "volume": None,
            "unit": None,
            "delta_field": pipeline['delta_fields'],
            "delta_value": "",
            "created_by": lyftrondata_options['user_id'],
            "updated_by": lyftrondata_options['user_id'],
            "tenant": lyftrondata_options['tenant_id'],
            "environment": lyftrondata_options['environment_id'],
            "project": lyftrondata_options['project_id'],
            "integration": lyftrondata_options['integration_id'],
            "started_by": lyftrondata_options['user_id']
            }
        
        target_child ={
            "id": child_id,
            "created_at": lyftrondata_options['batch_object']['target']['created_at'],
            "updated_at": lyftrondata_options['batch_object']['target']['updated_at'],
            "status": self.status,
            "version": "1.0",
            "pipeline": pipeline['source_table'],
            "started_at": lyftrondata_options['batch_object']['target']['started_at'],
            "finished_at": lyftrondata_options['batch_object']['target']['finished_at'],
            "next_execution_at": lyftrondata_options['batch_object']['target']['next_execution_at'],
            "row_select": self.row_select,
            "row_insert": self.row_write,
            "total_pipeline_processed": pipeline['pipeline_count'],
            "error_message": self.error_message,
            "parent_batch_id": lyftrondata_options['batch_object']['target']['id'],
            "source_table_name": pipeline['source_table'],
            "target_table_name": pipeline['target_table'],
            "is_super_parent": False,
            "runtime_log_file_path": "",
            "row_update": 0,
            "source_database_name": lyftrondata_options['source_database_name'],
            "target_database_name": lyftrondata_options['batch_object']['target']['target_database_name'],
            "source_schema_name": pipeline['source_schema'],
            "target_schema_name": pipeline['target_schema'],
            "volume": None,
            "unit": None,
            "delta_field": pipeline['delta_fields'],
            "delta_value": "",
            "created_by": lyftrondata_options['batch_object']['target']['created_by'],
            "updated_by": lyftrondata_options['batch_object']['target']['updated_by'],
            "tenant": lyftrondata_options['batch_object']['target']['tenant'],
            "environment": lyftrondata_options['batch_object']['target']['environment'],
            "project": lyftrondata_options['batch_object']['target']['project'],
            "integration": lyftrondata_options['batch_object']['target']['integration'],
            "started_by": lyftrondata_options['batch_object']['target']['started_by']
            }
        
        with open(lyftrondata_options['batch_file_path'],"r+") as batch_file:
            batch_list = json.load(batch_file)    
            batch_file.truncate(0)
            batch_file.seek(0)
            batch_list.append(child)
            json.dump(batch_list,batch_file)
            batch_file.close()
        try:
            spu.write_batch_target(lyftrondata_options['target'],target_child)
        except Exception as e:
            print("Unable to write to target: ",e)
            
        try:
            spu.write_batch_file(lyftrondata_options['filesystem_options'],
                        lyftrondata_options['batch_file_path'],
                        lyftrondata_options['batch_file_name'])
            
            status = True
            
        except Exception as e:
            print(str(e))
            status = False
        return status

    def jdbc_target_metadata(target_type,target_creds,action,target_schema,target_table):
        
        target_metadata = dict()
        
        handler_params = {
            'class_import': "JDBC",
            'command': 'initialize',
            'variables': target_creds
            }

        handler_obj = Lyftrondata_Connector_Handler(license)
        provider_engine_obj = handler_obj.runcommand(handler_params)
        
        print(provider_engine_obj)
        
        if action == 'create':
            query = spu.create_statement(target_type, target_table, target_schema)
        elif action == 'alter':
            query = spu.alter_statement("")
        else:
            query = ""
            
        if action != None:
            get_schema = {
                    'class_import': "JDBC",
                    'command': 'execute_query',
                    'query': query,
                    'provider_engine_obj': provider_engine_obj[1]
                }

            schema = handler_obj.runcommand(get_schema)
        
        return target_metadata
        
##################################################
# read and write methods for loads 
##################################################


    def read_spark(self,spark:pyspark.sql.SparkSession, creds:dict, table:str, format:str):
        logging.info("Attempting to reading data VIA SPARK")
        logging.info(f"Connection Details : [creds]")
        try: 
            
            connection_dict = self.dict_mapping(target_type=format,
                                                target_table=table,
                                                target=creds,
                                                )

            not_jdbc = ['snowflake', 'bigquery']
            
            if format not in not_jdbc:
                connection_dict['url'] = "jdbc:{FORMAT}://{URL}{PORT}/{DATABASE}".format(
                    FORMAT=creds['enginename'],
                    URL=connection_dict['url'],
                    PORT=f":{connection_dict['port']}" if connection_dict['port'] else '',
                    DATABASE=connection_dict['database']
                )
                format = 'jdbc'
            logging.info(connection_dict)
            df = spark.read.format(format).options(**connection_dict).load()
            self.row_select = self.row_select + df.count()
            logging.info("Total rows read:"+str(self.row_select))
            
            return df
        
        except Exception as e:
            logging.exception("Failure in reading data:"+str(e))
            if self.logging_options:
                self.upload_logs(integration_id = self.integration_id,
                            pipeline_id=self.pipeline_object['pipeline_id'],
                            last_log_line=self.last_log_line,
                            **self.logging_options)
            raise Exception(str(e))


    def run_load_pipeline(self,target_creds:dict,spark:pyspark.sql.SparkSession,pipeline:dict,target_type:str, pandas_df,mapping_df):
    
        self.pipeline_object = pipeline
        row_select = len(pandas_df)

        self.row_select = self.row_select + row_select
        load_action = pipeline['load_action']
        primary_keys = pipeline['primary_key']
        source_table = re.sub("[^0-9a-zA-Z]+", '_',
                            pipeline['source_table'])
        
        target_table = pipeline['target_table']


        if self.lyftrondata_options:
            source_metadata = spu.get_source_metadata_from_api(host_ip=self.lyftrondata_options['log_host_ip'],
                                                            integration_id = self.lyftrondata_options['integration_id'])
        else:
            source_metadata = spu.get_source_metadata_pandas(pandas_df)
            
        
        spark_df = self.pandas_to_spark(pandas_df, spark=spark)
        
        # FETCH TARGET METADATA
        target_metadata = spu.get_target_metadata(
                                        target=target_creds,
                                        target_table=target_table,
                                        target_type=target_type
                                    )

        # MATCHING SOURCE AND TARGET METADATA
        
        logging.info(f"Pandas DATAFRAME SIZE {len(pandas_df)} :: Metadata len {len(source_metadata)}/ SPARK DATAFRAME SIZE {len(spark_df.columns)}")
        logging.info(f"target table {pipeline['target_table']}")
        
        updated_spark_df, source_to_target_metadata = spu.equating_source_target_meta(
                                        target_type=target_type, 
                                        target=target_creds,
                                        target_table=target_table,
                                        target_metadata=target_metadata, 
                                        source_metadata=source_metadata,
                                        mapping=mapping_df,
                                        spark_df=spark_df,
                                        load_action=load_action,
                                        spark=spark
                                    )
        

        target_length = 0 if not target_metadata else len(target_metadata)

        print(
            f"LENGTH OF TARGET/SPARK_DF : {target_length}/{len(updated_spark_df.columns)}")
        # WRITING DATAFRAME TO TARGET AFTER EQUATION SOURCE AND TARGET RESPONSES

        flag = self.write(
                        df=updated_spark_df,
                        format=target_type,
                        target_table=pipeline['target_table'],
                        target=target_creds,
                        mode=load_action,
                        spark=spark
                    )

        # TYPE 1 OR TYPE 2 LOAD ACTION BLOCK

        if flag:
            try:
                if load_action == 'type1' or load_action == 'type2':
                    flag, status = spu.fire_type_statement(load_action,
                                                            target=target_creds,
                                                            target_type=target_type,
                                                            target_table=pipeline['target_table'],
                                                            primary_key=primary_keys,
                                                            source_to_target_metadata=source_to_target_metadata,
                                                            mapping=mapping_df)
            except Exception as e:
                self.error_message = str(e)
                self.status = "Failed"
                
                if self.logging_options:
                    self.upload_logs(integration_id = self.integration_id,
                            pipeline_id=self.pipeline_object['pipeline_id'],
                            last_log_line=self.last_log_line,
                            **self.logging_options
                        )
                if self.lyftrondata_options:
                    self.add_batch_record(pipeline=pipeline,lyftrondata_options=self.lyftrondata_options)
                raise Exception(str(e))
            
        
        if self.logging_options:
            self.upload_logs(integration_id = self.integration_id,
                            pipeline_id=pipeline['pipeline_id'],
                            last_log_line=self.last_log_line,
                            **self.logging_options)
        # self.status = "In Progress"
        if self.lyftrondata_options:
            self.add_batch_record(pipeline=pipeline,lyftrondata_options=self.lyftrondata_options)

        return flag
    

    def write(self, df: pyspark.sql.dataframe, target: dict, format: str, target_table: str, mode: str, spark:None):
        logging.info("WRITING DATAFRAME TO TARGET [ IN PROGRESS]")
        
        connection_dict = self.dict_mapping(target_type=format,
                                            target_table=target_table,
                                            target=target,
                                            )

        try:
            if mode.lower() == 'type1' or mode.lower() == 'type2':
                mode = 'append'
                connection_dict['dbtable'] = "stg_"+connection_dict['dbtable']

            not_jdbc = ['snowflake', 'bigquery']
            
            if format not in not_jdbc:
                connection_dict['url'] = "jdbc:{FORMAT}://{URL}{PORT}/{DATABASE}".format(
                    FORMAT=target['enginename'],
                    URL=connection_dict['url'],
                    PORT=f":{connection_dict['port']}" if connection_dict['port'] else '',
                    DATABASE=connection_dict['database']
                )
                
                format = 'jdbc'

            df.printSchema()
            logging.info(f"CONNECTION DETAILS {connection_dict}")
            
            df.write.format(format).options(
                **connection_dict).mode(mode).save()
            row_write = df.count()
            
            self.row_write = self.row_write + row_write
            
            print(
                f"DATA INSERTED SUCCESSFULLY! select/write {self.row_select}/{self.row_write}")
            df = None
            self.status = "Success" 
            return True

        except Exception as e:
            self.error_message = str(e)
            self.status = "Failed"
            
            if self.lyftrondata_options:
                self.add_batch_record(pipeline=self.pipeline_object,lyftrondata_options = self.lyftrondata_options)
            if self.logging_options:
                self.upload_logs(integration_id = self.integration_id,
                            pipeline_id=self.pipeline_object['pipeline_id'],
                            last_log_line=self.last_log_line,
                            **self.logging_options)
            raise Exception(str(e))


    def run_loads(self, spark: pyspark.sql.SparkSession, pipeline: dict, source: dict,
                  target: dict, license: str, row_count: int = 10000,load_type='fullLoad',**kwargs):
        """
        json = {
            pipieline :{
                'pipeline_id':'tickets_pipeline',
                "source_table":"tickets",
                "source_schema":"Lyftrondata_Gorgias",
                "target_table":"tickets",
                "target_schema:"GORGIASTESTING",
                'load_action':'append'
                },

            source = {
                "provider_type" : "", #api or db
                'provider_name': 'SageIntacct',
                'creds': {
                    'connection_type':'session',
                    "sender_id": "New Meridian",
                    "sender_password": "?T9o@Ksb7@f?$4dB",
                    "company_id": "New Meridian",
                    "username": "JSyed",
                    "password": "Blaze@123!",
                    "lyft_token_email": "admin@lyftrondata.com",
                    },
                'source_table':'glentry',
                'source_type' : 'api',
                },

            "target":{
                "provider_type":""  #api or db
                "creds":{
                    "sfURL" : "https://ak67441.central-us.azure.snowflakecomputing.com",
                    "sfUser" : "FAIZAN",
                    "sfPassword" : "Blaze@123!",
                    "sfDatabase" : "sf_tuts",
                    "sfSchema" : "public",
                    "sfWarehouse" : "sf_tuts_wh",
                    "sfRole" : "ACCOUNTADMIN",
                }
                'provider_name':'db'
                },
            "format":"snowflake",
            "license":""
            }
            """
        
        #SOURCE VARIABLES
        source_provider = source['provider_name']
        source_provider_type = source['provider_type']
        source_creds = source['creds']
        
        #TARGET VARIABLES
        target_provider = target['provider_name']
        target_provider_type = target['provider_type']
        target_creds = target['creds']
        
        #PIPELINE VARIABLES
        pipeline_id = pipeline['pipeline_id']
        target_table_action = pipeline['target_table_action'].lower()
        self.pipeline_object = pipeline
        self.pipeline_object['pipeline_id'] = pipeline_id


        if self.lyftrondata_options:
            host_ip = self.lyftrondata_options['log_host_ip']
            integration_id=self.lyftrondata_options['integration_id']
            mapping_df = spu.get_datatype_mapping_from_api(target_type=target_provider,
                                    host_ip = self.lyftrondata_options['log_host_ip'],
                                    integration_id=self.lyftrondata_options['integration_id'])
        
        else:
            mapping_df = spu.get_datatype_mapping(target_type=target_provider)
        
        if source_provider_type == 'api' and target_provider_type == "db":
            
            logging.info("WRITING API TO DB")
            
            handler_params = {
                'class_import': source_provider,
                'command': 'initialize',
                'variables': source_creds
                }

            handler_obj = Lyftrondata_Connector_Handler(license)
            provider_engine_obj = handler_obj.runcommand(handler_params)
            
            print(provider_engine_obj)
            
            if not provider_engine_obj[0]:
                print(provider_engine_obj[1])
                return "Connection to provider Failed!"


            if target_provider.lower() == 'bigquery':
                target['creds']['project_id'] = target_creds['serviceaccountjson']['project_id'] 
                pipeline['target_table'] = f"{target_creds['dataset']}.{pipeline['target_table']}"
                target['creds']['creds_file_path'] = self.credsFile
                
                if self.lyftrondata_options:
                    self.lyftrondata_options['target'] = target
                
            target_table = pipeline['target_table']
                
            READ_DATA = {
                'class_import': source_provider,
                'command': 'streaming',
                'variables': {'table': pipeline['source_table']},
                'provider_engine_obj': provider_engine_obj[1]
            }

            streaming = handler_obj.runcommand(READ_DATA)

            try:
                
                list_df = pd.DataFrame().reset_index(drop=True, inplace=True)
                    
                if target_table_action != 'no action':
                    
                    spu.target_db_load_action(
                        target=target_creds,
                        target_type=target_provider,
                        target_load_action=target_table_action,
                        target_table=target_table
                    )
                
                for panda_df, state in streaming:
                    pd_columns = list()
                    panda_df.columns = panda_df.columns.str.lower()

                    for col in panda_df.columns:
                        pd_columns.append(re.sub("[^0-9a-zA-Z]+", '_', col))
                    panda_df.columns = pd_columns

                    list_df = pd.concat([list_df, panda_df])

                    # FETCH THE DATAFRAME FROM API AND TAKE THE ROW COUNTS
                    # INITIATE RUN LOAD METHOD ON MINIMUM ROW COUNTS.
                    if list_df.shape[0] >= row_count or not state:
                        # FETCHING DATATYPE MAPPING

                        # PANDAS TO SPARK COMPLETE PROCESS
                        # spark_df = self.pandas_to_spark(spark=spark, pandas_df=list_df)
                        
                        if state:
                            self.status = "In Progesss"
                        
                        self.run_load_pipeline(
                                    target_creds = target_creds,
                                    spark=spark,
                                    pipeline=pipeline,
                                    target_type=target_provider,
                                    pandas_df=list_df,
                                    mapping_df = mapping_df
                                    )
                        
                        list_df = pd.DataFrame().reset_index(drop=True, inplace=True)   
                        spark_df = None 
                        if load_type.lower() == 'incrementaload':
                            break
            
            except Exception as e:
                self.status = "Failed"
                self.error_message = str(e)
                
                if self.lyftrondata_options:
                    self.add_batch_record(pipeline=pipeline,lyftrondata_options = self.lyftrondata_options)
                
                if self.logging_options:
                    self.upload_logs(integration_id = self.integration_id,
                                pipeline_id=pipeline_id,
                                last_log_line=self.last_log_line,
                                **self.logging_options)
                raise Exception(str(e))

            if self.status != "Success":
                self.status = "Success"
            
                if self.lyftrondata_options:
                    self.add_batch_record(pipeline=self.pipeline_object,lyftrondata_options = self.lyftrondata_options)
            print(f"STREAMING {pipeline['source_table']} SUCCESSFULL WITH WRITE/READ [{self.row_write}/{self.row_select}]")

        elif source_provider_type == 'db' and target_provider_type == 'db':
            
            logging.info(f"WRITING {source_provider} DB TO {target_provider} DB")
            
            if self.lyftrondata_options:
        
                target_metadata, source_metadata = spu.get_metadata_from_api(host_ip=host_ip,
                                                               integration_id=integration_id,
                                                               pipeline=pipeline)
            
                # updated_source_metadata = spu.converted_dtype(from_type="Source Provider",
                #                     to_type="Spark",
                #                     mapping=mapping_df,
                #                     metadata=source_metadata)
                
            
            spark_df = self.read_spark(spark=spark,
                                    creds=source_creds,
                                    table=pipeline['source_table'],
                                    format=source_provider)

            
            # spark_df = spu.spark_typecasting(updated_source_metadata,
            #                                  spark_df,
            #                                  {},
            #                                  {},spark=spark)

            
            # logging.info(f"Target Metadata : {target_metadata}")
            # logging.info("sparkdataframe after type_casting")
            spark_df.show()
            # logging.info(f"Source Metadata : {source_metadata}")

            if target_provider.lower() == 'bigquery':
                target['creds']['project_id'] = target_creds['serviceaccountjson']['project_id'] 
                pipeline['target_table'] = f"{target_creds['dataset']}.{pipeline['target_table']}"
                target['creds']['creds_file_path'] = self.credsFile

                if self.lyftrondata_options:
                    self.lyftrondata_options['target'] = target
                    
            # if pipeline['target_table_action'].lower() != 'no action':
            #     spu.target_db_load_action(target=target_creds,
            #                             target_type=target_provider,
            #                             target_load_action=target_table_action,
            #                             target_table=target_table)
            
            
            self.write(df=spark_df,
                            format=target_provider,
                            target_table=pipeline['target_table'],
                            target=target_creds,
                            mode=pipeline['load_action'],
                            spark=spark)
            
            if self.lyftrondata_options:
                self.add_batch_record(pipeline=pipeline,lyftrondata_options = self.lyftrondata_options)  
                
        elif source_provider_type == 'api' and target_provider_type == 'api':
            pass
        
        elif source_provider_type == 'db' and target_provider_type == 'api':
            pass
       
        if self.logging_options:
            self.upload_logs(integration_id = self.integration_id,
                            pipeline_id=pipeline['pipeline_id'],
                            last_log_line=self.last_log_line,
                            **self.logging_options)
        
        return True



if __name__ == "__main__":

    source = {
            'provider_type': 'api',
            'creds': {
               'connection_type': 'basicauth', 
                'subdomain': 'pethonesty', 
                'username': 'data@pethonesty.com', 
                'password': '0715c1c33f52504a06e393110847421157f87976f901a8e46f3c64e0b4e4d880',
                'lyft_token_email': 'admin@lyftrondata.com'
                },
            'provider_name':'Gorgias'
        }

    target = {
            'provider_type': 'db',
            'creds': {
                'serviceaccountjson': {
                        "type": "service_account",
                        "project_id": "bigquery-365918",
                        "private_key_id": "9c5337f58307c11030bf228cdfd832ca5ea44ff7",
                        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC9Reuk7sldXQiq\n4MF8Mjv7hDvI01uLseuhWH31uEKu2LMNEQJJso4Jm1QezN3FlbC2HDDZyaCokDdw\nXFU6hOl5flJx0vBpj7Q3yrVvwP8dyujwNAMcSrtK0DXfZaWdJrG5iYaw5CVQNV0k\noLAwyjkil3fBwu0sP5Hd1RVAUS0RnOKj9WGbT+MSCCUl/jqgyWsO2agTNf0OvvC8\nip3HnO5Gdsvx9UdoAMqb4qWObKnbL0FHv+9fC8wsO3Lqk5OUvJEfDkSkfdr4YgVO\no7h0wvSehM3wwwEtn7OsvEd5xHwtzRmc44VklbnkzSKRff6PG1PMiSgAvk5uvBJ5\nOV/C10YPAgMBAAECggEABItYuImJKSYyLpQd4SL9oLDQlKZKdOStMR8ESzGE3FjU\nl7Q4V1ejpGRn1SN7EaLh7sVngNsf8dwgkKCO5UxKpMGdLiFv50DthUdnKss59Nep\n1xaQmo3KyGWOXZI9szO6IafFJZscsDvPxDDdehZo38U+OVc6RY0zLd3PWE96owkU\nG05nJlQdTEmpZ/0QZ2Ei9lJWeLI+/vSKSZFXtpzgSyTQe9FpAdV/8yFMlxq0JVI3\nnAwpYoipO387k98p34db2RD7m8Dwu2sZfXO6cjV229QsGeEUan+kQXdc6QJyYvGn\n4vXnBYKLUUBAdn2J/is19mkPG5n04TEiLuOtbbvLbQKBgQD5FZLcQD+xpH8jjRws\nq68QGgnpUs5fYfpR8+46LEDGbvkyCROjRxXOLdAmzixWxtIR2lG7rAgBE49wdzx7\nwxJ2mEIg93HEjcUIzM9SvjeVh1BTYQrqc9fK67uei9RwnvoetGkh43Bpx6VzmdIe\ngmdCj+R5XOgYcwGMuZGCS0MSRQKBgQDChzmHbt54InVJ4/ivxDTmeUcIsNT/LXQg\n1yaiQGYtNRqUrpKZmFWq5hmy/d1dkb4UyKh1Ju1hKA1ew0Pvw8w1TU/5lLdoRlwW\nCrOhg3kOq/v0KtGqRui7bQhocRfCcca5Z5OwzHZxvl/HQDueXlfMUOUwCZd+w9dC\nJTMpTBpmQwKBgHYPYq+giFATzusz3BHUQkLYhLAhvo15LCOiAd1y0jT7roOnx7YR\nYGV8U3fBK0TqMfGiUDEq5hRUiB1fdryWhm7N1jI39qWaKLT2FqJ6ZHAsVcdfbMQZ\nqkOVHjWUw1mqEJVzH42fds28glBbrTsmxfjHqRxZC+1ivW5NGonuUFkdAoGALw1e\nUO/0R8Kt9A18Xadr1EOJdwSuwHpSGI9x/NTu4ghyQXxoYVaDgi7eEHlvTe6ut4BB\nnvSnflSdx0ob6KbHgi0NJyVdp489Puefw3V1lqLq8ohY5oL4UD1zRy/zu0ih9L6k\n7qLGE4UkzaEvyoKvYfA/P3tSdYsRSiKNWXPa/tkCgYB2NlZi4FXHIPRevrEy1goV\nSX0pZHY9AsgaOv1AH9XYVEaKJvOS+OKkrta4zEnggpKABdfwYiu/3b49v2bMJRXK\ndCEHZcaQ2gHWXhtOdoyCZwV9VJbWWkPcsP9Qm9WyUpQdT78QPPvAa7hgpDOxzWCS\nC/qJHhm8Bl+Ff4UX5F5WHA==\n-----END PRIVATE KEY-----\n",
                        "client_email": "lyftrondatabigquery@bigquery-365918.iam.gserviceaccount.com",
                        "client_id": "117174899747396484948",
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token",
                        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/lyftrondatabigquery%40bigquery-365918.iam.gserviceaccount.com"
                        },
                'dataset': 'lyftrondata',
                'gcp_bucket_name': 'lyftrondatabigquery'
            },
            'provider_name':'bigquery'
        }

    pipeline = {
            "pipeline_id":"abc_123",
            "source_table": "macros",
            "source_schema": "public",
            "target_table": "macros_testing_gorias_no_batches",
            "target_schema": "public",
            "target_table_action":"No Action",
            "trigger_fields": [],
            "primary_key":[],
            "load_action" : "append"
        }
    
    spark_jars  = []

    with open("creds_file.json","w") as f:
        json.dump( {
                        "type": "service_account",
                        "project_id": "bigquery-365918",
                        "private_key_id": "9c5337f58307c11030bf228cdfd832ca5ea44ff7",
                        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC9Reuk7sldXQiq\n4MF8Mjv7hDvI01uLseuhWH31uEKu2LMNEQJJso4Jm1QezN3FlbC2HDDZyaCokDdw\nXFU6hOl5flJx0vBpj7Q3yrVvwP8dyujwNAMcSrtK0DXfZaWdJrG5iYaw5CVQNV0k\noLAwyjkil3fBwu0sP5Hd1RVAUS0RnOKj9WGbT+MSCCUl/jqgyWsO2agTNf0OvvC8\nip3HnO5Gdsvx9UdoAMqb4qWObKnbL0FHv+9fC8wsO3Lqk5OUvJEfDkSkfdr4YgVO\no7h0wvSehM3wwwEtn7OsvEd5xHwtzRmc44VklbnkzSKRff6PG1PMiSgAvk5uvBJ5\nOV/C10YPAgMBAAECggEABItYuImJKSYyLpQd4SL9oLDQlKZKdOStMR8ESzGE3FjU\nl7Q4V1ejpGRn1SN7EaLh7sVngNsf8dwgkKCO5UxKpMGdLiFv50DthUdnKss59Nep\n1xaQmo3KyGWOXZI9szO6IafFJZscsDvPxDDdehZo38U+OVc6RY0zLd3PWE96owkU\nG05nJlQdTEmpZ/0QZ2Ei9lJWeLI+/vSKSZFXtpzgSyTQe9FpAdV/8yFMlxq0JVI3\nnAwpYoipO387k98p34db2RD7m8Dwu2sZfXO6cjV229QsGeEUan+kQXdc6QJyYvGn\n4vXnBYKLUUBAdn2J/is19mkPG5n04TEiLuOtbbvLbQKBgQD5FZLcQD+xpH8jjRws\nq68QGgnpUs5fYfpR8+46LEDGbvkyCROjRxXOLdAmzixWxtIR2lG7rAgBE49wdzx7\nwxJ2mEIg93HEjcUIzM9SvjeVh1BTYQrqc9fK67uei9RwnvoetGkh43Bpx6VzmdIe\ngmdCj+R5XOgYcwGMuZGCS0MSRQKBgQDChzmHbt54InVJ4/ivxDTmeUcIsNT/LXQg\n1yaiQGYtNRqUrpKZmFWq5hmy/d1dkb4UyKh1Ju1hKA1ew0Pvw8w1TU/5lLdoRlwW\nCrOhg3kOq/v0KtGqRui7bQhocRfCcca5Z5OwzHZxvl/HQDueXlfMUOUwCZd+w9dC\nJTMpTBpmQwKBgHYPYq+giFATzusz3BHUQkLYhLAhvo15LCOiAd1y0jT7roOnx7YR\nYGV8U3fBK0TqMfGiUDEq5hRUiB1fdryWhm7N1jI39qWaKLT2FqJ6ZHAsVcdfbMQZ\nqkOVHjWUw1mqEJVzH42fds28glBbrTsmxfjHqRxZC+1ivW5NGonuUFkdAoGALw1e\nUO/0R8Kt9A18Xadr1EOJdwSuwHpSGI9x/NTu4ghyQXxoYVaDgi7eEHlvTe6ut4BB\nnvSnflSdx0ob6KbHgi0NJyVdp489Puefw3V1lqLq8ohY5oL4UD1zRy/zu0ih9L6k\n7qLGE4UkzaEvyoKvYfA/P3tSdYsRSiKNWXPa/tkCgYB2NlZi4FXHIPRevrEy1goV\nSX0pZHY9AsgaOv1AH9XYVEaKJvOS+OKkrta4zEnggpKABdfwYiu/3b49v2bMJRXK\ndCEHZcaQ2gHWXhtOdoyCZwV9VJbWWkPcsP9Qm9WyUpQdT78QPPvAa7hgpDOxzWCS\nC/qJHhm8Bl+Ff4UX5F5WHA==\n-----END PRIVATE KEY-----\n",
                        "client_email": "lyftrondatabigquery@bigquery-365918.iam.gserviceaccount.com",
                        "client_id": "117174899747396484948",
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token",
                        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/lyftrondatabigquery%40bigquery-365918.iam.gserviceaccount.com"
                        },f)

    spark_connection=Connect(licenseKey="QWERTY-ZXCVB-6W4HD-DQCRG")

    spark_init = spark_connection.initialize('APP', '2g', {},credsFile='creds_file.json')

    df = spark_connection.run_loads(spark=spark_init,
            pipeline=pipeline,
            source=source,
            target=target,
            format='bigquery',
            license="QWERTY-ZXCVB-6W4HD-DQCRG",
            row_count=100
            )