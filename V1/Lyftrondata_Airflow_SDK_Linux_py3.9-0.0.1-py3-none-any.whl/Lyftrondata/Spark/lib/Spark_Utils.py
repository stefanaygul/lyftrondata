import pandas as pd
import pyspark
from pyspark.sql.types import *
from pyspark.sql.functions import lit , monotonically_increasing_id
import sqlalchemy
import json
import logging
import os
import socket
import sys
import psutil
import boto3

lyft_log = logging.basicConfig(level=logging.INFO,
                format = "{asctime} - {levelname:<8}- {message}",
                style ='{')

def memory_logs():
    vmem = psutil.virtual_memory()
    svem = psutil.swap_memory()

    def __intoGB__(value):
        value = value/(1024.0 ** 3)
        return value

    mem_logs = {
        'HostName': socket.gethostname(),
        'HostIP' : socket.gethostbyname(socket.gethostname()),
        'Total RAM':__intoGB__(vmem.total),
        'Available RAM':__intoGB__(vmem.available),
        'Used RAM':__intoGB__(vmem.used),
        'Free RAM':__intoGB__(vmem.free),
        'Total SWAP RAM': __intoGB__(svem.total),
        'Used SWAP RAM': __intoGB__(svem.used),
        'Free SWAP RAM': __intoGB__(svem.free),
     
    }
    mem_logs_str = '\n'
    for key,value in mem_logs.items():
        mem_logs_str = f'{mem_logs_str}{key}:{value}\n'

    logging.info(mem_logs_str)

def write_batch_target(target,batches_json_object):
    
    if 'schema' in target['creds']:
        del target['creds']['schema']
    
    logging.info("WRITING BATCHES TO TARGET")
    
    try:
        
        sql_engine = get_connection_engine(target['creds'],target['target_provider']).connect()
        sql_engine.execute(f"USE DATABASE {target['creds']['database']};")
        sql_engine.execute('CREATE SCHEMA IF NOT EXISTS LYFT_METADATA;')
        target_df = pd.read_json(json.dumps(batches_json_object),orient='index').transpose()
        target_df.to_sql('LYFT_BATCH',con = sql_engine,schema='LYFT_METADATA',if_exists='append',index=False)
        logging.info("WRITING LOG TO TARGET [SUCCESS]")
        sql_engine.close()
        return True
    
    except Exception as e:
        print(str(e))
        logging.info("WRITING LOG TO TARGET [FAILED]")
        return False


def write_batch_file(creds,json_file_path,target_write_path):
    # Create connection to Wasabi / S3
    print("WRITING LOGS TO WASABI!!!")
    connection_type = creds['connection_type']
    credentials = creds['creds']
    if connection_type == 'wasabi':
        try:
            s3 = boto3.resource('s3',
                endpoint_url = credentials['url'],
                aws_access_key_id = credentials['aws_access_key_id'],
                aws_secret_access_key = credentials['aws_secret_access_key']
            )
            bucket = s3.Bucket(credentials['bucket_name'])
            target_write_path = f"{creds['log_file_path']}/{target_write_path}"

            print("json_file_path: ",json_file_path)
            bucket.upload_file(json_file_path, target_write_path)
            status = True

            print("Log Written to target [SUCCESS]: ",target_write_path)
            
        except Exception as e:
            status = False
            print(target_write_path)
            print("Log Written to target [FAILED]  [ERROR]: ",e)
    else:
        print(f"Following Connection Type isn't implemented yet! : {connection_type}")
    return status

def get_connection_engine(creds: dict, target_type: str):
    """create engine object on provided creds file for provided target type

    Args:
        creds (dict): connection credentials
        target_type (str): target name

    Returns:
        target_engine(sqlalchemy.engine) : Return Target sqlalchemy engine object on successfull connectivity | None on failure
    """
    memory_logs()
    target_type = target_type.lower()
    logging.info(f"Connecting to the Target Engine for Target {target_type}...")
    
    target_engine = None
    user = creds.get('username',None)
    hostname = creds.get('hostname',None)
    password = creds.get('password',None)
    port = creds.get('port',None)
    account = creds.get('account',None)
    warehouse = creds.get('warehouse',None)
    role = creds.get('role',None)
    database = creds.get('database',None)
    schema = creds.get('schema',None)
    
    if schema != None:
        schema = f"/{schema}"    
    
    if target_type == 'snowflake':

        hostname = None if not hostname else hostname.replace(
                        '.snowflakecomputing.com/', ''
                    ).replace("https://", ''
                                ).replace("http://", '').replace(
                        '.snowflakecomputing.com', ''
                    )

        connection_string = f"snowflake://{user}:{password}@{hostname}/{database}{schema}?warehouse={warehouse}&role={role}"

    elif target_type == 'bigquery':
        connection_string = f"{target_type.lower()}://"
        
    else:
        connection_string = f"{target_type.lower()}://{user}:{password}@{hostname}/{database}"
        
    try:
        print("THIS IS GENERATED CONNECTION STRING",connection_string)
        
        target_engine = sqlalchemy.create_engine(connection_string)
        logging.info(f"Connected Sucessfully...")
    except Exception as e:
        logging.exception(f"Connection Failed! {e}")

    return target_engine


def get_target_metadata(target: dict,target_table: str, target_type: str):
    """Generate target metadata based on target type

    Args:
        target (dict): _description_
        target_type (string): target type 'snowflake','bigquery' etc

    Returns:
        target_metadata(list): (return target metadata of table on success | False)
    """

    memory_logs()
    logging.info(f"Generating Target Metadata for target : {target_type}...")
    schema = target['schema'] if 'schema' in target else None

    #get engine object for sqlalchemy inspector
    engine = get_connection_engine(creds=target,target_type=target_type)
    target_metadata = dict()
    inspector = sqlalchemy.inspect(engine)
    inspect_schema_data = inspector.get_table_names(schema=schema)
    inspect_schema = [name.lower() for name in inspect_schema_data]
    #checking if table exist in schema or not

    is_table_exist = True if target_table.lower() in inspect_schema else False

    if is_table_exist:
        target_table = inspect_schema_data[inspect_schema.index(target_table.lower())]
        logging.info("Table Exist in target...")
        try:
            column_metadata = inspector.get_columns(target_table)
            for column in column_metadata:
                target_metadata.update({
                        column['name']:str(column['type']).lower()}
                    )
                    
            logging.info("Generating Target Metadata [ Success ]...")
            return target_metadata

        except Exception as e:
            logging.exception(f"Tale Exist in Target Failed to Generate Metadata! {e}")
    else:
        logging.info("Table Not Exist in Target perfomring Create Statement...")

        return target_metadata

""" TO BE ADDED IN FUTURE
 
def get_target_metadata(target: dict, target_table: str, target_type: str) -> dict:
    ""Generate target metadata based on target type

    Args:
        target (dict): _description_
        target_table (string):
        target_type (string): target type 'snowflake','bigquery' etc

    Returns:
        target_metadata(list): (return target metadata of table on success | False)
    ""

    # test connection for snowflake based connector
    print("FETCHING TABLE METADATA FROM TARGET!")

    # get engine object for sqlalchemy inspector
    engine = get_connection_engine(creds=target, target_type=target_type)
    target_metadata = dict()
    conn = engine.connect()

    DATABASE = target.get('database',None)
    SCHEMA = target.get('schema',None)

    SELECT = ""Select column_name,data_type
                    from {DATABASE}INFORMATION_SCHEMA.COLUMNS
                    WHERE table_name = '{TABLE_NAME}' AND table_schema = '{SCHEMA}' "".format(TABLE_NAME=target_table,
                                                            DATABASE = DATABASE+"." if DATABASE else '',
                                                            SCHEMA = SCHEMA if SCHEMA else ''
                                                           )

    if target_type == 'snowflake':
        res =conn.execute(SELECT.upper()).fetchall()
    else:
        res =conn.execute(SELECT).fetchall()
    # checking if table exist in schema or not

    if res:
        for column in res:
            target_metadata.update({
            column[0].lower(): str(column[1]).lower()}
                )
        print("TABLE EXIST IN SCHEMA METADATA OBTAINED!!")
        return target_metadata

    else:
        print("METADATA FOR TABLE DO NOT EXIST PERFORM CREATE STATEMENT")
        return target_metadata
   """

def get_source_metadata(source_spark_df: pyspark.sql.dataframe):
    """_summary_

    Args:
        source_spark_df (pyspark.sql.dataframe): _description_

    Returns:
        dict: _description_
    """
    # Return meta data from Spark dataframe
    memory_logs()
    logging.info("Generating Source Metadata!")
    source_metadata = dict()
    sourcedata = json.loads(source_spark_df.schema.json())
    try:
        fields = sourcedata['fields']
        for column in fields:

            source_metadata.update({
                    column['name'].lower():str(column['type']).lower()}
                )
        logging.info("Generated Source Metadata [ Success ]...")
        logging.info(str(source_metadata))
        return source_metadata

    except Exception as e:
        logging.exception(f"Generating Source Metadata [ Failed ]...{e}")


def get_datatype_mapping(target_type: str, source_type: str = "Spark"):
    """Generate Datatype mapping based on Target and source type.

    Args:
        target_type (str): any target
        source_type (str, optional): source type. Defaults to "Spark".

    Returns:
        mapdf(pandas.DataFrame): mapped pandas dataframe with target source and their default values.
    """

    # load map csv for mapping
    memory_logs()
    abs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ''))
    mapping_path = f'{abs_path}/config/target_source_dtype_map.csv'

    logging.info("Generating Datatype Mapping List...")
    try:
        mapdf = pd.read_csv(mapping_path)
        mapdf.columns.str.lower()
        for col in mapdf.columns:
            if col.lower() == target_type.lower():
                mapdf = mapdf[[source_type, col, "Default Value","Lyftrondata"]].fillna("N/A")
                mapdf[source_type] = mapdf[source_type].str.lower()
                mapdf[col] = mapdf[col].str.lower()
                logging.info("Generating Datatype Mapping List [ Success ]...")
                return mapdf
        
    except Exception as e:
        logging.exception(f"Generating Datatype Mapping List [ Failed ].. {e}")


def fillnan(spark_df, mapping: pd.DataFrame,
                source_type: str = "Spark"):
    """_summary_

    Args:
        spark_df (_type_): _description_
        metadata (_type_): _description_
        mapping (_type_): _description_
        source_type (str, optional): _description_. Defaults to "Spark".

    Returns:
        _type_: _description_
    """
    memory_logs()
    logging.info("Filling NaN None and Null Values...")
    try:
        logging.info(f"Spark Dataframe Before Filling Nan")
        metadata = get_source_metadata(spark_df)
        defaultvalues = converted_dtype(from_type=source_type,
                                to_type="Default Value",
                                mapping=mapping,
                                metadata=metadata)

        spark_df = spark_df.na.fill(defaultvalues)
        memory_logs()
        logging.info(f"Spark Dataframe After Filling NaN")
        logging.info("Filling NaN None and Null Values... [Success]")
        metadata = get_source_metadata(spark_df)
        memory_logs()
        return spark_df, metadata
    except Exception as e:
        logging.exception(f"Filling NaN None and Null Values [ Failed ].. {e}")


def spark_typecasting(mapped_target_metadata:dict, spark_df: pyspark.sql.dataframe,
                    default_values:dict, not_in_source:dict, casting_types:dict ,spark):

    """This Function Perform the typecasting on provided metadata
        and add missing columns in source dataframe.

    Args:
        mapped_target_metadata (dict): Target metadata json
        spark_df (pyspark.sql.dataframe): spark dataframe
        default_values (dict): default values json mapped on target type.
        not_in_source (dict): columns which are in target but not in source

    Returns:
        pyspark.sql.dataframe: casted dataframe with missing columns
    """
    memory_logs()
    logging.info("Casting Source Metadata...")
    logging.info(f"Columns IN-SOURCE / NOT IN SOURCE \
        {len(spark_df.columns)}/{len(not_in_source)}")
    
    # adding missing columns to dataframe with their default values
    logging.info(f"Spark Dataframe Before Casting and Adding Columns")
    spark_df.printSchema()
    spark_df.show(5)
    length_of_rows = spark_df.count()
    rows = []
    if not_in_source:
        for _ in range(length_of_rows):
            row_data = []
            for column,dtype in not_in_source.items():
                row_data.append(default_values[column])
            rows.append(tuple(row_data))

                # class_name = getattr(sys.modules[__name__], casting_types[column])
        columns = list(not_in_source.keys())
        
        df_columns_not_in_source = spark.createDataFrame(rows,columns)

        df_columns_not_in_source = df_columns_not_in_source.withColumn("lyft_merge", monotonically_increasing_id())
        spark_df = spark_df.withColumn("lyft_merge", monotonically_increasing_id())

        spark_df = spark_df.join(df_columns_not_in_source,
                            spark_df.lyft_merge == df_columns_not_in_source.lyft_merge,
                            "left").drop("lyft_merge")

    memory_logs()

    logging.info(f"casting [COLUMNS NOT IN SOURCE] {not_in_source}")
    logging.info(f"casting [Default Values] {default_values}")

    spark_df1 = spark_df 
    spark_df = None

    try:
        castquery = list()
        logging.info(f"Length of DataFrame After Adding Columns {len(spark_df1.columns)}")
        # type casting based on target metadata

        for column, dtype in mapped_target_metadata.items():
            castquery.append(f"cast({column} as {dtype}) {column} ")
        spark_df1.selectExpr(castquery)
        spark_df = spark_df1
        spark_df1 = None
        logging.info(f"Spark Dataframe Before Casting and Adding Columns")
        logging.info(f"Current Length of spark DF {len(spark_df.columns)}")
        logging.info("Casting Source Metadata [ Success]...")
        memory_logs()
        return spark_df

    except Exception as e:
        logging.exception(f"Casting Source Metadata [ Failed ]... {e}")


def converted_dtype(from_type: str, to_type: str, 
                    mapping: pd.DataFrame, metadata: dict):
    """This Function Convert the Data types of each columns
        based on provided mapping (Target,Source,Default Values)

    Args:
        from_type (str): type you wanted to convert
        to_type (str): to be convert into
        mapping (pd.DataFrame): Dataframe of provided source and target with their 
                                Default values.
        metadata (dict): metadata which need to be convert

    Returns:
        dict: converted dictonary.
    """

    logging.info(f"Converting Datatypes {from_type}/{to_type}..")
    
    # fetching column name names from mapping dataframe.
    for col in mapping.columns:
        if from_type.lower() == col.lower():
            from_type = col
        if to_type.lower() == col.lower():
            to_type = col

    subset = dict()
    try:
        # creating dictonary of mapped columns according to data type.

        for column,datatype in metadata.items():
            if datatype.__contains__("("):
                datatype = datatype.split("(")[0]
            val = mapping.loc[mapping[from_type] == datatype]
            try:
                subset.update({
                    column.lower(): val[to_type].iat[0]
                })
            except Exception as e:
                logging.info(f" Failed Type {datatype}")
                logging.exception(f"Datatypes COLUMN NOT FOUND.. {e}")
        logging.info(f"Converting Datatypes {from_type}/{to_type} [ Success ]..")
 
        return subset
    except Exception as e:
        logging.exception(f"Converting Datatypes {from_type}/{to_type} [ Failed ].. {e}")


def fire_query(engine: sqlalchemy.engine, query: str):
    """This function Generate Query statement on target Connection.

    Args:
        engine (sqlalchemy.engine): Target Connection Engine
        query (str): query statement

    Returns:
        bool: True on Success/ False on Failure
    """

    logging.info(f"Execute Query [{query}]") 
    connection = engine.connect()
    Status = False
    try:    
        connection.execute(query)
        Status = True
        logging.info("Executed Query Succesfully....")
    except Exception as e:
        logging.exception(f"Excecute Query [ Failed ]... {e}")
    finally:
        connection.close()
        engine.dispose()
    return Status


def alter_statement(target_type: str, target_table: str, metadata: dict):
    """This method generates ALTER statement for provided metadata.

    Args:
        target_type (str): target type
        target_table (str): table name of target
        metadata (dict): metada data of columns which have to be altered/added

    Returns:
        str: full formed alter statement
    """

    query = f'alter table {target_table} add'
    constraint = 'not null' if target_type !='snowflake' else ''
    for column, datatype in metadata.items():
        query = query + f" {column} {datatype} {constraint},"
    query = query[:-1]+";"

    return query


def create_statement(target_type: str, target_table: str, metadata: dict):
    """This method generates CREATE statement for provided metadata.

    Args:
        target_type (str): target type
        target_table (str): table name of target
        metadata (dict): metadata of table columns which have to be added.

    Returns:
        str: full formed CREATE statement
    """

    query = f'CREATE TABLE {target_table}('
    for column, datatype in metadata.items():
        query = query + f" {column} {datatype} ,"
    query = query[:-1]+")"

    return query


def fire_type_statement(load_action: str, target: dict, target_type: str,
                        target_table: str, primary_key: str, spark_df: pyspark.sql.dataframe,
                        mapping: pd.DataFrame):
    """_summary_

    Args:
        load_action (str): _description_
        target (dict): _description_
        target_type (str): _description_
        target_table (str): _description_
        primary_key (list): _description_
        spark_df (pyspark.sql.dataframe): _description_
        mapping (pd.DataFrame): _description_

    Returns:
        str: _description_
    """

    logging.info("Generating Load action Statement ...")

    source_metadata = get_source_metadata(spark_df)
    metadata = converted_dtype(from_type="Spark",
                               to_type=target_type,
                               mapping=mapping,
                               metadata=source_metadata)

    if load_action == "type1":
        statement = """
        MERGE INTO "{DATABASE}"."{SCHEMA}"."{TABLE}" target
        using "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}" stage
        ON stage."{primary_key}" = target."{primary_key}"
        WHEN matched AND (stage."{primary_key}" != target."{primary_key}")
        THEN
        DELETE
        WHEN NOT matched THEN

        INSERT {TABLE_COLUMNS}
        VALUES {STAGE_TABLE_COLUMNS}
        """

    elif load_action == "type2":
        statement = """
        MERGE INTO "{DATABASE}"."{SCHEMA}"."{TABLE}"
        using (SELECT "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".id AS join_key_1,
              "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".*
        FROM   "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"
        UNION ALL
        SELECT NULL,
              "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".*
        FROM   "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"
              JOIN "{DATABASE}"."{SCHEMA}"."{TABLE}"
                ON "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".id =
                   "{DATABASE}"."{SCHEMA}"."{TABLE}".id
        WHERE  "{DATABASE}"."{SCHEMA}"."{TABLE}".lyft_startdate IS NULL
              AND ( "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"."actions" <>
                          "{DATABASE}"."{SCHEMA}"."{TABLE}"."actions"
                     OR "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"."name" <>
                        "{DATABASE}"."{SCHEMA}"."{TABLE}"."name" )) sub

        ON sub.join_key_1 = "{DATABASE}"."{SCHEMA}"."{TABLE}".id
        WHEN matched AND (sub."id" <> "{DATABASE}"."{SCHEMA}"."{TABLE}"."id" OR
        sub."name" <> "{DATABASE}"."{SCHEMA}"."{TABLE}"."name" ) THEN
        UPDATE SET "lyft_startdate" = CURRENT_TIMESTAMP(),
                    "lyft_version" = 'Update',
                    "lyft_enddate" = 'Inactive',
                    "lyft_status" = "{DATABASE}"."{SCHEMA}"."{TABLE}"."lyft_status"
                                    + 1
        WHEN NOT matched THEN
        INSERT {TABLE_COLUMNS}
        VALUES {STAGE_TABLE_COLUMNS}
        """
    
    try:
        DATABASE = target['database']
        TABLE = target_table
        SCHEMA = target['schema']
        TABLE_COLUMNS = str(tuple(metadata)).replace("'", '"')
        columns = list()
        primary_key = primary_key

        for column in metadata:
            column = f"stage.{column}" if load_action == 'type1' else f"sub.{column}"
            columns.append(column)
        STAGE_TABLE_COLUMNS = str(tuple(columns)).replace("'", '')

        query = statement.format(DATABASE=DATABASE,
                                SCHEMA=SCHEMA,
                                TABLE=TABLE,
                                STAGE_TABLE="stg_"+TABLE,
                                TABLE_COLUMNS=TABLE_COLUMNS,
                                STAGE_TABLE_COLUMNS=STAGE_TABLE_COLUMNS,
                                primary_key=primary_key)
        target_engine = get_connection_engine(target, target_type)
        status = fire_query(target_engine, query.upper())

        logging.info(f"Load Action {load_action} [ Success ]... ")

    except Exception as e:
        logging.exception(f"Load Action [ Failed ]... {e}")
        status = False
    return status, query


def compare_columns(mapped_target_metadata: dict, mapped_source_metadata: dict):
    """_summary_

    Args:
        mapped_target_metadata (dict): _description_
        mapped_source_metadata (dict): _description_

    Returns:
        dict,dict: _description_
    """
    logging.info("Comparing Source/Target Columns..")
    not_in_source = dict()
    not_in_target = dict()


    for column, dtype in mapped_source_metadata.items():
        if column.lower() not in mapped_target_metadata:
            not_in_target.update({column.lower(): dtype})

    for column, dtype in mapped_target_metadata.items():
        if column.lower() not in mapped_source_metadata.keys():
            not_in_source.update({column.lower(): dtype})

    logging.info(f"Columns NOT_IN_SOURCE / NOT_IN_TARGET : {len(not_in_source)}/{len(not_in_target)} ..")
    return not_in_source, not_in_target


def rearrange_colums(mapped_target_metadata: dict, meta_not_in_target: dict,
                     spark_df: pyspark.sql.dataframe):
    """_summary_

    Args:
        mapped_target_metadata (dict): _description_
        meta_not_in_target (dict): _description_
        spark_df (pyspark.sql.dataframe): _description_

    Returns:
        pyspark.sql.dataframe: _description_
    """
    logging.info("Rearranging Columns according to target....")

    columns = list(mapped_target_metadata.keys()) + \
        list(meta_not_in_target.keys())
    logging.info(f"Columns Rearranged:{columns}")

    spark_df = spark_df.select(columns)
    return spark_df


def equating_source_target_meta(target_type: str, target: dict, target_table: str,
                                target_metadata: dict, source_metadata: dict, mapping: pd.DataFrame,
                                spark_df: pyspark.sql.dataframe, load_action: str,spark):
    """_summary_

    Args:
        target_type (str): _description_
        target (dict): _description_
        target_table (str): _description_
        target_metadata (dict): _description_
        source_metadata (dict): _description_
        mapping (pd.DataFrame): _description_
        spark_df (pyspark.sql.dataframe): _description_

    Returns:net.razorvine.pickle.PickleException: expected zero arguments for construction of ClassDict (for pandas._libs.tslibs.nattype.__nat_unpickle)
        pyspark.sql.dataframe: _description_
    """
    memory_logs()
    logging.info("Equating Source/Target ... ")
    
    target_engine = get_connection_engine(target, target_type)
    try:
        if not target_metadata:

            spark_df, source_metadata = fillnan(spark_df=spark_df,
                                            mapping=mapping)

            source_metadata = converted_dtype(from_type="Spark",
                                            to_type=target_type,
                                            mapping=mapping,
                                            metadata=source_metadata)

            query = create_statement(target_type, target_table, source_metadata)
            target_engine = get_connection_engine(target, target_type)
            fire_query(target_engine, query)

            if load_action == 'type1' or load_action == 'type2':
                query = create_statement(
                    target_type, "stg_"+target_table, source_metadata)
                target_engine = get_connection_engine(target, target_type)
                fire_query(target_engine, query)

        else:
            logging.info(f"THIS IS METADATA OBJ {target_metadata}")

            mapped_target_metadata = converted_dtype(from_type=target_type,
                                                    to_type="Spark",
                                                    mapping=mapping,
                                                    metadata=target_metadata)

            logging.info(f"Target Metadata:{mapped_target_metadata.keys()}")
    
            mapped_source_metadata = converted_dtype(from_type="Spark",
                                                    to_type=target_type,
                                                    mapping=mapping,
                                                    metadata=source_metadata)

            not_in_source, not_in_target = compare_columns(
                        mapped_target_metadata, mapped_source_metadata)

            default_values = converted_dtype(from_type='Spark',
                                                to_type="Default Value",
                                                mapping=mapping,
                                                metadata=not_in_source)
            casting_types = converted_dtype(from_type='Spark',
                                                to_type="Lyftrondata",
                                                mapping=mapping,
                                                metadata=not_in_source)

            spark_df = spark_typecasting(mapped_target_metadata,
                                    spark_df,default_values,not_in_source,casting_types,spark)

            spark_df = rearrange_colums(mapped_target_metadata, not_in_target, spark_df)

            spark_df, source_metadata = fillnan(spark_df=spark_df,
                                    mapping=mapping)

            if not_in_target:
                alter_query = alter_statement(
                    target_type, target_table, not_in_target)
                target_engine = get_connection_engine(target, target_type)
                fire_query(target_engine, alter_query)


            if load_action == 'type1' or load_action == 'type2':
                # get engine object for sqlalchemy inspector

                engine = get_connection_engine(
                    creds=target, target_type=target_type)
                target_metadata = []

                inspector = sqlalchemy.inspect(engine)
                inspect_schema = inspector.get_table_names(target['schema'])

                # checking if table exist in schema or not
                is_table_exist = True if "stg_"+target_table in inspect_schema else False
                
                if is_table_exist:
                    if not_in_target:
                        alter_query = alter_statement(
                            target_type, "stg_"+target_table, not_in_target)
                        target_engine = get_connection_engine(target, target_type)
                        fire_query(target_engine, alter_query)

                else:

                    source_metadata = get_source_metadata(spark_df)
                    source_metadata = converted_dtype(from_type="Spark",
                                                    to_type=target_type,
                                                    mapping=mapping,
                                                    metadata=source_metadata)

                    query = create_statement(
                        target_type, "stg_"+target_table, source_metadata)
                    target_engine = get_connection_engine(target, target_type)
                    fire_query(target_engine, query)
        logging.info("Equating Source/Target [ Success ]... ")
        updated_spark_df = spark_df
        spark_df = None
        memory_logs()
        return updated_spark_df
    except Exception as e:
        logging.exception(f"Equating Source/Target [ Failed ]... {e}")
