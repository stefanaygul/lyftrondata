import pandas as pd
import pyspark
from pyspark.sql.types import *
from pyspark.sql.functions import lit , monotonically_increasing_id
import sqlalchemy
import json
import logging
import socket
import psutil
import boto3
import requests
import os
from Lyftrondata.Lyftrondata_Connector_Handler import Connect as Lyftrondata_Connector_Handler

lyft_log = logging.basicConfig(level=logging.INFO,
                format = "{asctime} - {levelname:<8}- {message}",
                style ='{')


############################
# METADATA AND LOGS
############################

def memory_logs():
    vmem = psutil.virtual_memory()
    svem = psutil.swap_memory()

    def __intoGB__(value):
        value = value/(1024.0 ** 3)
        return value

    mem_logs = {
        'HostName': socket.gethostname(),
        'HostIP' : socket.gethostbyname(socket.gethostname()),
        'Total RAM':__intoGB__(vmem.total),
        'Available RAM':__intoGB__(vmem.available),
        'Used RAM':__intoGB__(vmem.used),
        'Free RAM':__intoGB__(vmem.free),
        'Total SWAP RAM': __intoGB__(svem.total),
        'Used SWAP RAM': __intoGB__(svem.used),
        'Free SWAP RAM': __intoGB__(svem.free),
     
    }
    mem_logs_str = '\n'
    for key,value in mem_logs.items():
        mem_logs_str = f'{mem_logs_str}{key}:{value}\n'

    logging.info(mem_logs_str)


def write_batch_target(target:dict,
                       batches_json_object:dict):

    """This method Writes Batches (LYFT_METADATA) to target under 'LYFT_BATCH TABLES'
    Args:
        target (dict): dictonary containing target creds parameters and type of target_provider
        batches_json_object (dict): Dictonary to be converted into pandas dataframe

    Returns:
        bool: True/False
    """
    
    logging.info("WRITING BATCH TO TARGET DATABASE [INTIALIZED]......")
    
    
    if 'schema' in target['creds']:
        del target['creds']['schema']
    
    try:
        
        sql_engine = get_connection_engine(target['creds'],target['provider_name']).connect()

        if target['provider_name'].lower() != 'bigquery':
            sql_engine.execute(f"USE DATABASE {target['creds']['database']};")
        sql_engine.execute('CREATE SCHEMA IF NOT EXISTS LYFT_METADATA;')
        target_df = pd.read_json(json.dumps(batches_json_object),orient='index').transpose()
        target_df.to_sql('LYFT_BATCH',con = sql_engine,schema='LYFT_METADATA',if_exists='append',index=False)
        logging.info("WRITING BATCH TO TARGET DATABASE [SUCCESS]")
        sql_engine.close()
        return True
    
    except Exception as e:
        logging.info(f"WRITING BATCH TO TARGET DATABASE [FAILED] :ERROR: {str(e)}")
        return False


def write_batch_file(creds:dict,
                     json_file_path:str,
                     target_write_path:str):
    
    """This Method Write Batch object to the provided connection creds.

    Args:
        creds (dict): batch target credentials.
        json_file_path (str): batch object file path.
        target_write_path (str): path where batch object will be written on target.

    Returns:
        status[bool]: True on Success/False on Failed
    """
    
    # Create connection to Wasabi / S3
    logging.info("WRITING BATCH TO BUCKET [INTIALIZED]......")
    connection_type = creds['connection_type']
    credentials = creds['creds']
    if connection_type == 'wasabi':
        try:
            s3 = boto3.resource('s3',
                endpoint_url = credentials['url'],
                aws_access_key_id = credentials['aws_access_key_id'],
                aws_secret_access_key = credentials['aws_secret_access_key']
            )
            bucket = s3.Bucket(credentials['bucket_name'])
            target_write_path = f"{creds['log_file_path']}/{target_write_path}"
            bucket.upload_file(json_file_path, target_write_path)
            status = True
            logging.info(f"WRITING BATCH TO BUCKET [ SUCCESS ] :RESPONSE: {str(target_write_path)}")

        except Exception as e:
            status = False
            logging.exception(f"WRITING BATCH TO BUCKET [FAILED] :ERROR: {str(e)}")
    else:
        print(f"Following Connection Type isn't implemented yet! : {connection_type}")
    return status


def get_connection_engine(creds: dict, 
                            target_type: str):
    
    """create engine object on provided creds file for provided target type

    Args:
        creds (dict): connection credentials
        target_type (str): target name

    Returns:
        target_engine(sqlalchemy.engine) : Return Target sqlalchemy engine object on successfull connectivity | None on failure
    """
    logging.info(f"CREATING CONNECTION ENGINE FOR {target_type}...")
    engine_creds = {}
    target_type = target_type.lower()
    
    target_engine = None
    user = creds.get('username',None)
    hostname = creds.get('hostname',None)
    password = creds.get('password',None)
    port = creds.get('port',None)
    warehouse = creds.get('warehouse',None)
    role = creds.get('role',None)
    database = creds.get('database',None)
    schema = creds.get('schema',None)
    
    if schema != None:
        schema = f"/{schema}"    
    
    if target_type == 'snowflake':

        hostname = None if not hostname else hostname\
            .replace('.snowflakecomputing.com/', '')\
            .replace("https://", '')\
            .replace("http://", '')\
            .replace('.snowflakecomputing.com', '')

        engine_creds['url'] = f"snowflake://{user}:{password}@{hostname}/{database}{schema}?warehouse={warehouse}&role={role}"

    elif target_type == 'bigquery':
        engine_creds['url'] = f"{target_type.lower()}://{creds['project_id']}"
        engine_creds['credentials_path'] = creds['creds_file_path']
        
    else:
        engine_creds['url'] = f"{target_type.lower()}://{user}:{password}@{hostname}/{database}"
        
    try:
        
        target_engine = sqlalchemy.create_engine(**engine_creds)
        logging.info(f"CONNECTION ENGINE FOR {target_type} [SUCCESS]...")

        
    except Exception as e:
        logging.exception(f"CONNECTION ENGINE FOR {target_type} [FAILED] :ERROR: {e}")

    return target_engine


def get_target_metadata(target: dict,
                        target_table: str, 
                        target_type: str):
    
    """Generate target metadata based on target type

    Args:
        target (dict): credentials for target
        target_type (string): target type 'snowflake','bigquery' etc

    Returns:
        target_metadata(list): (return target metadata of table on success | False)
    """
    
    logging.info(f"GENERATING TARGET METADATA OF TABLE [{target_table}] ...")

    schema = target['schema'] if 'schema' in target else None

    #get engine object for sqlalchemy inspector
    
    engine = get_connection_engine(creds=target,target_type=target_type)
    target_metadata = dict()
    
    inspector = sqlalchemy.inspect(engine)
    inspect_schema_data = inspector.get_table_names(schema=schema)
    
    inspect_schema = [name.lower() for name in inspect_schema_data]
    logging.info(f"LIST OF TABLES PRESENT IN SCHEMA :RESPONSE: {inspect_schema}...")

    #checking if table exist in schema or not

    is_table_exist = True if target_table.lower() in inspect_schema else False
    
    if is_table_exist:
        target_table = inspect_schema_data[inspect_schema.index(target_table.lower())]
        logging.info(f"METADATA OF TABLE [{target_table}] EXIST...")
        try:
            column_metadata = inspector.get_columns(target_table)
            for column in column_metadata:
                target_metadata.update({
                        column['name']:str(column['type']).lower()}
                    )
            logging.info(f"GENERATING TARGET METADATA OF TABLE [{target_table}] [ SUCCESS ] :RESPONSE: {str(target_metadata)}")
            return target_metadata

        except Exception as e:
            logging.exception(f"GENERATING TARGET METADATA OF TABLE [{target_table}] [ FAILED ]:ERROR: {e}")
    else:
        logging.info(f"Target Metdata of TABLE [{target_table}] DO NOT EXIST PERFORMING CREATE STATEMENT.")
        return target_metadata


def get_metadata_from_api(host_ip,integration_id,pipeline):
    
    source_table = pipeline['source_table']
    target_table = pipeline['target_table']
    source_schema = pipeline['source_schema']
    target_schema = pipeline['target_schema']
    
    target_metadata = {}
    source_metadata = {}
    
    url = f"http://{host_ip}:8000/metadata/get_source_target_metadata/"
    post_reqeust_body = { "integration_id": integration_id }
    
    try:
        response = requests.post(url, json=post_reqeust_body)
        logging.info(f"URL {url} :: RESPONSE :: {response} :: RESPONSE METADATA :: {response.json()}")        
        data = response.json()['data']
        
        target_metadata_json = data['target_metadata']
        source_metadata_json = data['source_metadata']
    
        for table in source_metadata_json[source_schema]['TABLE']:
            if source_table in table:
                for column in table[source_table]['columns']:
                    source_metadata[column['column']] = column['datatype']
                
        if target_metadata_json:
            for table in target_metadata_json[target_schema]['TABLE']:
                if target_table in table:
                    for column in table[target_table]['columns']:
                        target_metadata[column['column']] = column['datatype']
            

    except Exception as e:
        logging.exception(e)

    return target_metadata, source_metadata
    

def get_source_metadata(source_spark_df: pyspark.sql.dataframe):
    """This method Generate Metadata from Spark Dataframe provided by source.

    Args:
        source_spark_df (pyspark.sql.dataframe): pyspark dataframe of source table

    Returns:
        source_metadata: dict object containing source metadata
    """
    
    
    # Return meta data from Spark dataframe
    
    logging.info(f"CREATING SOURCE TABLE METADATA [INITIALIZED] ...")
    source_metadata = dict()
    sourcedata = json.loads(source_spark_df.schema.json())
    try:
        fields = sourcedata['fields']
        for column in fields:

            source_metadata.update({
                    column['name'].lower():str(column['type']).lower()}
                )
        logging.info(f"SOURCE METADATA GENERATED [ SUCCESS ] :RESPONSE: {str(source_metadata)}")
        return source_metadata

    except Exception as e:
        logging.exception(f"CREATING SOURCE METADATA [ FAILED ] :ERROR: {str(e)}")


def get_datatype_mapping_from_api(target_type: str,
                         integration_id: str,
                         host_ip:str):
    
    """Generate Datatype mapping based on Target and source type.

    Args:
        target_type (str): any target
        source_type (str, optional): source type. Defaults to "Spark".

    Returns:
        mapdf(pandas.DataFrame): mapped pandas dataframe with target source and their default values.
    """

    # load map csv for mapping
        
    post_reqeust_body = {
        "integration_id": integration_id,
    }

    url = f"http://{host_ip}:8000/get_source_target_typemapping"
    response = requests.post(url, data=post_reqeust_body)

    logging.info("CHECKING DATATYPE MAPPING FOR {target_type}/{Spark}")
    
    try:
        logging.info(f"REQUESTING DATATYPE MAPPING FROM SOURCE :: RESPONSE {response}")
        if response.status_code == 200:
            response = response.json()
            mapdf = pd.DataFrame(response['data'])
            logging.info(mapdf)
        
        for col in mapdf.columns:
            if col.lower() == target_type.lower():
                mapdf = mapdf[["Source Provider","Spark", col, "Default Value","Lyftrondata"]].fillna("N/A")
                mapdf[col] = mapdf[col]
                logging.info(f"CHECKING DATATYPE MAPPING FOR {target_type}/Spark [ SUCCESS ]")
                logging.info(mapdf)
                return mapdf
        
    except Exception as e:
        logging.exception(f"DATATYPE MAPPING [ Failed ] :ERROR: {str(e)}")

def get_datatype_mapping(target_type: str):
    """Generate Datatype mapping based on Target and source type.

    Args:
        target_type (str): any target
        source_type (str, optional): source type. Defaults to "Spark".

    Returns:
        mapdf(pandas.DataFrame): mapped pandas dataframe with target source and their default values.
    """

    # load map csv for mapping
    abs_path = os.path.abspath(os.path.join(
        os.path.dirname(__file__), '..', ''))
    mapping_path = f'{abs_path}/config/target_source_dtype_map.csv'

    logging.info("Generating Datatype Mapping List...")
    try:
        mapdf = pd.read_csv(mapping_path)
        mapdf.columns.str.lower()
        for col in mapdf.columns:
            if col.lower() == target_type.lower():
                mapdf = mapdf[['Source Provider',"Spark", col, "Default Value",
                               "Lyftrondata"]].fillna("N/A")
                logging.info("Generating Datatype Mapping List [ Success ]...")
                return mapdf

    except Exception as e:
        logging.exception(f"Generating Datatype Mapping List [ Failed ].. {e}")

def get_source_metadata_pandas(source_df: pd.DataFrame):
    """_summary_

    Args:
        source_spark_df (pyspark.sql.dataframe): _description_

    Returns:
        dict: _description_
    """
    # Return meta data from Spark dataframe
    
    logging.info("Generating Source Metadata!")
    source_metadata = dict()
    
    def __checkdtype(val):
        val = str(val)
        if val == 'int64':
            datatype = "int"
        elif val == 'bool':
            datatype = "boolean"
        elif val == "object":
            return "varchar(255)"
        elif val == 'datetime64':
            datatype = "datetime"
        else:
            datatype = "varchar(255)"
            
        return datatype
    try:
        
        for col in source_df.columns:
            source_metadata[col] = __checkdtype(source_df[col].dtype)
        return source_metadata

    except Exception as e:
        logging.exception(f"Generating Source Metadata [ Failed ]...{e}")
############################
# QUERIES  
############################


def fire_query(engine: sqlalchemy.engine, 
               query: str):
    
    """This function Generate Query statement on target Connection.

    Args:
        engine (sqlalchemy.engine): Target Connection Engine
        query (str): query statement

    Returns:
        bool: True on Success/ False on Failure
    """

    logging.info(f"EXECUTE QUERY [{query}]") 
    connection = engine.connect()
    Status = False
    try:    
        connection.execute(query)
        Status = True
        logging.info("Executed Query [ SUCCESS ]")
    except Exception as e:
        logging.exception(f"Excecute Query [ FAILED ] :: {e}")
    finally:
        connection.close()
        engine.dispose()
    return Status


def alter_statement(target_type: str,
                    target_table: str,
                    metadata: dict):
    
    """This method generates ALTER statement for provided metadata.

    Args:
        target_type (str): target type
        target_table (str): table name of target
        metadata (dict): metada data of columns which have to be altered/added

    Returns:
        str: full formed alter statement
    """
    target_type = target_type.lower()
    
    query = f'alter table {target_table}'
    syntax = 'add column'
    empty_constraints = ['snowflake','bigquery']
    
    constraint = 'not null' if target_type not in empty_constraints else ''
    
    logging.info(f"CREATING ALTER STATEMENT FOR TARGET {target_type}")
    try:
        for column, datatype in metadata.items():
            if target_type.lower() == 'bigquery':
                query = query + f" {syntax} {column} {datatype} {constraint},"
            else:
                query = query + f" {column} {datatype} {constraint},"
        query = query[:-1]+";"
        logging.info(f"CREATING ALTER STATEMENT FOR TARGET {target_type} :RESPONSE: {query}")
        return query
    
    except Exception as e:
        logging.exception(f"CREATING ALTER STATEMENT FOR TARGET {target_type} [ FAILED ] :ERROR: {str(e)} ")
        return False


def create_statement(target_type: str, 
                     target_table: str, 
                     metadata: dict):
    
    """This method generates CREATE statement for provided metadata.

    Args:
        target_type (str): target type
        target_table (str): table name of target
        metadata (dict): metadata of table columns which have to be added.

    Returns:
        str: full formed CREATE statement
    """

    logging.info(f"CREATING CREATE STATEMENT FOR TARGET {target_type}")
    try:
        query = f'CREATE TABLE {target_table}('
        for column, datatype in metadata.items():
            query = query + f" {column} {datatype} ,"
        query = query[:-1]+")"
        logging.info(f"CREATING ALTER STATEMENT FOR TARGET {target_type} [ SUCCESS ] :RESPONSE: {query}")
        return query
    except Exception as e:
        logging.exception(f"CREATING ALTER STATEMENT FOR TARGET {target_type} [ FAILED ] :ERROR: {e}")
        return False


def fire_type_statement(load_action: str, 
                        target: dict, 
                        target_type: str,
                        target_table: str, primary_key: str, spark_df: pyspark.sql.dataframe,
                        mapping: pd.DataFrame):
    
    """This Method Execute Query MERGE TYPE STATEMENTS [TYPE1/TYPE2] On Target.

    Args:
        load_action (str): Load Action type1/type
        target (dict): target credentials
        target_type (str): target database type
        target_table (str): target table
        primary_key (list): primary key of target_
        spark_df (pyspark.sql.dataframe): pyspark dataframe to be written on target
        mapping (pd.DataFrame): pandas Dataframe of datatype mapping.

    Returns:
        str: _description_
    """

    logging.info("Generating Load action Statement ...")

    source_metadata = get_source_metadata(spark_df)
    metadata = converted_dtype(from_type="Spark",
                               to_type=target_type,
                               mapping=mapping,
                               metadata=source_metadata)

    if load_action == "type1":
        statement = """
        MERGE INTO "{DATABASE}"."{SCHEMA}"."{TABLE}" target
        using "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}" stage
        ON stage."{primary_key}" = target."{primary_key}"
        WHEN matched AND (stage."{primary_key}" != target."{primary_key}")
        THEN
        DELETE
        WHEN NOT matched THEN

        INSERT {TABLE_COLUMNS}
        VALUES {STAGE_TABLE_COLUMNS}
        """

    elif load_action == "type2":
        statement = """
        MERGE INTO "{DATABASE}"."{SCHEMA}"."{TABLE}"
        using (SELECT "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".id AS join_key_1,
              "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".*
        FROM   "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"
        UNION ALL
        SELECT NULL,
              "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".*
        FROM   "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"
              JOIN "{DATABASE}"."{SCHEMA}"."{TABLE}"
                ON "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}".id =
                   "{DATABASE}"."{SCHEMA}"."{TABLE}".id
        WHERE  "{DATABASE}"."{SCHEMA}"."{TABLE}".lyft_startdate IS NULL
              AND ( "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"."actions" <>
                          "{DATABASE}"."{SCHEMA}"."{TABLE}"."actions"
                     OR "{DATABASE}"."{SCHEMA}"."{STAGE_TABLE}"."name" <>
                        "{DATABASE}"."{SCHEMA}"."{TABLE}"."name" )) sub

        ON sub.join_key_1 = "{DATABASE}"."{SCHEMA}"."{TABLE}".id
        WHEN matched AND (sub."id" <> "{DATABASE}"."{SCHEMA}"."{TABLE}"."id" OR
        sub."name" <> "{DATABASE}"."{SCHEMA}"."{TABLE}"."name" ) THEN
                    "lyft_version" = 'Update',
        UPDATE SET "lyft_startdate" = CURRENT_TIMESTAMP(),
                    "lyft_enddate" = 'Inactive',
                    "lyft_status" = "{DATABASE}"."{SCHEMA}"."{TABLE}"."lyft_status"
                                    + 1
        WHEN NOT matched THEN
        INSERT {TABLE_COLUMNS}
        VALUES {STAGE_TABLE_COLUMNS}
        """
    
    try:
        DATABASE = target['database']
        TABLE = target_table
        SCHEMA = target['schema']
        TABLE_COLUMNS = str(tuple(metadata)).replace("'", '"')
        columns = list()
        primary_key = primary_key

        for column in metadata:
            column = f"stage.{column}" if load_action == 'type1' else f"sub.{column}"
            columns.append(column)
        STAGE_TABLE_COLUMNS = str(tuple(columns)).replace("'", '')

        query = statement.format(DATABASE=DATABASE,
                                SCHEMA=SCHEMA,
                                TABLE=TABLE,
                                STAGE_TABLE="stg_"+TABLE,
                                TABLE_COLUMNS=TABLE_COLUMNS,
                                STAGE_TABLE_COLUMNS=STAGE_TABLE_COLUMNS,
                                primary_key=primary_key)
        target_engine = get_connection_engine(target, target_type)
        status = fire_query(target_engine, query.upper())

        logging.info(f"Load Action {load_action} [ Success ]... ")

    except Exception as e:
        logging.exception(f"Load Action [ Failed ]... {e}")
        status = False
    return status, query


def target_db_load_action(target:dict,
                       target_type:str,
                       target_load_action:str,
                       target_table:str):
    """
    """
    
    load_action_query = ""
    if target_load_action.lower() == 'truncate':
       load_action_query = f"""TRUNCATE TABLE {target_table};"""
    elif target_load_action.lower() == 'drop':
        load_action_query = f"""DROP TABLE IF EXISTS {target_table} CASCADE;"""
    else:
        load_action_query = ""
    
    try:
        engine = get_connection_engine(target,target_type)
        fire_query(engine,load_action_query)
        return True
    
    except Exception as e:
        logging.info(str(e))
        return False
    
############################
############################

# TABLE COMPARISION METHODS

def fillnan(spark_df,
            default_values):
    

    
    memory_logs()
    logging.info("Filling NaN None and Null Values...")
    
    try:
        logging.info(f"Spark Dataframe Before Filling Nan")
        spark_df = spark_df.na.fill(default_values)
        memory_logs()
        logging.info("Filling NaN None and Null Values... [Success]")
        memory_logs()
        return spark_df

    except Exception as e:
        logging.exception(f"Filling NaN None and Null Values [ Failed ].. {e}")


def spark_typecasting(mapped_target_metadata: dict, 
                      spark_df: pyspark.sql.dataframe,
                      default_values: dict, 
                      columns_not_in_source: dict, spark):
    
    """This Function Perform the typecasting on provided metadata
        and add missing columns in source dataframe.

    Args:
        mapped_target_metadata (dict): Target metadata json
        spark_df (pyspark.sql.dataframe): spark dataframe
        default_values (dict): default values json mapped on target type.
        columns_not_in_source (dict): columns which are in target but not in source

    Returns:
        pyspark.sql.dataframe: casted dataframe with missing columns
    """
    memory_logs()
   
    logging.info(f"Casting Source Metadata {len(mapped_target_metadata)}...")
    
    logging.info(f"Spark Dataframe Before Casting and Adding Columns [ IN-SOURCE / NOT IN SOURCE ] \
        {len(spark_df.columns)}/{len(columns_not_in_source)}")

    # adding missing columns to dataframe with their default values
    logging.info(f"Spark Dataframe Before Casting and Adding Columns")

    length_of_rows = spark_df.count()
    rows = []
   
    if columns_not_in_source:
        
        for _ in range(length_of_rows):
            row_data = []
            for column, dtype in columns_not_in_source.items():
                row_data.append(default_values[column])
            rows.append(tuple(row_data))

        columns = list(columns_not_in_source.keys())

        df_columns_not_in_source = spark.createDataFrame(rows, columns)

        df_columns_not_in_source = df_columns_not_in_source.withColumn(
            "lyft_merge", monotonically_increasing_id())
        spark_df = spark_df.withColumn(
            "lyft_merge", monotonically_increasing_id())

        spark_df = spark_df.join(df_columns_not_in_source,
                                 spark_df.lyft_merge == df_columns_not_in_source.lyft_merge,
                                 "left").drop("lyft_merge")

    memory_logs()

    logging.info(f"casting [COLUMNS NOT IN SOURCE] {columns_not_in_source}")

    try:
        castquery = list()
        logging.info(
            f"Length of DataFrame After Adding Columns \n {len(spark_df.columns)}")
        
        # type casting based on target metadata
        mapped_target_metadata.update(columns_not_in_source)
    
        spark_df.printSchema()
        
        logging.info(f"""Length Of Metadata :: {len(mapped_target_metadata)} \n \
                     Casting Metadata :: {mapped_target_metadata}""")
        
        
        for column, dtype in mapped_target_metadata.items():
            castquery.append(f"cast({column} as {dtype}) {column} ")
        
        spark_df = spark_df.selectExpr(castquery)

        logging.info(f"Spark Dataframe Before Casting and Adding Columns")
        logging.info(f"Current Length of spark DF {len(spark_df.columns)}")
        logging.info("Casting Source Metadata [ Success]...")
        memory_logs()
        return spark_df

    except Exception as e:
        logging.exception(f"Casting Source Metadata [ Failed ]... {e}")


def converted_dtype(from_type: str, to_type: str, 
                    mapping: pd.DataFrame, metadata: dict):
    """This Function Convert the Data types of each columns
        based on provided mapping (Target,Source,Default Values)

    Args:
        from_type (str): type you wanted to convert
        to_type (str): to be convert into
        mapping (pd.DataFrame): Dataframe of provided source and target with their 
                                Default values.
        metadata (dict): metadata which need to be convert

    Returns:
        dict: converted dictonary.
    """

    logging.info(f"Converting Datatypes {from_type}/{to_type}..")
    
    # fetching column name names from mapping dataframe.
    for col in mapping.columns:
        if from_type.lower() == col.lower():
            from_type = col
        if to_type.lower() == col.lower():
            to_type = col

    subset = dict()
    try:
        # creating dictonary of mapped columns according to data type.

        for column,datatype in metadata.items():
            
            if datatype.__contains__("("):
                datatype = datatype.split("(")[0]
                         
            val = mapping.loc[mapping[from_type].str.lower() == datatype.lower()]
            
            try:
                subset.update({
                    column.lower(): val[to_type].iat[0]
                })
                
            except Exception as e:
                logging.info(f" Failed Type {datatype}")
                logging.exception(f"Datatypes COLUMN NOT FOUND [{datatype}].. {e}")
     
        logging.info(f"Converting Datatypes {from_type}/{to_type} [ Success ]..")
 
        return subset
    except Exception as e:
        logging.exception(f"Converting Datatypes {from_type}/{to_type} [ Failed ].. {e}")


def compare_columns(mapped_target_metadata: dict, 
                    mapped_source_metadata: dict):
    """_summary_

    Args:
        mapped_target_metadata (dict): _description_
        mapped_source_metadata (dict): _description_

    Returns:
        dict,dict: _description_
    """
    logging.info("Comparing Source/Target Columns..")
    not_in_source = dict()
    not_in_target = dict()


    for column, dtype in mapped_source_metadata.items():
        if column.lower() not in mapped_target_metadata:
            not_in_target.update({column.lower(): dtype})

    for column, dtype in mapped_target_metadata.items():
        if column.lower() not in mapped_source_metadata.keys():
            not_in_source.update({column.lower(): dtype})

    logging.info(f"Columns NOT_IN_SOURCE / NOT_IN_TARGET : {len(not_in_source)}/{len(not_in_target)} ..")
    return not_in_source, not_in_target


def rearrange_colums(mapped_target_metadata: dict, 
                     meta_not_in_target: dict,
                     spark_df: pyspark.sql.dataframe):
    """_summary_

    Args:
        mapped_target_metadata (dict): _description_
        meta_not_in_target (dict): _description_
        spark_df (pyspark.sql.dataframe): _description_

    Returns:
        pyspark.sql.dataframe: _description_
    """
    logging.info("Rearranging Columns according to target....")

    columns = list(mapped_target_metadata.keys()) + \
        list(meta_not_in_target.keys())
    logging.info(f"Columns Rearranged:{columns}")

    spark_df = spark_df.select(columns)
    return spark_df


def equating_source_target_meta(target_type: str, 
                                target: dict, 
                                target_table: str,
                                target_metadata: dict, source_metadata: dict, mapping: pd.DataFrame,
                                spark_df: pyspark.sql.dataframe,load_action: str,spark):
    """_summary_

    Args:
        target_type (str): _description_
        target (dict): _description_
        target_table (str): _description_
        target_metadata (dict): _description_
        source_metadata (dict): _description_
        mapping (pd.DataFrame): _description_
        spark_df (pyspark.sql.dataframe): _description_

    Returns:net.razorvine.pickle.PickleException: expected zero arguments for construction of ClassDict (for pandas._libs.tslibs.nattype.__nat_unpickle)
        pyspark.sql.dataframe: _description_
    """
    
    memory_logs()
    logging.info("Equating Source/Target ... ")
    
    target_engine = get_connection_engine(target, target_type)
    
    try:
        if not target_metadata:
            
            target_provider_metadata = converted_dtype(from_type="Source Provider",
                                        to_type=target_type,
                                        mapping=mapping,
                                        metadata=source_metadata)

            default_values = converted_dtype(from_type="Source Provider",
                                        to_type="Default Value",
                                        mapping=mapping,
                                        metadata=source_metadata)

            spark_df = fillnan(spark_df=spark_df,
                                            default_values=default_values)
            
            query = create_statement(target_type, target_table, target_provider_metadata)

            target_engine = get_connection_engine(target, target_type)

            fire_query(target_engine, query)

            if load_action == 'type1' or load_action == 'type2':
                query = create_statement(
                    target_type, "stg_"+target_table, target_provider_metadata)
                target_engine = get_connection_engine(target, target_type)
                fire_query(target_engine, query)

        else:
            
            logging.info(f"THIS IS TARGET METADATA {target_metadata}")
            logging.info(f"THIS IS SOURCE METADATA {source_metadata}")

            target_to_source_metadata = converted_dtype(from_type=target_type,
                                            to_type="Source Provider",
                                            mapping=mapping,
                                            metadata=target_metadata)
            
            for column in target_to_source_metadata:
                if column in source_metadata:
                    source_metadata[column] = target_to_source_metadata[column]

            source_to_target_metadata = converted_dtype(from_type="Source Provider",
                                                     to_type=target_type,
                                                     mapping=mapping,
                                                     metadata=source_metadata)
            
            target_to_spark_metadata = converted_dtype(from_type="Source Provider",
                                            to_type="Spark",
                                            mapping=mapping,
                                            metadata=target_to_source_metadata)            
            
            not_in_source, columns_not_in_target = compare_columns(target_to_source_metadata,
                                                                           source_to_target_metadata)


            columns_not_in_source = dict()
            
            for col in not_in_source:
                columns_not_in_source[col] = target_to_spark_metadata[col]
            
            target_and_source_metadata = dict()
            target_and_source_metadata.update(target_to_source_metadata)
            target_and_source_metadata.update(source_metadata)
            
            metadata_all = converted_dtype(from_type='Source Provider',
                                            to_type="Spark",
                                            mapping=mapping,
                                            metadata=target_and_source_metadata)
            
            default_values = converted_dtype(from_type='Source Provider',
                                            to_type="Default Value",
                                            mapping=mapping,
                                            metadata=target_and_source_metadata)

            spark_df = spark_typecasting(mapped_target_metadata=metadata_all,
                                         spark_df = spark_df, 
                                         default_values=default_values,
                                         columns_not_in_source=columns_not_in_source, 
                                         spark=spark)

            spark_df = rearrange_colums(target_to_source_metadata, columns_not_in_target, spark_df)

            spark_df = fillnan(spark_df=spark_df,
                               default_values=default_values)

            source_metadata = target_and_source_metadata
            

            if columns_not_in_target:
                alter_query = alter_statement(
                    target_type, target_table, columns_not_in_target)
                target_engine = get_connection_engine(target, target_type)
                fire_query(target_engine, alter_query)


            if load_action == 'type1' or load_action == 'type2':
                # get engine object for sqlalchemy inspector

                engine = get_connection_engine(creds=target, target_type=target_type)
                target_metadata = []

                inspector = sqlalchemy.inspect(engine)
                inspect_schema = inspector.get_table_names(target['schema'])

                # checking if table exist in schema or not
                is_table_exist = True if "stg_"+target_table in inspect_schema else False
                logging.info(f"{target_table}")
                if is_table_exist:
                    if columns_not_in_target:
                        alter_query = alter_statement(
                            target_type, "stg_"+target_table, columns_not_in_target)
                        target_engine = get_connection_engine(
                            target, target_type)
                        fire_query(target_engine, alter_query)

                else:

                    source_target_metadata = converted_dtype(from_type="Source Provider",
                                                      to_type=target_type,
                                                      mapping=mapping,
                                                      metadata=source_metadata)

                    query = create_statement(
                        target_type, "stg_"+target_table, source_target_metadata)
                    target_engine = get_connection_engine(target, target_type)
                    
                    fire_query(target_engine, query)


        logging.info("Equating Source/Target [ Success ]... ")
        updated_spark_df = spark_df
        spark_df = None
        memory_logs()
        return updated_spark_df, source_metadata
    
    except Exception as e:
        logging.exception(f"Equating Source/Target [ Failed ]... {e}")
