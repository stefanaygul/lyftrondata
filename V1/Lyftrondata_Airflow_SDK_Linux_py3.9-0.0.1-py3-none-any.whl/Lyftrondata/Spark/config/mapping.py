SPARK_MAPPING = {
    "snowflake": {
        "DB_CONNECTIONS": {
            "hostname": "sfUrl",
            "username": "sfUser",
            "account": "sfAccount",
            "password": "sfPassword",
            "database": "sfDatabase",
            "schema": "sfSchema",
            "warehouse": "sfWarehouse",
            "role": "sfRole",
            "table": "dbtable"
        },
        "INSERT_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "CREATE_BATCHES": {
            "query": """CREATE TABLE {DATABASE}.{SCHEMA}.LYFT_BATCHES( id VARCHAR
                , created_at TIMESTAMP_TZ
                , updated_at TIMESTAMP_TZ
                , status VARCHAR
                , version VARCHAR
                , pipeline VARCHAR
                , started_at TIMESTAMP_TZ
                , finished_at TIMESTAMP_TZ
                , next_execution_at TIMESTAMP_TZ
                , row_select SMALLINT
                , row_insert SMALLINT
                , total_pipeline_processed SMALLINT
                , error_message VARIANT
                , parent_batch_id VARCHAR
                , source_table_name VARCHAR
                , target_table_name VARCHAR
                , is_super_parent BOOLEAN
                , runtime_log_file_path text
                , created_by_id VARCHAR
                , environment_id VARCHAR
                , integration_id VARCHAR
                , project_id VARCHAR
                , started_by_id VARCHAR
                , tenant_id VARCHAR
                , updated_by_id VARCHAR
            )  VALUES ;""",
            "stringCase": "upper"
        },
        "INSERT_TABLE": {

        },
        "CREATE_TABLE": {

        },
        "ALTER_TABLE": {

        },
        "TYPE_1": {

        },
        "TYPE_2": {

        }
    },
    "jdbc": {
        "DB_CONNECTIONS": {
            "hostname": "url",
            "username": "user",
            "password": "password",
            "database": "database",
            "schema": "schema",
            "port": "port",
            "classname": "driver",
            "table": "dbtable",
            "query":"query"
        },
        "INSERT_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "CREATE_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "INSERT_TABLE": {

        },
        "CREATE_TABLE": {

        },
        "ALTER_TABLE": {

        },
        "TYPE_1": {

        },
        "TYPE_2": {

        }
    },
    "bigquery": {
        "DB_CONNECTIONS": {
           "serviceaccountjson": "credentialsFile",
            "gcp_bucket_name": "temporaryGcsBucket",
            "dbtable": "table",
            "database": "parentProject",
            "schema": "project"
        },
        "INSERT_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "CREATE_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "INSERT_TABLE": {

        },
        "CREATE_TABLE": {

        },
        "ALTER_TABLE": {

        },
        "TYPE_1": {

        },
        "TYPE_2": {

        }
    },
    
    "sqlalchemy": {
        "DB_CONNECTIONS": {
            "hostname": "url",
            "username": "user",
            "password": "password",
            "database": "database",
            "schema": "schema",
            "port": "port",
            "classname": "driver",
            "table": "dbtable"
        },
        "INSERT_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "CREATE_BATCHES": {
            "query": "INSERT INTO {DATABASE}.{SCHEMA}.LYFT_BATCHES {COLUMNS} VALUES {VALUES};",
            "stringCase": "upper"
        },
        "INSERT_TABLE": {

        },
        "CREATE_TABLE": {

        },
        "ALTER_TABLE": {

        },
        "TYPE_1": {

        },
        "TYPE_2": {

        }
    }   
}