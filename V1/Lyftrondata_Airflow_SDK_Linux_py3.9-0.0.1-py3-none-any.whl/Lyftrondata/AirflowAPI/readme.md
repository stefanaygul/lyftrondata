INTEGRATION JSON SAMPLE

```{
    "type": "runload",
    
    "dag_params": {
        "dag_id": "Infoplus-customer-integration-10-12-22",
        "schedule_interval": null,
        "start_date": "2022-10-10T14:09:03Z",
        "description": "Testing DAG on Flask API"
    },
    
    "pipelines": [

        {
            "source_table": "customer",
            "source_schema": "Lyftrondata_InfoPlus",
            "target_table": "customer",
            "target_schema": "INFOPLUS",
            "trigger_fields": [],
            "primary_key":[],
            "load_action" : "append"
        }
     
    ],

    "integration_params": {
        "source": {
            "provider_name":"InfoPlus",
            "provider_type":"api",
            "creds": {
              "connection_type": "personaltoken",
              "personal_token":"yourtoken",
              "subdomain":"youdomaim",
              "apiversion":"v3.0",
              "lyft_token_email":"admin@lyftrondata.com"
          }
        },
        "target": {
            "provider_name": "snowflake",
            "provider_type": "db",
            "creds": {
                "hostname": "https://nl60162.ap-south-1.aws.snowflakecomputing.com",
                "account":"nl60162.ap-south-1",
                "username": "rusab",
                "password": "Blaze123!",
                "database": "WORK",
                "schema": "INFOPLUS",
                "warehouse": "UPLOAD",
                "role": "ACCOUNTADMIN"
            }
        },
        "die_on_error":false,
        "spark_jars":["driver jar names"],
        "row_count": 10000,
        "license": "QWERTY-ZXCVB-6W4HD-DQCRG"
    },
    "logging_options":{
        "cloud_type": "cloudwatch",
        "creds":{    
                "aws_access_key_id":"",
                "aws_secret_access_key":"",
                "region_name":""
                }
        }
    
}```