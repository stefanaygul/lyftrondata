import base64
import zlib
import json
import os
import getpass

# FLASK MODULES
from flask import Flask, request
from flask_restful import (Resource, Api, abort)
from flask_cors import CORS

# LYFTRONDATA MODULES
from Lyftrondata.Lyftrondata_Connector_Handler import Connect


app = Flask(__name__)
api = Api(app)
CORS(app)
MIME_TYPE = 'application/json'


def airflow_dag(integration_json):
    """Generates Airflow DAG based on provided Credentials

    Args:
        integration_json (dict): credentials for Integration

    Returns:
        tuple: (Boolen,string)

    """
    dir_path = os.path.dirname(os.path.realpath(__file__))
    print(dir_path)

    path_to_data = {
        'read': dir_path+'/data/template_read.txt',
        'write': dir_path+'/data/Lyftrodnatamirror_integration_template.txt',
        'runload': dir_path+'/data/Lyftrondatasync_integration_template.txt',
        'run_load_pipe': dir_path+'/data/Lyftrondatasync_integration_subtasks_template.txt',
        'write_load_pipe':dir_path+'/data/Lyftrodnatamirror_integration_subtasks_template.txt',
        'airflow_dag':dir_path+'/data/Lyftrondata_rehab_template.txt'
    }

    try:
        LOAD_OBJECT = ''
        LOAD_OBJECT_RELATIONSHIP = ''
        integration_type = integration_json['type']

        if integration_type == "runload":
            with open(path_to_data['run_load_pipe'], "r") as pipe_template_obj:
                pipe_template = pipe_template_obj.read()

            for index,pipeline in enumerate(integration_json['pipelines']):
                pipeline['pipeline_count'] = index            
                pipe_template_replaced = pipe_template.replace(
                    "#PIPELINE", str(pipeline))
                print(pipeline)
                pipeline['source_table'] = pipeline['source_table'].replace(
                    " ", "_").replace("-", "")
        
                LOAD_OBJECT = LOAD_OBJECT + \
                    pipe_template_replaced.replace(
                        "#TABLE_NAME", pipeline['source_table']) + '\n'
                LOAD_OBJECT_RELATIONSHIP = LOAD_OBJECT_RELATIONSHIP + \
                    f" >> {pipeline['source_table']}_pipeline"

            with open(path_to_data[integration_type], "r") as dag_template:
                template = dag_template.read()
                if integration_json['lyftron_options']:
                    integration_json['lyftron_options']['target'] = integration_json['integration_params']['target']
                lyftron_options = integration_json['lyftron_options'] 
                filesystem_options = integration_json['filesystem_options'] 
                logging_options = integration_json['logging_options'] 
                template = template.replace('#LOGGING_OPTIONS',str(logging_options))
                template = template.replace('#LYFTRONDATA_OPTIONS',str(lyftron_options))
                template = template.replace('#filesystem_options',str(filesystem_options))
                template = template.replace('#INTEGRATION_JSON', str(integration_json['integration_params'])
                                            ).replace('#LOADS', LOAD_OBJECT
                                                      ).replace('#LOAD_RELATION', LOAD_OBJECT_RELATIONSHIP
                                                                ).replace("#DAG_PARAMS", str(integration_json['dag_params']))

                dag_id = integration_json['dag_params']['dag_id']

        elif integration_type == 'write':
            with open(path_to_data['write_load_pipe'], "r") as pipe_template_obj:
                pipe_template = pipe_template_obj.read()

            for pipeline in integration_json['pipelines']:
                
                pipeline['pipeline_id'] = f"{pipeline['source_table']}_pipeline"
                pipe_template_replaced = pipe_template.replace(
                    "#PIPELINE", str(pipeline))
                print(pipeline)
                pipeline['source_table'] = pipeline['source_table'].replace(
                    " ", "_").replace("-", "")
                LOAD_OBJECT = LOAD_OBJECT + \
                    pipe_template_replaced.replace(
                        "#TABLE_NAME", pipeline['source_table']) + '\n'
                LOAD_OBJECT_RELATIONSHIP = LOAD_OBJECT_RELATIONSHIP + \
                    f" >> {pipeline['source_table']}_pipeline"

            with open(path_to_data[integration_type], "r") as dag_template:
                template = dag_template.read()
                logging_options = None if 'logging_options' not in integration_json else integration_json['logging_options'] 
                template = template.replace('#LOGGING_OPTIONS',str(logging_options))
                template = template\
                    .replace('#INTEGRATION_JSON', str(integration_json['integration_params']))\
                    .replace('#LOADS', LOAD_OBJECT)\
                    .replace('#LOAD_RELATION', LOAD_OBJECT_RELATIONSHIP)\
                    .replace("#DAG_PARAMS", str(integration_json['dag_params']))

                dag_id = integration_json['dag_params']['dag_id']
 
        elif integration_type == 'airflow_dag':
            with open(path_to_data[integration_type], "r") as dag_template:
                template = dag_template.read()
                
                logging_options = None if 'logging_options' not in integration_json else integration_json['logging_options'] 
                template = template.replace("#POST_DETAILS", str(integration_json['post_details'])).replace("#DAG_PARAMS", str(integration_json['dag_params']))

                dag_id = integration_json['dag_params']['dag_id']
        
        else:
            abort(404, message="integration Type ('read' or 'write') not provided!")

        airflow_path = os.getenv("AIRFLOW_HOME") + "/dags"
        dag_file_path = f"{airflow_path}/{dag_id}.py"

        if not os.path.exists(airflow_path):
            return False, "Airflow dag folder cannot be located. Kindly move to ~/airflow/dags"+airflow_path

        with open(dag_file_path, "w") as write_dag_file:
            write_dag_file.write(template)
        write_dag_file.close()
                
        return True, f"DAG {dag_id} Write Successfully!"

    except Exception as e:
        return False, str(e)


class CreateDAG(Resource):
    def post(self):
        content_type = request.headers.get('Content-Type')
        license_key = request.headers.get('LicenseKey')

        if not license_key:
            abort(400, message="LicenseKey Header is missing!")

        if license_key != "lyftrondata":
            abort(401, message="Invalid Licensekey")

        if (content_type == 'application/json'):
            # get integration json
            integration_json = json.loads(request.data)
            af_dag = airflow_dag(integration_json)

            # check if dag is true or false
            if not af_dag[0]:
                abort(404, message=af_dag[1])

            return af_dag[1]
        else:
            return 'Content-Type not supported!'

api.add_resource(CreateDAG, '/create_dag')

@app.route('/logs')
def log_read():
    query_params = request.args

    dag_id = query_params.get("dag-id")
    pipeline = query_params.get("stage-id")
    date = query_params.get("date")
    date = date.replace(" ", "+")
    log_id = query_params.get("log-number", None)
    LOG_DIR = os.getenv("AIRFLOW_HOME") + "/logs/"

    if pipeline is not None and pipeline is not None and date is not None:
        if log_id is None:
            try:
                LOG_PATH = f"{dag_id}/{pipeline}/{date}/"

                logs_files = [                 
                    os.path.join(LOG_DIR + LOG_PATH, f)
                    for f in os.listdir(LOG_DIR + LOG_PATH)
                    if f.endswith(".log")
                ]
                logs = {}
                for i, each_file in enumerate(logs_files):
                    with open(each_file) as f:
                        txt = f.read().encode('utf-8')
                        compress = zlib.compress(txt)
                        encode = base64.b64encode(compress)
                        logs[i + 1] = str(encode)
                        txt = f.read().encode('utf-8')
                        compress = zlib.compress(txt)
                        encode = base64.b64encode(compress)
                        logs[i + 1] = str(encode)
            except Exception as e:
                response = app.response_class(
                    response=json.dumps({"Error": str(e)}),
                    status=500,
                    mimetype=MIME_TYPE
                )
                return response
        else:
            try:
                LOG_PATH = f"{dag_id}/{pipeline}/{date}/{log_id}.log"
                with open(LOG_DIR + LOG_PATH) as f:
                    txt = f.read()
                    logs = str(base64.b64encode(
                        zlib.compress(txt.encode('utf-8'))))

            except Exception as e:
                response = app.response_class(
                    response=json.dumps({"error": str(e)}),
                    status=500,
                    mimetype=MIME_TYPE
                )
                return response

        data = json.dumps({
            "dag": dag_id,
            "encoding": "utf-8",
            "compression_method": "base64-zlib",
            "data": logs,
        })

        response = app.response_class(
            response=data,
            status=200,
            mimetype=MIME_TYPE
        )
        return response
    else:
        response = app.response_class(
            response=json.dumps(
                {"Error": "dag-id, stage-id or date is not provided"}),
            status=400,
            mimetype=MIME_TYPE
        )
        return response

def connetion(con: object, command: str, connector_name: str, creds: dict):
    return con.runcommand({
        'class_import': connector_name,
        'command': command,
        'variables': creds
    })

@app.route('/authtoken', methods=['POST'])
def handler_auth():
    """
    Json Body:
    ```json
    {
        "source": {
            "connector": "",
            "creds": {
                "connection_type": "",
                "subdomain": "",
                "username": "",
                "password": ""
            }
        },
        "license": ""
    }
    ```
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)

            if source is not None and licence is not None:
                connector_name = source.get('connector', "")
                creds = source.get('creds')

                con = Connect(licence)
                status, token = connetion(con, "initialize", connector_name, creds)
                resp = json.dumps(dict(status=status, token=token))
                status_code = 200 if status else 400
                return app.response_class(response=resp, status=status_code, mimetype=MIME_TYPE)

        except Exception as e:
            error = json.dumps({"error": str(e)})
            return app.response_class(response=error, status=500, mimetype=MIME_TYPE)
    else:
        error = json.dumps({"error": "Invalid Request Method"})
        return app.response_class(response=error, status=500, mimetype=MIME_TYPE)

@app.route('/executequery', methods=['POST'])
def handler_execute_query():
    """
    Example Body:

    ```json
    {
        "source": {
            "connector": "Gorgias",
            "creds": {
                "connection_type": "basicauth",
                "subdomain": "pethonesty",
                "username": "data@pethonesty.com",
                "password": "0715c1c33f52504a06e393110847421157f87976f901a8e46f3c64e0b4e4d880"
            }
        },
        "license": "QWERTY-ZXCVB-6W4HD-DQCRG",
        "query": "select * from users"
    }
    ```
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            query = request.json.get('query')

            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")

                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)

                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "execute_query",
                        "provider_engine_obj": token,
                        "query": query
                    }
                    status, response = con.runcommand(handler_param)
                    resp = json.dumps(
                        {"status": status, "data": response.to_dict('record')})
                    status_code = 200 if status else 400
                    return app.response_class(response=resp, status=status_code, mimetype=MIME_TYPE)
                else:
                    return app.response_class(
                        response=json.dumps({"Error": "Null Token"}),
                        status=400,
                        mimetype=MIME_TYPE
                    )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/fetchdatafromapi", methods=['POST'])
def handler_fetch_data():
    """
    fetchDataFromAPI Example

    ```json
    {
        "source": {
            "connector": "Gorgias",
            "creds": {
                "connection_type": "basicauth",
                "subdomain": "pethonesty",
                "username": "data@pethonesty.com",
                "password": "0715c1c33f52504a06e393110847421157f87976f901a8e46f3c64e0b4e4d880"
            }
        },
        "license": "QWERTY-ZXCVB-6W4HD-DQCRG",
        "table": ""
    }
    ```
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            table = request.json.get('table')

            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")

                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)

                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "fetchDataFromAPI",
                        "provider_engine_obj": token,
                        "variables": {
                            "table": table
                        }
                    }
                    response = con.runcommand(handler_param)

                    resp = json.dumps(response)
                    return app.response_class(
                        response=resp,
                        status=200,
                        mimetype=MIME_TYPE
                    )
                else:
                    return app.response_class(
                        response=json.dumps({"Error": "Null Token"}),
                        status=400,
                        mimetype=MIME_TYPE
                    )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/schemalist", methods=['POST'])
def handler_get_schema_list():
    """
    {
        "source": {
            "connector": "Gorgias",
            "creds": {
                "connection_type": "basicauth",
                "subdomain": "pethonesty",
                "username": "data@pethonesty.com",
                "password": "0715c1c33f52504a06e393110847421157f87976f901a8e46f3c64e0b4e4d880"
            }
        },
        "license": "QWERTY-ZXCVB-6W4HD-DQCRG",
    }
    """

    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")

                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)

                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "get_schema_list",
                        "provider_engine_obj": token,
                    }
                    status, response = con.runcommand(handler_param)
                    if status:
                        resp = json.dumps(
                            {"status": status, "schema": response})
                        return app.response_class(
                            response=resp,
                            status=200,
                            mimetype=MIME_TYPE
                        )
                    if status:
                        resp = json.dumps(
                            {"status": status, "schema": response})
                        return app.response_class(
                            response=resp,
                            status=200,
                            mimetype=MIME_TYPE
                        )
                    else:
                        resp = json.dumps(
                            {"status": status, "schema": "Failed to get Schema List"})
                        return app.response_class(
                            response=resp,
                            status=400,
                            mimetype=MIME_TYPE
                        )
                else:
                    return app.response_class(
                        response=json.dumps({"Error": "Null Token"}),
                        status=400,
                        mimetype=MIME_TYPE
                    )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/schemaobjects", methods=['POST'])
def handler_get_schema_objects():
    """
    {   
        "source": {},
        "license": "",
        "table": ""
    }
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")

                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)
                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "get_schema_list",
                        "provider_engine_obj": token,
                    }
                    status, response = con.runcommand(handler_param)

                    if status:
                        handler_param = {
                            'class_import': connector_name,
                            'command': "get_schema_objects",
                            "provider_engine_obj": token,
                            "schema_and_object_list": [{"schema_name": response[0], "object_list": ['TABLE', "VIEW"]}]
                        }
                        status, response = con.runcommand(handler_param)
                        if status:
                            resp = json.dumps(
                                {"status": status, "schema": response})
                            return app.response_class(
                                response=resp,
                                status=200,
                                mimetype=MIME_TYPE
                            )
                        else:
                            resp = json.dumps(
                                {"status": status, "message": response})
                            return app.response_class(
                                response=resp,
                                status=400,
                                mimetype=MIME_TYPE
                            )
                    else:
                        return app.response_class(
                            response=json.dumps({"Error": "Null Token"}),
                            status=400,
                            mimetype=MIME_TYPE
                        )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/testconnection", methods=['POST'])
def handler_test_connection():
    """
    {
        "source": {},
        "license": "",
    }
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")
                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)
                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "test_connection",
                        "provider_engine_obj": token,
                    }
                    status, response = con.runcommand(handler_param)
                    if status:
                        resp = json.dumps({"status": status})
                        return app.response_class(
                            response=resp,
                            status=200,
                            mimetype=MIME_TYPE
                        )
                    else:
                        resp = json.dumps(
                            {"status": status, "message": response})
                        return app.response_class(
                            response=resp,
                            status=400,
                            mimetype=MIME_TYPE
                        )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/schemaobjectcolumns", methods=['POST'])
def handler_get_object_columns():
    """
    ```json
    {
        "source": {},
        "license": "",
        "table_list": [""],
        "view_list": []
    }```
    """
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")
                table_list = request.json.get('table_list', [])
                view_list = request.json.get("view_list", [])
                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)
                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "get_object_columns",
                        "provider_engine_obj": token,
                        "schema_and_object_list": [{"schema_name": f'Lyftrondata_{connector_name}_Connector', "object_list": [{'TABLE': table_list, "VIEW": view_list}]}]
                    }
                    status, response = con.runcommand(handler_param)
                    if status:
                        resp = json.dumps(
                            {"status": status, "schema": response})
                        return app.response_class(
                            response=resp,
                            status=200,
                            mimetype=MIME_TYPE
                        )
                    else:
                        resp = json.dumps(
                            {"status": status, "message": response})
                        return app.response_class(
                            response=resp,
                            status=400,
                            mimetype=MIME_TYPE
                        )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/installconnector", methods=['GET'])
def install_connector():
    query_params = request.args
    connector_name = query_params.get("connector_name", None)
    
    PATH = "/home/lyftrondata/Python%20Drivers/production/2022/Non-Encoded/V1"
    VENV_PATH = "/home/lyftrondata/airflow_venv/lib/python3.9/site-packages/Lyftrondata/"
    try:
        
        if connector_name is not None and request.method == "GET":
            wheel_path = f"Lyftrondata_{connector_name}_Linux_3.9-0.0.1-py3-none-any.whl"
            full_path = os.path.join(PATH, wheel_path)

            if os.path.exists(full_path):
                if os.path.exists(f"{VENV_PATH}{connector_name}"):
                    resp = json.dumps({"Message": "Already Installed on Our System"})
                    return app.response_class(response=resp,status=409, mimetype=MIME_TYPE)
                else:
                    try:
                        os.system(f'pip install {full_path}')
                    except Exception as e:
                        return app.response_class(response=json.dumps({"Message": f"{str(e)}"}),status=400,mimetype=MIME_TYPE)
                    else:
                        return app.response_class(response=json.dumps({"Message": f"Package Installed"}),status=200,mimetype=MIME_TYPE)
            else: 
                return app.response_class(response=json.dumps({"Message": f"Package Not Found in Production"}),status=404, mimetype=MIME_TYPE)
        else:
            return app.response_class(response=json.dumps({"Message": f"Invalid Connector Name or Name is not provided"}), status=400, mimetype=MIME_TYPE)
    except Exception as e:
        return app.response_class(response=json.dumps({"Message": str(e)}), status=500, mimetype=MIME_TYPE)

@app.route("/importengine", methods=['POST'])
def handler_import_engine():
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")
                con = Connect(licence)
                status_init, token = connetion(con, "initialize", connector_name, creds)
                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "import_engine",
                        "provider_engine_obj": token,
                    }
                    response = con.runcommand(handler_param)
                    resp = json.dumps({"status": status_init, "engine": str(response)})
                    return app.response_class(
                        response=resp,
                        status=200,
                        mimetype=MIME_TYPE
                    )
            else:
                return app.response_class(
                    response=json.dumps({"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

@app.route("/urlmaker", methods=['POST'])
def handler_url_maker():
    if request.method == 'POST':
        try:
            source = request.json.get('source', None)
            licence = request.json.get('license', None)
            if source is not None:
                connector_name = source.get('connector')
                creds = source.get("creds")
                con = Connect(licence)
                status_init, token = connetion(
                    con, "initialize", connector_name, creds)
                if status_init:
                    handler_param = {
                        'class_import': connector_name,
                        'command': "url_maker",
                        "provider_engine_obj": token,
                        "variables": {
                            "subdomain":  request.json.get('subdomain'),
                            "response_type": request.json.get('code'),
                            "scope": request.json.get('scope')
                        } 
                    }
                    response = con.runcommand(handler_param)
                    resp = json.dumps({"status": True, "url": response})
                    return app.response_class(
                        response=resp,
                        status=200,
                        mimetype=MIME_TYPE
                    )
            else:
                return app.response_class(
                    response=json.dumps(
                        {"Error": "Source creds is not provided"}),
                    status=400,
                    mimetype=MIME_TYPE
                )
        except Exception as e:
            return app.response_class(
                response=json.dumps({"error": str(e)}),
                status=500,
                mimetype=MIME_TYPE
            )
    else:
        return app.response_class(
            response=json.dumps({"error": "Invalid Request Method"}),
            status=500,
            mimetype=MIME_TYPE
        )

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5009)
    