import importlib


class Connect:

    def __init__(self, LicenseKey):
        self.LicenseKey = LicenseKey
        self.class_instance = None

    def runcommand(self, json_params):

        """
        Description:
            This method run the commands of modules which provided are by user
            in json format.

        Return:
            Returns the Command responses provided using json.

        """
        # THIS METHOD WILL IMPORT REQIUIRED MODULE AND RETURN THE RESPONSE
        # BASED ON PROVIDED JSON
        
        command = json_params['command']
        class_import = f"Lyftrondata.{json_params['class_import']}.lib.Lyftrondata_{json_params['class_import']}_Connector"
        variables = json_params.get('variables', '')

        # Create connector class instance
        modules = importlib.import_module(class_import)
        if self.class_instance is None:
            self.class_instance = getattr(modules, 'Connect')(self.LicenseKey)

        if command == 'initialize':
            if 'code' in variables:
                # IF CODE IS PROVIDED IN JSON WILL RUN THIS PART
                # ELSE GUI BASED AUTHENTICATION WILL BE USED ON PLATFORM WHERE DRIVER IS INSTALLED.
                self.class_instance.code = variables['code']
                del variables['code']
            if json_params.get('dataset', None):
                dataset = json_params['dataset']
                connector_method_response = self.class_instance.initialize(**variables)
            else:
                connector_method_response = self.class_instance.initialize(**variables)

        elif command == 'test_connection':
            provider_engine_obj = json_params['provider_engine_obj']
            connector_method_response = getattr(self.class_instance, command)(provider_engine_obj)

        elif command == 'import_engine':
            connector_method_response = getattr(modules, 'engine')

        elif command == 'get_schema_list':
            provider_engine_obj = json_params['provider_engine_obj']
            connector_method_response = getattr(self.class_instance, command)(provider_engine_obj)

        elif command == 'get_schema_objects':
            provider_engine_obj = json_params['provider_engine_obj']
            schema_and_object_list = json_params['schema_and_object_list']
            connector_method_response = getattr(self.class_instance, command)(provider_engine_obj,
                                                                              schema_and_object_list)

        elif command == 'get_object_columns':
            provider_engine_obj = json_params['provider_engine_obj']
            schema_and_object_list = json_params['schema_and_object_list']
            if json_params.get('read_json', None):
                connector_method_response = getattr(self.class_instance, command)(provider_engine_obj,
                                                                              schema_and_object_list,read_json=json_params['read_json'])
            else:
                connector_method_response = getattr(self.class_instance, command)(provider_engine_obj,
                                                                                  schema_and_object_list)
      
        elif command == 'get_schema_object_and_columns':
            provider_engine_obj = json_params['provider_engine_obj']
            schema_and_object_list = json_params['schema_and_object_list']
            connector_method_response = getattr(self.class_instance, command)(provider_engine_obj,
                                                                              schema_and_object_list)

        elif command == 'execute_query':
            if 'subdomain' in variables:
                # IF API REQUIRED SUBDOMAIN THEN THIS PART OF CODE WILL RUN
                self.class_instance.subdomain = variables.get('subdomain', '')
                del variables['subdomain']
            if 'token' in variables:
                self.class_instance.token = variables.get('token', '')
                del variables['token']
            provider_engine_obj = json_params['provider_engine_obj']
            connector_method_response = getattr(self.class_instance, command)(json_params["query"], provider_engine_obj)

        elif command == 'url_maker':
            # IMPORTING UTILS MODULE
            utils =  f"Lyftrondata.{json_params['class_import']}.lib.Lyftrondata_{json_params['class_import']}_utils"
            utils_modules = importlib.import_module(utils)

            # CALLING HANDLER CLASS
            utils_method = getattr(utils_modules, 'Lyftrondata_authHandler')

            # CREATING INSTANCE OF PARAMETERS
            auth_url = self.class_instance.auth_url
            scopes = self.class_instance.scope

            # IF AUTHENTICATION REQUIRED SUBDOMAINS WILL RUN THIS PART
            if auth_url.__contains__('SUBDOMAIN'):
                subdomain = variables['subdomain']
                auth_url = auth_url.replace('SUBDOMAIN', subdomain)
                # REMOVING SUBDOMAIN VARIBALE TO AVOID UNWANTED KEY
                del variables['subdomain']

            # IF VARIABLE ISN'T DEFINED BY USER THEN LYFTRONDATA PROVIDED SCOPE WILL BE CALLED
            if 'scope' not in variables:
                variables['scope'] = scopes
            variables['response_type'] = 'code'
            connector_method_response = utils_method().url_maker(auth_url, variables)

        elif command == 'fetchDataFromAPI':
            print("printing from handler")
            print(variables)
            # PROVIDING TOKEN FROM JSON\
            if 'subdomain' in variables:
                # IF API REQUIRED SUBDOMAIN THEN THIS PART OF CODE WILL RUN
                self.class_instance.subdomain = variables['subdomain']
                del variables['subdomain']
            if 'token' in variables:
                self.class_instance.token = variables['token']
                del variables['token']
            connector_method_response = self.class_instance.fetchDataFromAPI(**variables)

        elif command == 'streaming':
            connector_method_response = self.class_instance.streaming(**variables)

        elif command == 'object':
            ## THIS WILL RETURN YOU AN OBJECT OF CONNECT CLASS
            connector_method_response = getattr(modules, f'Connect')(self.LicenseKey)
        
        else:
            try:
                connector_method_response = getattr(self.class_instance, command)(**variables)

            except AttributeError as e:
                return e

        return connector_method_response
