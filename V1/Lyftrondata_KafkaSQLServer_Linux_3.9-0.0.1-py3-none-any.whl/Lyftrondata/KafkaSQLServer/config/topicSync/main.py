from kafka import KafkaConsumer
from os import path
import os
import json
import logging
from datetime import datetime
import os

dir = os.path.dirname(__file__)
logPath = "@@logFilesPath@@"
logFileName = f"{datetime.utcnow().strftime('%Y%m%d')}.log"
logging.basicConfig(filename=f"{logPath}/{logFileName}", level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")

consumer = KafkaConsumer(bootstrap_servers=['localhost:9092'])
consumer.subscribe(topics=@@topics@@)
print("checking for messages")
print(consumer)

for message in consumer:
    try:
        # message value and key are raw bytes -- decode if necessary!
        #eg., for unicode: message.value.decode('utf-8')
        topic = message.topic
        msg = message.value
        if msg is not None:
            msg = json.loads(message.value)
            row = msg['payload']
            previous = row['before']
            updated = row['after']

            logging.info(f"Retrieved data from kafka")
            if updated is not None:

                filename = os.path.join(dir, 'data/' + topic + '.json')
                data = []

                # Check if file exists
                if path.isfile(filename) is False:
                    open(filename,"w+")
                    data = data
                else:
                    # Read JSON file
                    with open(filename) as fp:
                        data = json.load(fp)

                data.append(updated)

                with open(filename, 'w+') as json_file:
                    json.dump(data, json_file,
                                        indent=4,
                                        separators=(',',': '))
    except Exception as err:
        logging.error(str(err))
