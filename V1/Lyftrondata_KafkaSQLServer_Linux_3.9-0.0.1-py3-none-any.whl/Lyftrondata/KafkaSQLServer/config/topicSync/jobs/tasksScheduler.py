import schedule
import time
from dataSendToSparkJob import job

# Task scheduling
# After every 1mins geeks() is called.
schedule.every(1).minutes.do(job)
print('working....')

while True:

    # Checks whether a scheduled task
    # is pending to run or not
    schedule.run_pending()
    time.sleep(1)
