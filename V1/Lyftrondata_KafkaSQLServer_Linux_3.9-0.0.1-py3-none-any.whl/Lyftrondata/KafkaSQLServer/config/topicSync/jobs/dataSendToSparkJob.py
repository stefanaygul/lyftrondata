from datetime import datetime
from os import path
import requests
import os
import json
import logging
from datetime import datetime

def job():
    topics = @@topics@@
    target = @@targetCred@@
    format = "@@format@@"
    mode = "@@mode@@"
    type = "@@type@@"
    targetSchema = "@@targetSchema@@"
    sourceSchema = "@@sourceSchema@@"
    dir = os.path.dirname(__file__)
    logPath = "@@logFilesPath@@"
    logFileName = f"{datetime.utcnow().strftime('%Y%m%d')}.log"
    logging.basicConfig(filename=f"{logPath}/{logFileName}", level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
    NumOfRecords = 1001
    pipelines = []

    try:
        for topic in topics:
            filename = os.path.join(dir, '../data/' + topic + '.json')
            if path.isfile(filename) is True:

                table = topic.split('.')[2]
                target['table'] = table
                description = f"Kafka to airflow for table {table}"
                # Read JSON file
                with open(filename) as fp:
                    data = json.load(fp)
                    if len(data) != 0:
                        apiData = data[0:NumOfRecords]

                        if len(apiData) != 0:
                            logging.info(f"Table: {table}, {len(apiData)} records are ready to sending airflow")

                            pipelines.append({
                                "source_table": table,
                                "source_schema": sourceSchema,
                                "target_table": table,
                                "target_schema": targetSchema,
                                "load": apiData,
                                "load_action": mode
                            })

                            del data[0:NumOfRecords]
                            with open(filename, 'w+') as json_file:
                                json.dump(data, json_file,
                                                    indent=4,
                                                    separators=(',',': '))
                        else:
                            print("Api data is empty")               
                    else:
                        print("Data is empty")
            else:
                print("File " + topic + ".json does not exist")

        if len(pipelines) != 0:

            dagId = 'DS1_DEVPY_LX_' + datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
            reqData = {
                "type": type,
                "dag_params":{
                    "dag_id": dagId,
                    "schedule_interval": None,
                    "start_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "description" : description
                },
                "pipelines": pipelines,
                "integration_params":{
                    "target": target,
                    "format": format
                }
            }

            headers = {"Content-Type": "application/json", "LicenseKey": "lyftrondata"}
            response = requests.post("@@integrationTargetServerUrl@@", json=reqData, headers=headers)
            logging.info(f"Airflow api response: {response.status_code}")
            logging.info(f"Airflow api status code: {response.text}")

        else:
            print("Pipelines are empty")
    except Exception as err:
        logging.error(str(err))