import requests
import logging
from datetime import datetime
import os

dirname = os.path.dirname(__file__)
logPath = "@@logFilesPath@@"
logFileName = f"{datetime.utcnow().strftime('%Y%m%d')}.log"
logging.basicConfig(filename=f"{logPath}/{logFileName}", level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")

try:
    data = {
        "name": "@@connectorName@@",
        "config": {
            "connector.class": "io.debezium.connector.sqlserver.SqlServerConnector",
            "tasks.max": "1",
            "database.hostname": "@@hostName@@",
            "database.port": "@@port@@",
            "database.user": "@@user@@",
            "database.password": "@@password@@",
            "database.dbname": "@@dbName@@",
            "database.server.name": "@@serverName@@",
            "schema.include": "@@schema@@",
            "table.include.list": "@@tables@@",
            "database.history.kafka.bootstrap.servers": "kafka:9092", 
            "database.history.kafka.topic": "dbhistory.@@serverName@@" 
        }
    }
    url = "http://localhost:8083"
    headers = {"Content-Type": "application/json"}

    response = requests.post(url+"/connectors", json=data, headers=headers)
    logging.info(f"Connector is initializing to kafka")
    logging.info(f"Connector api response: {response.text}")
    logging.info(f"Connector api status code: {response.status}")
except Exception as err:
    logging.error(str(err))
