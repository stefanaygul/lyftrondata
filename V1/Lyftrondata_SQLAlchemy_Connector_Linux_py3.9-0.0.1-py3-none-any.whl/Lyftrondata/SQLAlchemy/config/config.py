CONNECTION_KEY_MAPPING = [
    {
        "lyftron_key": "enginename",
        "jdbc_key": "engine_name"
    },
    {
        "lyftron_key": "username",
        "jdbc_key": "username"
    },
    {
        "lyftron_key": "password",
        "jdbc_key": "password"
    },
    {
        "lyftron_key": "hostname",
        "jdbc_key": "host"
    },
    {
        "lyftron_key": "port",
        "jdbc_key": "port"
    },
    {
        "lyftron_key": "database",
        "jdbc_key": "database"
    }
]
SQLAlchemy_CONN_STRING = f"enginename://username:password@hostname:port/database"
