import time
import pandas as pd
from Lyftrondata import payasyougo as pg 
import sqlalchemy as sa
from sqlalchemy import inspect
from sqlalchemy.exc import NoSuchTableError
from Lyftrondata.SQLAlchemy.config.config import CONNECTION_KEY_MAPPING
import json

class Connect:
    license_key = ""
    connector_name = "Lyftrondata_SQLAlchemy_Connector"
    logging = False
    logs_attenuation = 0

    def __init__(self, license_key):
        """ Constructor method to set product license key

        :param license_key: lyfron license key string
        """
        self.license_key = license_key

    def dict_mapping(jsn, connection_type):
        from Lyftrondata.SQLAlchemy.config import mapping
        
        mapping = mapping.MAPPING[connection_type]
        for m in mapping.keys():
            if jsn.get(m) is not None:
                jsn[mapping[m]] = jsn.pop(m)
        return jsn

    def initializeJson(self, logging=False , logs_attenuation = 0,creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'
        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            EndTime = time.time()
            self.payasyougo_check(StartTime, EndTime, self.initialize, str(e))
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : self.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : self.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : self.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : self.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : self.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : self.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : self.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : self.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : self.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : self.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : self.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : self.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : self.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "environment" : self.dict_mapping(init_jsn,connection_type).get('environment'),
            "logs_attenuation" : self.dict_mapping(init_jsn,connection_type).get('logs_attenuation') or init_jsn.get('logs_attenuation') or 0,
            "logging" : self.dict_mapping(init_jsn,connection_type).get('logging') or init_jsn.get('logging') or False

        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            status = f'Connection Successful!! \t Connection String ({str(init_jsn)})'
            EndTime = time.time()
            self.payasyougo_check(StartTime, EndTime, self.initializeJson,status)
            return init

        except Exception as e:
            status = f'Failed! \t Error ({str(e)}) '
            EndTime = time.time()
            self.payasyougo_check(StartTime, EndTime, self.initializeJson,status)
            raise Exception(e)

    def initialize(self, logging=False , logs_attenuation = 0, **credentials):
        """This method will validate database credentials and retrun sqlalchemy engine

        :param credentials: json object containing all information for database connection
        (host,port, username, password and database name)
        :return: tuple containing True/False and sqlalchemy engine object
        """
        start_time = time.time()
        self.logging = logging
        self.logs_attenuation = logs_attenuation
        try:
            connection_string = f"{credentials[CONNECTION_KEY_MAPPING[0]['lyftron_key']]}://" \
                                f"{credentials[CONNECTION_KEY_MAPPING[1]['lyftron_key']]}:" \
                                f"{credentials[CONNECTION_KEY_MAPPING[2]['lyftron_key']]}@" \
                                f"{credentials[CONNECTION_KEY_MAPPING[3]['lyftron_key']]}:" \
                                f"{credentials[CONNECTION_KEY_MAPPING[4]['lyftron_key']]}/" \
                                f"{credentials[CONNECTION_KEY_MAPPING[5]['lyftron_key']]}"

            engine_obj = sa.create_engine(connection_string)

            end_time = time.time()
            status = {
                "Status": "Success"
            }
            self.payasyougo_check(start_time, end_time, self.initialize, status)
            return True, engine_obj
        except KeyError as key_err:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(key_err)
            }
            self.payasyougo_check(start_time, end_time, self.initialize, status)
            return False, f"Missing following key in credential json: {key_err}"
        except Exception as e:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(e)
            }
            self.payasyougo_check(start_time, end_time, self.initialize, status)
            return False, str(e)

    def test_connection(self, engine_obj):
        """This method will connect to database

        :param engine_obj: sqlAlchemy engine object
        :return: tuple containing True/False at zero index and empty/error string at first index
        """
        start_time = time.time()

        try:
            engine_obj.connect()

            end_time = time.time()
            status = {
                "Status": "Success",
            }
            self.payasyougo_check(start_time, end_time, self.test_connection, status)
            return True, ''
        except Exception as e:
            end_time = time.time()
            status = {
                "Status": "Failed",
                "Error": str(e)
            }
            self.payasyougo_check(start_time, end_time, self.test_connection, status)
            return False, str(e)

    def execute_query(self, query, engine_obj):
        """This method will execute given query on provided sqlalchemy connection and will return its response

        :param engine_obj: sqlalchemy engine object
        :param query: query string
        :return: tuple containing True/False at zero index and dataframe/error string at first index
        """
        try:
            query_result = engine_obj.execute(query)
            if query_result.rowcount == -1:
                return True, 'Operation performed successfully'
            query_result_keys = list(query_result.keys())
            if query_result.rowcount != 0:
                query_result = query_result.fetchall()
                if len(query_result):
                    df = pd.DataFrame(query_result, columns=query_result_keys)
                    return True, df
                else:
                    return True, 0
            else:
                return True, 0
        except Exception as err:
            return False, str(err)

    def get_schema_list(self, engine_obj):
        """This method will return list of all schema in given sql alchemy engine object

        :param engine_obj: sqlalchemy engine object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        try:
            inspector = inspect(engine_obj)
            schemas = inspector.get_schema_names()
            return True, schemas
        except Exception as err:
            return False, str(err)

    def get_schema_objects(self, engine_obj, schema_and_object_list):
        """This method will return list of all tables in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(table_name)
                    elif schema_object == "VIEW":
                        schema_view_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        for view_name in schema_view_list:
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(view_name)
                    elif schema_object == "INDEX":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = inspector.get_indexes(table_name)
                            for index_name in schema_index_list:
                                response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                    index_name["name"])
            return True, response_data
        except Exception as err:
            return False, str(err)

    def get_object_columns(self, engine_obj, schema_and_object_list):
        """This method will return lst of columns in given schema objects

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    object_key = list(schema_object.keys())[0]
                    response_data[schema_and_object_dict["schema_name"]][object_key] = []

                    if object_key == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][table_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    elif object_key == "VIEW":
                        schema_view_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    # elif object_key == "INDEX":
                    #     schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                    #     for table_name in schema_table_list:
                    #         schema_index_list = inspector.get_indexes(table_name)
                    #         [
                    #             response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                    #                 index_name["name"]
                    #             )
                    #             for index_name in schema_index_list
                    #         ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def get_schema_object_and_columns(self, engine_obj, schema_and_object_list):
        """This method will return lst of all tables in given schema's

        :param engine_obj: sqlalchemy engine object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            inspector = inspect(engine_obj)
            response_data = {}
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            columns = inspector.get_columns(table_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][table_name]["columns"].append({
                                    "column": column["name"],
                                    "datatype": str(column["type"]).split("(")[0],
                                    "description": str(description)
                                })
                    elif schema_object == "VIEW":
                        schema_view_list = inspector.get_view_names(schema=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            columns = inspector.get_columns(view_name, schema=schema_and_object_dict["schema_name"])
                            for column in columns:
                                if "comment" not in column:
                                    description = ""
                                else:
                                    description = column["comment"]
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][view_name][
                                    "columns"].append({
                                        "column": column["name"],
                                        "datatype": str(column["type"]).split("(")[0],
                                        "description": str(description)
                                    })
                    elif schema_object == "INDEX":
                        schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = inspector.get_indexes(table_name)
                            [
                                response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                    index_name["name"]
                                )
                                for index_name in schema_index_list
                            ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def payasyougo_check(self, StartTime, EndTime, method,status):
        try:
            pg.measure_execution_time(
                self.LicenseKey, method, StartTime, EndTime, self.connector_name,status,logging=self.logging, logs_attenuation= self.logs_attenuation)
        
        except Exception as e:
            raise Exception("Server Error - contact help@lyftrondata.com")
