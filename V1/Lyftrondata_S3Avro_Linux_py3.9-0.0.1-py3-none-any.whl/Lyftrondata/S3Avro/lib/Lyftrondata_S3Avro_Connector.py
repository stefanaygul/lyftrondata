from sqlalchemy import create_engine
import pandas as pd
from sql_metadata import Parser
import requests
import math
import schedule
import time, datetime
from dateutil.tz import tzutc
import os
import re
import json
import concurrent.futures
import base64
import boto3 as bt
import pandas as pd
from io import BytesIO,StringIO
import fastavro as fa

from Lyftrondata.S3Avro.lib import Lyftrondata_S3Avro_utils as utils
from Lyftrondata.S3Avro.config import config
from Lyftrondata import settings
from Lyftrondata import payasyougo as pg

global Connector_name
Connector_name = "Lyftrondata_S3Avro_Connector"

pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)

data = []
gs = None
dt = None
lookUp = None
engine = create_engine('sqlite://')
engines = [['PostgreSQL', 'postgresql://scott:tisger@localhost/mydatabase'], ['Sql Server', 'mssql+pyodbc://scott:tiger@mydsn'],
           ['Oracle', 'oracle://scott:tiger@127.0.0.1:1521/sidname'], ['MySQL', 'mysql://scott:tiger@localhost/foo'], ['SQLite', 'sqlite:///foo.db']]
supportedEngines = pd.DataFrame(
    columns=['Engine Name', 'Example Connection'], data=engines, index=None)


##########################################################################
####   CONNECTIONS DATA PARSER FETCH DATA    ####
##########################################################################

class Connect:
    ##########################################################################
    #####   ALL CLASS VARIABLES    ####
    ##########################################################################

    dirname = os.path.dirname(__file__)
    token = None
    endpoints = dict()
    expired_time = None
    fetched_time = None
    client_id = None
    client_secret = None
    refresh_token = None
    redirect_uri = None
    worker = 10  # number of threads
    session = requests.Session()
    verify = True
    log_connection = True
    
    subdomain = ""
    code = None
    refreshtoken_url = ""
    base_url = "BASE_URL"
    auth_url = ""
    token_url = ""
    scope = ""
    bucket = ""
    aws_access_key_id = None
    __environment = ''
    aggregate = None
    StartTime = time.time()

    # LOG PARAMS
    logging_options = False
    log_connection = True
    load_data = dict()

    # Possible request exceptions that can be handled
    request_exceptions = {
        200: "Success",
        401: "401 Unauthorized - Invalid Credentials",
        403: "403 Forbidden - Access Denied",
        404: "404 Not Found - Content Not Found or Invalid Endpoint",
        400: "400 Bad Request - Invalid Request (provided tables aren't accurate contact help@lyftrondata.com)",
        429: "429 Too Many Requests - Rate Limit or Hourly Quota Exceeded",
        500: "500 Internal Server Error - API Server Down or Unavailable",
        501: "501 Not Implemented - API Endpoint Not Implemented",
        502: "502 Bad Gateway - API Server Down or Unavailable",
        503: "503 Service Unavailable - API Server Down or Unavailable",
        504: "504 Gateway Timeout - API Server Down or Unavailable",
        599: "599 Unknown Error - API Server Down or Unavailable"
    }

    authhandler = utils.Lyftrondata_authHandler()

    oauth_settings = {
        "auth_url": auth_url,
        "token_url": token_url,
        "auth_params": {'response_type': 'code', 'access_type': 'offline', 'prompt': 'consent'},
        "token_params": {'grant_type': 'authorization_code'},
        "token_headers": None,
        "token_data": None,  # set to None if no token data is required
    }

##########################################################################
#####   INITS    ####
##########################################################################

    def __init__(self, LicenseKey):
        self.LicenseKey = LicenseKey
        self.abs_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', ''))
        self.schema_path = f'{self.abs_path}/schema/{Connector_name}.json'.replace("_Connector",'')
        self.endpointjson = f'{self.abs_path}/config/{Connector_name}_endpoints.json'
        
    def __get_table_df(self,con,table):
        avro_records = []
        obj_resp = con.get_object(Bucket=self.bucket, Key=table)
        file_stream = obj_resp['Body'].read()
        f = BytesIO(file_stream)
        avro_reader = fa.reader(f)

        for record in avro_reader:
            avro_records.append(record)
            
        df = pd.DataFrame.from_dict(avro_records)
        if self.aggregate == True:
            df['Lyft_From_Source'] = table.replace("/data/","_lyft_")
        df.columns = df.columns.str.replace(' ','_')

        return df

    def __checkdtype(self,val):
        val = str(val)

        if val == 'int64':
            datatype = "int"

        elif val == 'bool':
            datatype = "boolean"

        elif val == "object":
            return "varchar(255)"

        elif val == 'datetime64':
            datatype = "datetime"

        elif val == 'float64':
            datatype = "float"

        else:
            datatype = "varchar(255)"

        return datatype

    def __get_schema(self,df):
        columns_list = []

        for col in df.columns:
            column = dict()
            column['column'] = col
            column['datatype'] = self.__checkdtype(df[col].dtype)
            column['description'] = ''
            columns_list.append(column)
        return columns_list
                
    def replacement(self, x):
        return x.replace('"', '').replace("'", '')

    def getMetadata(self):
        response = {
            'tables': {

            }
        }
        schemajson = os.path.join(self.dirname, Connector_name+"_schema.json")
        jsn = pd.read_json(schemajson, orient="records", typ="records")
        for k, v in jsn['Tables'].items():
            if k.__contains__('sys.'):
                pass
            else:
                response['tables'][k] = v

        return response

    def token_file_handler(self, token_file):
        with open(token_file, "r") as tokenfile:
            tokenjson = json.load(tokenfile)
        
        self.token = tokenjson.get('access_token')
        self.expired_time = tokenjson.get('expires_in')
        self.refresh_token = tokenjson.get('refresh_token')
        self.fetched_time = tokenjson.get('fetched_at')
        
        return self.token
    
    def getConnectorDefinition(self, param):

        if isinstance(param, str):
            csv = pd.read_csv(param)
            return csv.to_json(orient='records')
        else:
            engine = param['engine']
            db = param['db']
            name = param['name']
            user = param['user']
            password = param['password']
            host = param['host']
            port = param['port']
            engine = create_engine(
                engine+'://'+user+':'+password+'@'+host+':'+port+'/'+db)

            query = engine.execute(
                'select * from "Lyftrondata_Connector_Definition"')

            df = pd.DataFrame(query, columns=query.keys())
            return df.to_json(orient='records')

    def get_schema_tables(self):
        self.StartTime = time.time()

        """
        Returns a list of tables in the schema

        Returns: list of tables in the schema
        """
        try:
            tablelist = self.execute_query("select * from sys.tables")[1]
            tablelist = tablelist.loc[tablelist['datatype'] == 'table']
            data = tablelist.to_dict(orient='records')
            status = {
                'Status':'Success!'
                }
        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            data = e
        self.payasyougo_check(self.get_schema_tables,status)
        return data

    def get_table_columns(self, tables=[]):
        self.StartTime = time.time()

        """
        Get the columns of the table from the schema

        Parameters:
            tables (list): List of tables

        Returns:
            list: List of columns of the table
        """
        res = []
        try:
            jsn = json.load(open(self.schema_path))["Tables"]
            for k in jsn:
                if k in tables:
                    res.append(jsn[k])
            status = {
                'Status':'Success!'
                }

        except Exception as e:
            status = {
            'Status':'Failed!',
            "Error": str(e)
            }
            res = e

        self.payasyougo_check(self.get_table_columns,status)
        return res

    def get_schema_list(self,con):
        self.StartTime = time.time()
        arr = []
        res = []
        try:    
            if self.aggregate == True:
                status = {
                    "Status": "Success",
                    "Result": self.bucket
                }
                self.payasyougo_check(self.get_table_columns,status)
                return True , [self.bucket]

            result = con.list_objects_v2(Bucket=self.bucket
                                        )
            val = result.get('Contents')
            for v in val:
                dirf= ''
                if "/" in v['Key'] and ".avro" in v['Key']:
                    arr = v['Key'].split('/')
                    arr = arr[:-1]
                    
                    for a in arr:
                        dirf = dirf + a + '_lyft_' if arr.index(a) != len(arr) - 1 else dirf + a
                    if dirf not in res and dirf != '':
                        res.append(dirf)
            status = {"Status":"Success",
                       "Result":res}
            self.payasyougo_check(self.get_table_columns,status)
            return True, res

        except Exception as e:
            status = {"Status":"Failed!",
                    "Results":str(e)}
            self.payasyougo_check(self.get_table_columns,status)
            return False , str(e)
    
    def get_schema_objects(self,con,schemas):
        self.StartTime = time.time()
        res = []
        views = list()
        schema_obj = dict()
        try :  
            if self.aggregate == True:
                response = con.list_objects(Bucket=self.bucket)
                for content in response.get('Contents', []):
                    var = content['Key']
                    if '.avro' in var:
                        sp = var.split('/')[:-1]
                        if len(sp) > 1:
                            folder = ''
                            for dir in sp:
                                if dir != "data":
                                    folder = folder + dir + "_lyft_"  
                            sp = folder[:-6]
                        else:
                            sp =sp[0]
                        if sp not in res:
                            res.append(sp)

                schema_obj[self.bucket] = {
                    'TABLE':res,
                    'VIEW':views
                    }           
                status = {
                    'Status':'Success!',
                    "Result": schema_obj
                }
                self.payasyougo_check(self.get_schema_objects,status)
                return True, schema_obj

            for schema in schemas :
                schema = schema['schema_name'] if 'schema_name' in schema else schema
                table_path = schema.replace('_lyft_',"/data/")
                response = con.list_objects(Bucket=self.bucket, Prefix=table_path)
                for content in response.get('Contents', []):
                    var = content['Key']
                    if var.endswith('.avro'):
                        res.append(var.replace(".avro","").replace("/data/","_lyft_"))

                schema_obj[schema] = {
                                'TABLE':res,
                                'VIEW':views
                                }
                res = []
                views = []
            status = {
                    'Status':'Success!',
                    "Result": schema_obj
                }            
            self.payasyougo_check(self.get_schema_objects,status)
            return True, schema_obj

        except Exception as e:
            status = {"Status": "Failed!",
                        "Result": str(e)}
            self.payasyougo_check(self.get_schema_objects,status)
            return False , str(e)
        
    def get_object_columns(self,con,schema_obj,read_json=False):
        resp = dict()
        self.StartTime = time.time()
        try:
            if type(schema_obj) == list:
                for objects in schema_obj:
                    table_respone = list()
                    obj_name = objects['schema_name']
                    obj_name = obj_name.replace('_lyft_','/data/')
                    obj_list = objects['object_list']

                    for obj in obj_list:
                        if 'TABLE' in obj:
                            table_records = dict()
                            df = pd.DataFrame()
                            if self.aggregate == True:
                                df_avro = pd.DataFrame()
                                for table in obj['TABLE']:
                                    table_path = table+"/metadata/metadata.csv"
                                    try:
                                        csv_obj = con.get_object(Bucket=self.bucket, Key=table_path)
                                        body = csv_obj['Body']
                                        csv_string = body.read().decode('utf-8')
                                        df = pd.read_csv(StringIO(csv_string))
                                        df = df.fillna("")

                                        appendcolumns = [
                                            {'column':'Lyft_LastModified', 'datatype':'varchar(255)', 'description':''},
                                            {'column':'Lyft_Size', 'datatype':'int', 'description':''},
                                            {'column':'Lyft_From_Source', 'datatype':'varchar(255)', 'description':''}
                                        ]
                                        df.columns = df.columns.str.replace(' ','_')
                                        for cols in appendcolumns:
                                            df = df.append(cols,ignore_index=True)
                                        df = df.sort_values(by ='column' )
                                    except Exception as e:
                                        status = {
                                            "Status":"Failed!",
                                            "Result": str(e)
                                        }
                                    self.payasyougo_check(self.get_object_columns,status)
                                    table_records[table] ={
                                            'columns': df.to_dict('records'),
                                    }
                                obj_name = obj_name

                            else:   

                                for table in obj['TABLE']:
                                    table_path = table.replace("_lyft_",'/data/')
                                    df_avro = self.__get_table_df(con,table_path+".avro")
                                    df_avro = df_avro.reindex(columns=sorted(df_avro.columns))
                                    columns_list = self.__get_schema(df_avro)
                                    table_records[table] ={
                                        'columns': columns_list,
                                    }
                            table_respone.append(table_records)
                                
                        resp[obj_name] = {'TABLE':table_respone,
                                        'VIEW': []}
                status = {"status":'Success!'}
                self.payasyougo_check(self.get_object_columns,status)
                return True , resp
        except Exception as e:
            status = {"status":'Failed!',
                        "Result": str(e)}
            self.payasyougo_check(self.get_object_columns,status)
            return False, str(e)


##########################################################################
####   MAKE CONNECTOR REQUESTS FROM API   ####
##########################################################################
 
    def makeView(self, required_parameter, baseUrl, replaced_parameter, col=None, val=None, jsn=None, endpoint=None):
        """
        Description:
        [this method will be used when a person wants to filter per id(
            showing detailed explanantion). It will find key and then get responses of each record]

        Parameters:
            jsn ([list]): [contains the response of the main table ]
            required_parameter ([string]): [key so that we can filter against it ]
            base_url ([string]): [url to hit the main model/table]
            replaced_parameter ([string]) : key which have to be replaced by required parameter.
            endpoint ([string], optional): endpoint if required. default is None.

        """

        finalresponse = list()
        required_parameter = required_parameter.split('.')
        if col != None:
            if replaced_parameter in col:
                a = val[col.index(replaced_parameter)]
                value = str(a)
                url = baseUrl + \
                    endpoint.replace(replaced_parameter,
                                     self.replacement(value))
                response = self.req(url)
                if type(response) == list:
                    for i in response:
                        i[replaced_parameter] = self.replacement(str(a))
                else:
                    response[replaced_parameter] = self.replacement(str(a))

                finalresponse.append(response)
            return finalresponse

        a = jsn
        b = []
        urls = list()
        for item in jsn:
            a = item
            for k in required_parameter:
                a = a[k]
                url = baseUrl + endpoint.replace(replaced_parameter, str(a))
                urls.append(url)
                b.append(a)

        with concurrent.futures.ThreadPoolExecutor(max_workers=self.worker) as executor:
            futures = executor.map(self.req, urls)
            futures = list(futures)

        for i, d in zip(futures, b):
            if type(i) == list:
                for j in i:
                    j[replaced_parameter] = self.replacement(str(d))
            else:
                i[replaced_parameter] = self.replacement(str(d))

            finalresponse.append(i)

        return finalresponse

    def return_error(self, status_code, req):
        print(req.status_code, req.url)

        if isinstance(status_code, str):
            status_code = int(status_code)

        if status_code == 200:
            print("Connection to table [Success]")
            try:
                return True,req
                
            except Exception as e:
                return False, str(e)    

        elif status_code in self.request_exceptions:
            custom_exception = self.request_exceptions[status_code]
            return False, str(e)    

        else:
            return False, str(requests.exceptions.RequestException(
                f"{str(status_code)} AN UNKNOWN ERROR OCCURED"))

    def req(self, url, headers=None, params=None):
        """ This Function is used for making request on endpoints.

        Args:
            url (string): endpoint url
            headers (dict, optional): headers for the request if required. Defaults to None.
            params (dict, optional):  params for the request if required. Defaults to None.

        Returns:
            json: response from the endpoint in form of json/dict
        """
        if self.expired_time != None:
            isExpired = self.authhandler.check_expire_time(
                self.expired_time, self.fetched_time)
            print(f'is token expired ? {isExpired}')
            if isExpired == True and self.refresh_token != None:
                self.refreshtoken_url = self.refreshtoken_url.replace(
                    "SUBDOMAIN", self.subdomain)
                refreshtoken_params = {
                    'grant_type': 'refresh_token',
                    'refresh_token': self.refresh_token,
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'scope': self.scope
                }
                refresh = self.authhandler.refreshToken(self.token_file,
                                                        refreshtoken_url=self.refreshtoken_url,
                                                        refreshtoken_params=refreshtoken_params
                                                        )

                if 'expires_in' in refresh:
                    self.expired_time = refresh['expires_in']
                self.fetched_time = refresh['fetched_at']
                if 'refresh_token' in refresh:
                    self.refresh_token = refresh['refresh_token']
                self.token = refresh['access_token']
            elif isExpired == True and self.refresh_token == None:
                print("Token expired and refresh token not found")
                os.remove(self.token_file)
                return None

        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.token}',
        }

        req = self.session.get(url, headers=headers, data=data)

        return self.return_error(req.status_code, req)

##########################################################################
#  TEST CONNECTION TO API #####
##########################################################################

    def test_connection(self, obj):
        """
        Make a test connection to the API.

        Args:
            endpoint_path: 

        Returns:
            Message indicating the connection status.
        """
        if obj is not None:
            return True, ""
        else:
            return False, "Connection Error!"

##########################################################################
####   INTIALIZE AND LOAD USER CREDIENTIALS   ####
##########################################################################

    def initializeJson(self, creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        self.StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'
        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            status = {
                    'Connection String':'',
                    'Status': f'Failed! {str(e)}'
                        }
            self.payasyougo_check(self.initializeJson, status)
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : utils.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : utils.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : utils.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : utils.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : utils.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : utils.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : utils.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : utils.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : utils.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : utils.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : utils.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : utils.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : utils.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "environment" : utils.dict_mapping(init_jsn,connection_type).get('environment'),
            "logs_attenuation" : utils.dict_mapping(init_jsn,connection_type).get('logs_attenuation') or init_jsn.get('logs_attenuation') or 0,
            "logging" : utils.dict_mapping(init_jsn,connection_type).get('logging') or init_jsn.get('logging') or False

        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            del init_params['environment']
            status = {
                'Connection String' : init_params,
                'Status': 'Success!'
            }
            self.payasyougo_check(self.initializeJson,status)
            return init

        except Exception as e:
            del init_params['environment']
            status = {
                'Connection String' : init_params,
                'Status': f'Failed! {str(e)}'
            }            
            
            self.payasyougo_check(self.initializeJson,status)
            raise Exception(e)


    def initialize(self, connection_type=None, personal_token=None, client_id=None, client_secret=None, redirect_uri=None, subdomain=None,
                    username=None, password=None, lyft_token_email=None, 
                    access_key_id=None, secret_access_key=None, region_name=None, bucket=None,
                    aggregate=True,ssl=True,logging_options=False,**kwargs):
        
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            connection_type ([string], required): [provide the connection type "personalToken" if you want to access by personal token generated by API.
                                        or "OAuth2" if you want to provide credentials to get access].
            personal_token ([string], optional): [do provide personaltoken if you selected Connection_type as personalToken]. Defaults to None.
            client_id ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            client_secret ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            redirect_uri ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None.
            subdomain ([string], optional): [provided by API it is required if connection type is "OAuth2"]. Defaults to None. (If Required)
            username ([string], optional): [provided by API it is required if connection type is "basicAuth"]. Defaults to None.
            password ([string], optional): [provided by API it is required if connection type is "basicAuth"]. Defaults to None.

        Returns:
            token: access token which will be used as to make requests.
        """
        self.StartTime = time.time()
        self.aggregate = aggregate
        self.__environment = kwargs.get('environment') or None
        self.logging_options = logging_options
        self.verify = ssl
        self.subdomain = subdomain or ""
        self.client_id = client_id or ""
        self.client_secret = client_secret or ""
        redirect_uri = redirect_uri or ""
        username = username or ""
        password = password or ""
        personal_token = personal_token or ""

        connection_string = str({
            'connection_type':connection_type,
            "personal_token":personal_token, 
            "client_id":client_id, 
            "client_secret":client_secret,
            'redirect_uri':redirect_uri,
            "subdomain":subdomain,
            "username":username, 
            "password":password, 
            "lyft_token_email":lyft_token_email,
            'access_key_id':access_key_id,
            "secret_access_key":secret_access_key, 
            "region_name":region_name,
            'bucket':bucket,
            "aggregate":aggregate,
            "logging_options":self.logging_options
            })
                                    
        if lyft_token_email != None:
            self.token_file = f'{settings.BASE_DIR}/{lyft_token_email}_{Connector_name}_token.json'
        else:
            self.token_file = f'{settings.BASE_DIR}/{Connector_name}_token.json'

        # for development purposes (remove this line after connector is done)

        if connection_type.lower() == "personaltoken":
            self.token = personal_token

        elif connection_type.lower() == "basicauth":

            self.token = base64.b64encode(
                f"{username}:{password}".encode('utf-8')).decode('utf-8')

        elif connection_type.lower() == "oauth2":

            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file,
                            self.expired_time,
                            self.refresh_token,
                            self.fetched_time)
                self.payasyougo_check(self.initialize,status)
                return self.token

            else:
                self.auth_url = self.auth_url
                self.token_url = self.token_url

                self.oauth_settings['token_params']['client_id'] = self.client_id
                self.oauth_settings['token_params']['client_secret'] = self.client_secret
                self.oauth_settings['token_params']['redirect_uri'] = redirect_uri
                self.oauth_settings['auth_params']['client_id'] = self.client_id
                self.oauth_settings['auth_params']['scope'] = self.scope
                self.oauth_settings['auth_params']['redirect_uri'] = redirect_uri

                if self.code is not None:
                    self.oauth_settings['token_params']['code'] = self.code

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    with open(self.token_file, "w") as tokenjson:
                        json.dump(resp, tokenjson)
                else:
                    return resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        elif connection_type.lower() == "oauth2_client_credentials":

            if os.path.exists(self.token_file):
                self.token = self.token_file_handler(self.token_file,
                            self.expired_time,
                            self.refresh_token,
                            self.fetched_time)               
                self.payasyougo_check(self.initialize,status)
                return self.token

            else:
                self.auth_url = self.auth_url
                self.token_url = self.token_url

                self.oauth_settings['token_params'] = {
                    'client_id': self.client_id,
                    'client_secret': self.client_secret,
                    'grant_type': 'client_credentials',
                    'redirect_uri': redirect_uri
                }

                self.oauth_settings['auth_params'] = {}
                self.oauth_settings['token_headers'] = {
                    'Content-Type': 'application/x-www-form-urlencoded'}

                resp = self.authhandler.OAuthentication2(**self.oauth_settings)

                if resp != None:
                    self.token = resp['access_token']
                    with open(self.token_file, 'w') as f:
                        json.dump(resp, f)
                else:
                    return resp

                if 'expires_in' in resp:
                    self.expired_time = resp['expires_in']
                if 'refresh_token' in resp:
                    self.refresh_token = resp['refresh_token']
                self.fetched_time = resp['fetched_at']

        elif connection_type.lower() == "aws":
            self.bucket = bucket
            self.aws_access_key_id = access_key_id
        
            try:
                self.client = bt.client(
                    's3',
                    aws_access_key_id=access_key_id,
                    aws_secret_access_key=secret_access_key,
                    region_name=region_name
                )
                self.token = self.client
                
            except Exception as e:
                status = {
                    'Connection String':connection_string,
                    'Status': f'Failed! {str(e)}'
                }

                self.payasyougo_check(self.initialize,status)
                return False, self.token
        else:
            print("Provide the Connection Type: 'personalToken' or 'OAuth2' ")
            self.token = None

            status = {
                    'Connection String':connection_string,
                    'Status': 'Failed! (Invalid Connection Type)'
                }

            self.payasyougo_check(self.initialize,status)
            return False, self.token

        status = {
                'Connection String':connection_string,
                'Status': 'Success!'
                }

        self.payasyougo_check(self.initialize,status)
        return True, self.token

    
    def fetchDataFromAPI(self, table, parameter=None,from_page=None,to_page=None, parameterValue=None):
        """
        Description:
            This Method is used to fetch data from API specific endpoint.

        Parameters:
            table(string): table name or endpoint name.
            col(list[string]): contains the column names 'SELECT * FROM table Where col = value'.
            value(list[string]): contains the value of specified column.

        Returns:
            jsn(json) : json file contains the complete response fetched from endpoint 
        # """
        self.StartTime = time.time()
        fetchedData = dict()
        _df = pd.DataFrame()

        if self.aggregate == True:
            self.load_data = utils.read_wasabi(self.aws_access_key_id,self.bucket)
            
            time_format = '%Y-%m-%d %H:%M:%S%z'
            
            response = self.client.list_objects(Bucket=self.bucket,Prefix=table+"/data/")
            files = dict()
            for content in response.get('Contents', []):
                var = content['Key']
                if var.endswith('.avro'):
                    content_modified_date = content['LastModified']

                    if self.load_data and var in self.load_data[table]:
                        content_date = self.load_data[table][var]
                        
                        last_modified = datetime.datetime.strptime(content_date,
                                                time_format).replace(
                                                    tzinfo=tzutc()
                                                )
                        total_time = (content_modified_date - last_modified).total_seconds()

                        if int(total_time) > 0:
                            print(f"FETCHING UPDATED DATA FROM {var}")
                            df = self.__get_table_df(self.client,var)
                            df['Lyft_LastModified'] = content_modified_date
                            df['Lyft_size'] = content['Size']
                            _df = _df.append(df,ignore_index=True)
                        files[var]= str(content_modified_date)


                    else:
                        print(f"FETCHING UPDATED DATA FROM {var}")
                        df = self.__get_table_df(self.client,var)
                        df['Lyft_LastModified'] = content_modified_date
                        df['Lyft_size'] = content['Size']
                        _df = _df.append(df,ignore_index=True)
                        files[var]= str(content_modified_date)

            self.load_data = {table:files}
            utils.write_Wasabi(self.load_data,self.aws_access_key_id,self.bucket)
            _df = _df.reindex(sorted(_df.columns), axis=1)
            table_path = table
        else:
            table_path = table.replace("_lyft_","/data/")+".avro"
            _df = self.__get_table_df(self.client,table_path)
            _df = _df.reindex(sorted(_df.columns), axis=1)

        fetchedData = {table: _df.to_dict('records')}
        status = {            
            'Table': table,
            'Location': table_path,
            'Status': 'Success!',
            'Result': fetchedData
            }

        self.payasyougo_check(self.fetchDataFromAPI,status)

        return fetchedData


    def json_parse(self,jsn, main_table_name):

        """
        Description:
            This method is used to parse/Normalize the Json Response fetched from endpoint in a way where
            object and array will be consider as separate Dataframes.

        Parameters:
            jsn(json): json response which have to be normalize.
            main_table_name: Main endpoint Name where the response is fetched from.

        Return:
            dataframes(dict) : dictionary which contains all the key as tablename and value as Dataframes.
        """
        dataframe = None
        simple = dict()
        dataFrames = dict()
        for key in jsn:
            val = jsn[key]
            if type(val) == list:
                dataFrames[key] = pd.DataFrame(val)
            elif type(val) == dict:
                dataframe = pd.DataFrame.from_dict(
                    val, orient="index")
                dataFrames[key] = dataframe.transpose()
            else:
                simple[key] = val
        if not simple:
            return dataFrames
        else:
            datafr = pd.DataFrame.from_dict(simple,orient="index")
            dataFrames[main_table_name] =datafr.transpose()
            return dataFrames

##########################################################################
            ####   SCHEMA GENERATION AND SYSTEMS QUERIES   ####
##########################################################################
 
    def execute_query(self, query,provider_obj=None):
        """
        Description:
            This method is used to break the query such as tablename, column,values

        Parameter:
            query(string): Takes Query in String Format.

        Returns:
            Table(pandas.DataFrame): Returns the dataframe contains the queried table data.

        """

        self.StartTime = time.time()
        parameter = list()
        parameterValue = list()
        query = query.lower() 
        
        def __execute(table,parameter,parametervalue, from_page = None, to_page = None):
            if not bool(parameter) and not bool(parametervalue):
                parameter, parametervalue = None, None

            jsonres = self.fetchDataFromAPI(table,parameter,parametervalue, from_page, to_page)
            list_df = self.json_parse(jsonres, table)
            for df_name, df in list_df.items():
                self.dataToTable(df, df_name)

            try:
                r = engine.execute(query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True,df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        def __execute_sys(table,col):
            try :
                data = self.sysQueries(table,col)
                tablename = table.replace('.','_')
                self.dataToTable(data,tablename)
                modified_query = query.replace(table,tablename)
                r = engine.execute(modified_query)
                df_result = pd.DataFrame(r, index=None, columns=r.keys())
                df_result = df_result.drop(['index'], axis=1, errors='ignore')

                status = {
                    'Executed Query': [query],
                    'Status': 'Success!',
                    'Rows Fetched': str(df_result.shape[0])
                }
                self.payasyougo_check(self.execute_query,status)
                return True , df_result

            except Exception as e:
                status = {
                    'Executed Query': [query],
                    'Status': f'Failed! {str(e)}',
                    'Rows Fetched': 0
                }
                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        def __sql_query_tokenizer(query):
            """ Tokenize SQL query and return a list of tokens."""

            query = query.replace('\n', '').replace('  ', ' ')
            re_where_clause = re.compile(r'((\"|\')?([A-Za-z0-9_]+)(\"|\')?(\s+)?=(\s+)?(\"|\')?[A-Za-z0-9_]+(\"|\')?(\s+)?(and|or)?)+')
            re_lyftpage_clause = re.compile(r'(lyftpage(start|end)\s+[0-9]+)')

            where_clause = {}
            lyftpage_clause = {}

            columns = Parser(query).columns
            tables = Parser(query).tables
            limit = Parser(query).limit_and_offset

            for j in re.findall(re_where_clause, query):
                k = j[0]
                k = k.replace('"', '').replace("'", '')\
                    .replace(' and', "").replace(' or', '')\
                    .replace(' ', '')
                k = k.split('=')
                where_clause[k[0]] = k[1]

            lyft_page = re.findall(re_lyftpage_clause, query)
            is_pages = bool(lyft_page)

            if is_pages:
                query = re.sub(re_lyftpage_clause, '', query)
                    
            for j in lyft_page:
                k = j[0]
                k = k.split(' ')
                lyftpage_clause[k[0]] = k[1]
                
            return columns, tables, where_clause, lyftpage_clause, limit, query

        
        if query.__contains__("Describe"):
            try:
                
                t =query.split("Describe ")
                data = self.sysQueries("sys.Describe", t[1])
                status = {"Status": "Success!",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return True , data

            except Exception as e:

                status = {"Status": f"Failed! {str(e)}",
                        "Exceuted query" : f'[{query}]'}

                self.payasyougo_check(self.execute_query,status)
                return False, str(e)

        if query.__contains__("select"):
            columns, tables, where_clause, lyftpage_clause, limit, query = __sql_query_tokenizer(query)
            
            if query.lower().__contains__("sys."):
                return __execute_sys(tables[0],columns)

            else:
                if bool(lyftpage_clause) and bool(where_clause):
                    try:
                        if (lyftpage_clause.get('lyftpagestart', None) is not None):
                            from_page = lyftpage_clause['lyftpagestart']
                            from_page = int(from_page)
                            
                        if lyftpage_clause.get('lyftpageend', None) is not None:
                            to_page = lyftpage_clause['lyftpageend']
                            to_page = int(to_page)
                            
                        return __execute(
                            tables[0],
                            list(where_clause.keys()), 
                            list(where_clause.values()), 
                            from_page, to_page
                        )
                    except Exception as e:
                        print("Error: ", e)
                
                elif bool(lyftpage_clause):
                    try:
                        if (lyftpage_clause.get('lyftpagestart', None) is not None):
                            from_page = lyftpage_clause['lyftpagestart']
                            from_page = int(from_page)
                            
                        if lyftpage_clause.get('lyftpageend', None) is not None:
                            to_page = lyftpage_clause['lyftpageend']
                            to_page = int(to_page)

                        return __execute(
                            tables[0],
                            list(), 
                            list(),
                            from_page, to_page
                        )
                    except Exception as e:
                        print("Error: ", e)
                    
                
                elif bool(where_clause):
                    return __execute(
                        tables[0],
                        list(where_clause.keys()), 
                        list(where_clause.values())   
                    )
                else:
                    return __execute(tables[0],list(), list())
     

    def sysQueries(self,query,table):
        """
        Description:
            System Queries Method is used to fetch information schema from the system query.
                following are tableName:
                    (sys.table, sys.contraint, sys.delta, sys.methods, sys.logs, sys.usage, sys.license
                    sys.connectionstring, sys.version)
        Parameters:
            query: System table name.
        """

        qury = query.split(".")
        command = qury[1]
        jsn = pd.read_json(self.schema_path, orient="records", typ="records")

        if command == "tables":
            tablenames = jsn['Tables'].keys()
            tables = []
            tablestype = []
            for i in tablenames:
                tables.append(i)
                tablestype.append(jsn['Tables'][i]['datatype'])
            df = pd.DataFrame(tables, columns=["TableName"])
            df["DataType"] = tablestype
            return df

        elif command == "constraints":

            tables = []
            fk = []
            pk = []
            colname = []
            tablenames = jsn['Tables'].keys()

            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            tables.append(i)
                            colname.append(col['column'])
                            if col['constraint'].__contains__("PRIMARY"):
                                fk.append("NULL")
                                pk.append(col['constraint'])
                            else :
                                fk.append(col['constraint'])
                                pk.append("NULL")

            df = pd.DataFrame(tables, columns=["TableName"])

            df["PrimayKey"] = pk
            df["ForeignKey"] = fk
            df["ColumnName"] = colname
            return df

        elif command == "methods":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic['MethodName'] = i
                dic["return"] = jsn['Methods'][i]['return']
                dic["returntype"] = jsn['Methods'][i]['returntype']
                dic["description"] = jsn['Methods'][i]['description']
                para = jsn['Methods'][i]['parameters']
                dic["parameters"] =str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "logs":
            col = ["Logs"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "delta":
            jsn = pd.read_json(self.schema_path, orient="records", typ="records")
            tables = []
            deltafield = []

            tablenames = jsn['Tables'].keys()
            for i in tablenames:
                if not i.__contains__("sys."):
                    cols = jsn['Tables'][i]['columns']
                    for col in cols:
                        if len(col['constraint']) > 0:
                            if col['constraint'].__contains__("PRIMARY"):
                                tables.append(i)
                                deltafield.append(col['column'])
            df = pd.DataFrame(tables, columns=["tablename"])
            df["DeltaField"] = deltafield
            return df

        elif command == "connectionstring":
            data = []
            methodsname = jsn['Methods'].keys()
            for i in methodsname:
                dic = dict()
                dic["Target"] = i
                para = jsn['Methods'][i]['parameters']
                dic["ConnectinParameters"] =  str(para)
                data.append(dic)
            df = pd.DataFrame(data)
            return df

        elif command == "version":
            return pd.DataFrame({'ConnectorVersion' : ["0.0.1"]})

        elif command == "limit":
            return pd.DataFrame({'ApiLimit' : ["100"]})

        elif command == "usage":
            #[licensekey	remaining_time	total_allowed_time	total_time_spent	start_time	end_time	total_time_taken	rows_allowed	rows_fetched	month	machine_name	mac	ip)
            col = ["Total Time Spent ", "Remaining Time", " Total Time alloted"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col)

        elif command == "license":
            col = ["LicenseKey", "ActivateDate", "ExpireDate", "Total Time Spent", "Remaining Time"]
            return pd.DataFrame(pg.search(self.LicenseKey, command), columns=col,index=None)

        elif command == 'Describe':
            tables = jsn['Tables'][table]
            data = []
            constraints = []
            pk = ""
            fk = ""
            Statement = 'CREATE TABLE '+ table+'('
            for i in tables['columns']:
                Statement = Statement+i['column']+" "+i['datatype']+",\n"
                if i['constraint'].__contains__("PRIMARY"):
                    pk = "PRIMARY KEY ("+i['column']+"),\n"
                elif i['constraint'].__contains__("FOREIGN "):
                    fk = i['constraint']
                else:
                    pass
            describedtable = Statement[:-2]+",\n"+pk+fk+');'

            return describedtable
        else:
            return pd.DataFrame({'Error' : ["INVALID SYS QUERY"]})


##########################################################################
                    ########### UTILITIES ##############
##########################################################################

    def dataToTable(self,results,table,query=None):
        """
        Description:
            This Method is used to convert the Given Dataframe into SQL Table
        Parameters:
            results(pandas.DataFrame): dataframe which have to be convert into SQL TABLE .
            table(string) : Name of the DataFrame.
            query(string): Query to get the Specific data from the given dataframe.
        """

        if 'index' in results.columns:
            results = results.drop(['index'], axis=1)
        d = results.to_sql(table, con=engine, if_exists='replace')


    def scheduler_task(self,data, rows, file_name=""):
        """
        Description:
            This Method is used to Schedule the task for given data.
        Parameters:
            rows(int): number of rows each schedule data have.
            data(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """

        self.StartTime = time.time()

        # assuming.......data's type is pandas framework.......
        global END, START, STOP
        START = 0
        END = START + rows

        if END > len(data):
            END = len(data)
            STOP = 1

        print(data.iloc[START: END])
        START += rows
        try:
            if len(file_name) > 1:
                data.to_csv(file_name)
            else:
                print('')
                print(data)
            status = {'Status': "Success! Task Scheduled"}
        except Exception as e:
            status = {'Status': f"Failed! {str(e)}"}
        self.payasyougo_check(self.scheduler_task,status)


    def schedule_data(self,sec, rows, df,filename):
        """
        Description:
            This Method is used to Schedule the data for given amount of time.
        Parameters:
            sec(int): Seconds for data to schedule again.
            rows(int): number of rows each schedule data have.
            df(pandas.DataFrame): Complete dataframe where row are schedule.
            filename(string): name of file where you have to store the data.

        """
        self.StartTime = time.time()
        print("Total rows : ", len(df))
        schedule.every(sec).seconds.do(
            lambda: self.scheduler_task(data=df, rows=rows, file_name=filename))  # file_name is optional

        while True:
            schedule.run_pending()
            if STOP:
                schedule.clear()
                break

        status = {'Status': "Success"}
        self.payasyougo_check(self.schedule_data,status)


    def connectEngine(self,username, password, server, database, tableName, df):
        """
        Description:
            This Method is used to Connect user with Databases using sql Alchemy and upload the dataframe.

        Parameters:
            username(string): database username.
            password(string): password of the database.
            server(string): server address of the database.
            database(string): Database name.
            tableName(string): Name of table you have to upload.
            df(pandas.DataFrame): Dataframe of the table which have to be upload.

        """
        self.StartTime = time.time()
        alchemyEngine = create_engine(
        f"postgresql+psycopg2://"+username+":"+password+"@"+server+"/"+database+", pool_recycle=3600")

        try:
            con = alchemyEngine.connect()
            df.to_sql(
                tableName, con, if_exists='replace')
            con.close()
            print("Data uploaded to table "+tableName)
            status = {'Status':"Success!",
                "Connection String":f'(postgresql+psycopg2://{username}:{password}@{server}/{database})'}

        except Exception as e:
            print (getattr(e, 'message', repr(e)))
            status = {
                'Status':'failed!',
                'error': str(e)
                }
        self.payasyougo_check(self.connectEngine,status)


    def Pagination(self,data, number_of_page=0):

        """
        Description:
            This Method is used to Perform pagination on the responses.
        Parameters:
            data(pandas.DataFrame): Response of in form of dataFrame
            Number_of_page: Number of pages data split into.

        """

        self.StartTime = time.time()
        per_page = 0
        total_page = 0

        if number_of_page > 0:
            per_page = math.ceil(len(data) / number_of_page)
            total_page = number_of_page
        count = 1
        print("Enter page number to show its data. \n")
        while True:
            print(data.iloc[((count - 1) * per_page): (count * per_page)])
            print("Showing page : ", count, " / ", total_page,"\n")
            key = input("Press 'A' or 'D' to navigate or jump to page no: ")
            if (key.isdigit()):
                page = int(key)
                if page > total_page:
                    print('Page doesnot exist')
                else:
                    count = page
            elif(key.lower() in ['a','d']):
                lower = key.lower()
                if lower == 'a':
                    if count > 1:
                        count -= 1
                elif lower == 'd':
                    if count < total_page:
                        count += 1
            else:
                print("Invalid page number")
                
            status = {'Status':"Success!",
                    'Page Number': number_of_page,
                    'data': data}
            self.payasyougo_check(self.Pagination,status)


    def payasyougo_check(self,method,status):
        try:
            pg.measure_execution_time(
                LicenseKey= self.LicenseKey,
                Function = method,
                StartTime = self.StartTime,
                EndTime = time.time(),
                connectername=Connector_name,
                status=status,
                logging=self.logging_options,
                log_connection=self.log_connection)
            self.log_connection = False

        except Exception as e:
            if self.__environment != 'development':
                raise Exception("Server Error - contact help@lyftrondata.com")