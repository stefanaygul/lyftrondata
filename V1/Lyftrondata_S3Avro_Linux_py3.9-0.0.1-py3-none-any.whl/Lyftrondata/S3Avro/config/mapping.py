MAPPING = {
    "aws":{
        "accessKey" : "access_key_id",
        "secretKey": "secret_access_key",
        "region" : "region_name",
        "bucket":"bucket",
        "aggregate": "aggregate",
        "lyftrondata_email" : "lyft_token_email", 
        }
}