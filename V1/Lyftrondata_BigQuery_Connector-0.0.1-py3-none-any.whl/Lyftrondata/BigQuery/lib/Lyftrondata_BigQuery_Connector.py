import copy
import time
from google.cloud import bigquery
from google.oauth2 import service_account
import pandas as pd
import json
from Lyftrondata import payasyougo as pg
from Lyftrondata.BigQuery.config.config import CONNECTION_KEY_MAPPING
from sqlalchemy import create_engine

engine = create_engine('sqlite://')
engines = [['PostgreSQL','postgresql://scott:tiger@localhost/mydatabase'],['Sql Server','mssql+pyodbc://scott:tiger@mydsn'],['Oracle','oracle://scott:tiger@127.0.0.1:1521/sidname'],['MySQL','mysql://scott:tiger@localhost/foo'],['SQLite','sqlite:///foo.db']]
supportedEngines = pd.DataFrame(columns=['Engine Name','Example Connection'],data=engines,index=None)

class Connect:

    license_key = ""
    connector_name = "Lyftrondata_BigQuery_Connector"
    gcp_dataset = ""
    gcp_project = ""
    logging = False
    logs_attenuation= 0
    logging_options = False
    log_connection = True
    __environment = ''
    StartTime = time.time()

    def __init__(self, license_key):
        self.license_key = license_key

    def dict_mapping(jsn, connection_type):
        from Lyftrondata.BigQuery.config import mapping
        
        mapping = mapping.MAPPING[connection_type]
        for m in mapping.keys():
            if jsn.get(m) is not None:
                jsn[mapping[m]] = jsn.pop(m)
        return jsn
    
    def json_parse(self,jsn, main_table_name):

        """
        Description:
            This method is used to parse/Normalize the Json Response fetched from endpoint in a way where
            object and array will be consider as separate Dataframes.

        Parameters:
            jsn(json): json response which have to be normalize.
            main_table_name: Main endpoint Name where the response is fetched from.

        Return:
            dataframes(dict) : dictionary which contains all the key as tablename and value as Dataframes.
        """
        dataframe = None
        simple = dict()
        dataFrames = dict()
        for key in jsn:
            val = jsn[key]
            if type(val) == list:
                dataFrames[key] = pd.DataFrame(val)
            elif type(val) == dict:
                dataframe = pd.DataFrame.from_dict(
                    val, orient="index")
                dataFrames[key] = dataframe.transpose()
            else:
                simple[key] = val
        if not simple:
            return dataFrames
        else:
            datafr = pd.DataFrame.from_dict(simple,orient="index")
            dataFrames[main_table_name] =datafr.transpose()
            return dataFrames

    def initializeJson(self, logging=False , logs_attenuation = 0,creds=''):
        """This Method is used to create the connection with API which return token/access responses.

        Args:
            creds([sting], required): [path to json file containing initialize credentials]

        Returns:

            tuple: (Boolean, S3Client)
        """
        StartTime = time.time()
        creds = creds if len(creds) > 0 else 'creds.json'
        try:
            with open(creds,'r') as init_jsn_file:
                init_jsn = json.load(init_jsn_file)
        except Exception as e:
            EndTime = time.time()
            status = {
                'Status': 'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.initializeJson, status)
            raise (e)
        connection_type= init_jsn.get('connection_type')

        init_params={
            "access_key_id" : self.dict_mapping(init_jsn,connection_type).get('access_key_id'),
            "secret_access_key" : self.dict_mapping(init_jsn,connection_type).get('secret_access_key'),
            "region_name" : self.dict_mapping(init_jsn,connection_type).get('region_name'),
            "bucket" : self.dict_mapping(init_jsn,connection_type).get('bucket'),
            "lyft_token_email" : self.dict_mapping(init_jsn,connection_type).get('lyft_token_email') or init_jsn.get('lyft_token_email') or '',
            "aggregate" : self.dict_mapping(init_jsn,connection_type).get('aggregate'),
            "username" : self.dict_mapping(init_jsn,connection_type).get('username'),
            "password" : self.dict_mapping(init_jsn,connection_type).get('password'),
            "personal_token" : self.dict_mapping(init_jsn,connection_type).get('personal_token') ,
            "subdomain" : self.dict_mapping(init_jsn,connection_type).get('subdomain'),
            "client_id" : self.dict_mapping(init_jsn,connection_type).get('client_id'),
            "client_secret" : self.dict_mapping(init_jsn,connection_type).get('client_secret'),
            "redirect_uri" : self.dict_mapping(init_jsn,connection_type).get('redirect_uri'),
            "environment" : self.dict_mapping(init_jsn,connection_type).get('environment'),
            "logs_attenuation" : self.dict_mapping(init_jsn,connection_type).get('logs_attenuation') or init_jsn.get('logs_attenuation') or 0,
            "logging" : self.dict_mapping(init_jsn,connection_type).get('logging') or init_jsn.get('logging') or False

        }

        try:

            init=  self.initialize(connection_type=connection_type,**init_params)
            status = f'Connection Successful!! \t Connection String ({str(init_jsn)})'
            EndTime = time.time()
            self.payasyougo_check(self.initializeJson, status)
            return init

        except Exception as e:
            status = f'Failed! \t Error ({str(e)}) '
            EndTime = time.time()
            self.payasyougo_check(self.initializeJson,status)
            raise Exception(e)

    def initialize(self,logging=False , logs_attenuation = 0, **credentials):
        """This method validates bigquery credentials and return bigquery client object

        :param credentials: json containing bigquery service account info and dataset name
        :param dataset: bigquery account dataset name
        :return: tuple containing True/False at zero index and bigquery client object at first index
        """
        self.logging = logging
        self.logs_attenuation = logs_attenuation

        try:
            start_time = time.time()
            dataset_name = credentials[CONNECTION_KEY_MAPPING[1]["lyftron_key"]]
            if not dataset_name:
                return False, "Missing dataset name in credentials"
            gcp_project = credentials[CONNECTION_KEY_MAPPING[0]["lyftron_key"]].get("project_id", "")
            gcp_dataset = f"{gcp_project}.{dataset_name}"
            self.gcp_dataset = gcp_dataset
            self.gcp_project = gcp_project
            service_account_josn = service_account.Credentials.from_service_account_info(
                credentials[CONNECTION_KEY_MAPPING[0]["lyftron_key"]]
            )
            client = bigquery.Client(
                project=gcp_project, credentials=service_account_josn)
            # dataset = bigquery.Dataset(gcp_dataset)
            end_time = time.time()
            status = {
                'Status': 'Success!'
            }
            self.payasyougo_check(self.initialize, status)
            return True, client
        except KeyError as key_err:
            status = {
                'Status': 'Failed!',
                'Error': str(key_err)
            }
            self.payasyougo_check(self.initialize, status)
            return False, f"Missing following key in input {key_err}"
        except Exception as e:
            status = {
                'Status': 'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.initialize, status)
            return False, str(e)

    def test_connection(self, client):

        try:
            start_time = time.time()
            client.query(f"SELECT * FROM {self.gcp_dataset}.INFORMATION_SCHEMA.TABLES")
            end_time = time.time()
            status = {
                'Status': 'Success!'
            }
            self.payasyougo_check(self.test_connection, status)
            return True, ''
        except Exception as e:
            end_time = time.time()
            status = {
                'Status': 'Failed!',
                'Error': str(e)
            }
            self.payasyougo_check(self.test_connection, status)
            return False, str(e)

    def execute_query(self, query, client=None):
        """
        Description:
            This Method is used to fetch data from API specific Table.
            
        Parameters:
            table(string): table name.
            client: bigquery client object
        
        Returns:
            results : df contains the complete response get from endpoint 
        """
        try:
            start_time = time.time()
            query_obj = client.query(query)
            results = query_obj.result()
            end_time = time.time()
            status = {
                "Status": "Success!"
            }
            self.payasyougo_check(self.execute_query, status)
            if "MERGE" in str(query):
                if query_obj.num_dml_affected_rows != None:
                    rows = query_obj.num_dml_affected_rows
                    json = {"number of rows inserted": rows}
                    return True, pd.json_normalize(json)
                else:
                    return True, ''
            if results.total_rows:
                return True, results.to_dataframe()
            else:
                return True, ''
        except Exception as e:
            return False, str(e)

    def fetchDataFromAPI(self,table,client=None):
        """
        Description:
            This Method is used to fetch data from API specific Table.
            
        Parameters:
            table(string): table name.
            client: sqlalchemy engine object
        
        Returns:
            jsn(json) : json file contains the complete response fetched from endpoint 
        """
        response_json = ""
        try:
            query = f"select * from {table}"
            query_result = client.query(query)
            response = query_result.result()

            status = {
                "Status": "Success!"
            }
        
            if response.total_rows:
                response =  response.to_dataframe()
                response_list = response.to_dict(orient='records')
                response_json = {table:response_list}
                
            self.payasyougo_check(self.fetchDataFromAPI, status)
            return response_json

        except Exception as err:
            return False, str(err)

    def dataToTable(self,results,table,query=None):
        """
        Description:
            This Method is used to convert the Given Dataframe into SQL Table
        Parameters:
            results(pandas.DataFrame): dataframe which have to be convert into SQL TABLE .
            table(string) : Name of the DataFrame.
            query(string): Query to get the Specific data from the given dataframe.
        """

        if 'index' in results.columns:
            results = results.drop(['index'], axis=1)
        d = results.to_sql(table, con=engine, if_exists='replace')

    def get_schema_list(self, client_obj):
        """This method will return list of all schema in given bigquery client object

        :param client_obj: bigquery client object
        :return: tuple containing True/False at zero index and list of all schema at first index
        """
        schema_list = []
        try:
            result_list = client_obj.list_datasets()
            [schema_list.append(row.dataset_id) for row in result_list if row.dataset_id not in schema_list]
            return True, schema_list
        except Exception as err:
            return False, str(err)

    def get_schema_objects(self, client_obj, schema_and_object_list):
        """This method will return list of all tables in given schema's

        :param client_obj: bigQuery client api object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of schema objects at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            response_data = {}
            schema_table_list = None
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        schema_table_list = client_obj.list_tables(dataset=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(row.table_id)
                            for row in schema_table_list if row.table_type == "TABLE"
                        ]
                    elif schema_object == "VIEW":
                        schema_table_list = client_obj.list_tables(dataset=schema_and_object_dict["schema_name"])
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(row.table_id)
                            for row in schema_table_list if row.table_type=="VIEW"
                        ]

                    elif schema_object == "INDEX":
                        # TODO
                        schema_table_list = client_obj.get_table_names(dataset=schema_and_object_dict["schema_name"])
                        for table_name in schema_table_list:
                            schema_index_list = self.inspector.get_indexes(table_name)
                            [response_data[schema_and_object_dict["schema_name"]][schema_object].append(index_name["name"]) for index_name in schema_index_list]
            return True, response_data
        except Exception as err:
            return False, str(err)

    def get_object_columns(self, client_obj, schema_and_object_list,read_json=None):
        """This method will return lst of columns in given schema objects

        :param client_obj: bigQuery client api object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            response_data = {}
            gcp_project = client_obj.project
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    object_key = list(schema_object.keys())[0]
                    response_data[schema_and_object_dict["schema_name"]][object_key] = []

                    if object_key == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            table_id = f"{gcp_project}.{schema_and_object_dict['schema_name']}.{table_name}"
                            table_obj = client_obj.get_table(table_id)
                            [
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][table_name][
                                    "columns"].append(
                                        {
                                        "column": column.name,
                                        "datatype": column.field_type,
                                        "description": column.description
                                        }
                                )
                                for column in table_obj.schema
                            ]
                    elif object_key == "VIEW":
                        schema_view_list = schema_object[object_key]
                        [
                            response_data[schema_and_object_dict["schema_name"]][object_key].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            table_id = f"{gcp_project}.{schema_and_object_dict['schema_name']}.{view_name}"
                            table_obj = client_obj.get_table(table_id)
                            [
                                response_data[schema_and_object_dict["schema_name"]][object_key][index][view_name][
                                    "columns"].append(
                                        {
                                        "column": column.name,
                                        "datatype": column.field_type,
                                        "description": column.description
                                        }
                                )
                                for column in table_obj.schema
                            ]
                    # elif object_key == "INDEX":
                    #     schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                    #     for table_name in schema_table_list:
                    #         schema_index_list = inspector.get_indexes(table_name)
                    #         [
                    #             response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                    #                 index_name["name"]
                    #             )
                    #             for index_name in schema_index_list
                    #         ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def get_schema_object_and_columns(self, client_obj, schema_and_object_list):
        """This method will return lst of columns in given schema objects

        :param client_obj: bigQuery client api object
        :param schema_and_object_list: list of schema and object
        :return: tuple containing True/False at zero index and list of given object columns at first index
        """
        try:
            if not type(schema_and_object_list) == list:
                return False, "Please provide schema and object list array format"
            elif not len(schema_and_object_list):
                return False, "Please provide atleast one schema and object name in list"
            response_data = {}
            gcp_project = client_obj.project
            for schema_and_object_dict in schema_and_object_list:
                response_data[schema_and_object_dict["schema_name"]] = {}

                # Check if object list in each schema dict is list and contains atleast one object name
                if not type(schema_and_object_dict["object_list"]) == list:
                    return False, f"Please provide objects name in array for schema {schema_and_object_dict['schema_name']}"
                elif not len(schema_and_object_dict["object_list"]):
                    return False, f"Please provide atleast one object name in object list of {schema_and_object_dict['schema_name']}"

                for schema_object in schema_and_object_dict["object_list"]:
                    response_data[schema_and_object_dict["schema_name"]][schema_object] = []

                    if schema_object == "TABLE":
                        # Get list of all tables for schema and append in response dict
                        schema_table_response = client_obj.list_tables(dataset=schema_and_object_dict["schema_name"])
                        schema_table_list = []
                        [
                            schema_table_list.append(table_obj.table_id)
                            for table_obj in schema_table_response if table_obj.table_type == "TABLE"
                        ]
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {table_name: {"columns": []}}
                            )
                            for table_name in schema_table_list
                        ]
                        # Get columns for each table and append in response dict
                        for index, table_name in enumerate(schema_table_list):
                            table_id = f"{gcp_project}.{schema_and_object_dict['schema_name']}.{table_name}"
                            table_obj = client_obj.get_table(table_id)
                            [
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][table_name][
                                    "columns"].append(
                                        {
                                        "column": column.name,
                                        "datatype": column.field_type,
                                        "description": column.description
                                        }
                                )
                                for column in table_obj.schema
                            ]
                    elif schema_object == "VIEW":
                        schema_view_response = client_obj.list_tables(dataset=schema_and_object_dict["schema_name"])

                        schema_view_list = []
                        [
                            schema_view_list.append(table_obj.table_id)
                            for table_obj in schema_view_response if table_obj.table_type == "VIEW"
                        ]
                        [
                            response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                                {view_name: {"columns": []}}
                            )
                            for view_name in schema_view_list
                        ]
                        # Get columns for each view and append in response dict
                        for index, view_name in enumerate(schema_view_list):
                            table_id = f"{gcp_project}.{schema_and_object_dict['schema_name']}.{view_name}"
                            table_obj = client_obj.get_table(table_id)
                            [
                                response_data[schema_and_object_dict["schema_name"]][schema_object][index][view_name][
                                    "columns"].append(
                                        {
                                        "column": column.name,
                                        "datatype": column.field_type,
                                        "description": column.description
                                        }
                                )
                                for column in table_obj.schema
                            ]
                    # elif object_key == "INDEX":
                    #     schema_table_list = inspector.get_table_names(schema=schema_and_object_dict["schema_name"])
                    #     for table_name in schema_table_list:
                    #         schema_index_list = inspector.get_indexes(table_name)
                    #         [
                    #             response_data[schema_and_object_dict["schema_name"]][schema_object].append(
                    #                 index_name["name"]
                    #             )
                    #             for index_name in schema_index_list
                    #         ]
                    else:
                        pass
            return True, response_data
        except KeyError as key_err:
            return False, f"Missing following key in input {key_err}"
        except Exception as err:
            return False, str(err)

    def getMetadata(self, creds):
        start_time = time.time()
        try:
            gcp_project = creds["project_id"]
            gcp_dataset = gcp_project+"."+creds["dataset"]
            del creds['dataset']
            credentials = service_account.Credentials.from_service_account_info(
                creds)
            client = bigquery.Client(
                project=gcp_project, credentials=credentials)
            dataset = bigquery.Dataset(gcp_dataset)

            query = client.query("""
                                 SELECT table_name, column_name, data_type
                    FROM `{DATASET}`.INFORMATION_SCHEMA.COLUMNS
                    ORDER BY table_name, ordinal_position
                                 """.format(DATASET=gcp_dataset))
            df = pd.DataFrame(query)
            df.style.hide_index()
            js = json.loads(df.to_json(orient='table', index=False))
            end_time = time.time()
            status = {
                "Status": "Success!"
            }
            self.payasyougo_check(self.getMetadata, status)
            return js["data"]
        except Exception as e:
            end_time = time.time()
            status = {
                "Status": "Failed!",
                'Error': str(e)
            }
            self.payasyougo_check(self.getMetadata, status)
            return str(e)

    def CSVtoGCP(self, client, dataset_id, table_id, filename, schema_list):
        """Upload you CSV file to Google Big Query

        Args:
            client (object): Your big query client which you intialized
            dataset_id (string): Your big query dataset id
            table_id (string): Your big query table_id
            filename ([type]): Your CSV file location. Should be absolute path
            schema_list ([type]): Your big query mapping with column datatypes

        Returns:
            Object or String: Will return status of your upload request
        """
        start_time = time.time()
        dataset_ref = client.dataset(dataset_id)
        table_ref = dataset_ref.table(table_id)
        job_config = bigquery.LoadJobConfig(schema=schema_list)
        job_config.source_format = bigquery.SourceFormat.CSV
        job_config.allow_quoted_newlines = True
        #job_config.write_disposition ="WRITE_TRUNCATE"

        # load the csv into bigquery
        with open(filename, "rb") as source_file:
            job = client.load_table_from_file(
                source_file, table_ref, job_config=job_config)

        end_time = time.time()
        status = {
            'Status': 'Success!'
        }
        self.payasyougo_check(self.CSVtoGCP, status)

        return job.result()  # Waits for table load to complete.

    def DFtoGCP(self, client, dataset_id, table_id, dataframe, target_action, schema_list):

        start_time = time.time()
        job_config = bigquery.LoadJobConfig(schema=schema_list)
        job_config.write_disposition = target_action
        # load the csv into bigquery
        job = client.load_table_from_dataframe(
            dataframe, dataset_id+"."+table_id, job_config=job_config
        )

        end_time = time.time()
        atus = {
            'Status': 'Success!'
        }
        self.payasyougo_check(self.DFtoGCP, self.status)

        return job.result()  # Waits for table load to complete.

    def uploadARV(self, client, dataset_id, table_id, loc, target_action, uri, schema_list):
        """Upload .arv file to bigquery object. The file can be stored locally or on cloud.

        Args:
            client (object): Your bigquery client object.
            dataset_id (string): your bigquery dataset id.
            table_id (string): your bigquery table id.
            loc (string): Location of the file or URI. Make sure to set URI as false if working with file.
            target_action (string): Truncate/Write in target.
            uri (boolean): If true work with URI(online file storage). If false will work with locally stored files
        """
        job_config = bigquery.LoadJobConfig(schema=schema_list,
                                            source_format=bigquery.SourceFormat.AVRO)
        job_config.write_disposition = target_action
        global load_job

        if uri:
            load_job = client.load_table_from_uri(
                loc, dataset_id+"."+table_id, job_config=job_config
            )  # Make an API request.
        else:
            with open(loc, "rb") as source_file:
                load_job = client.load_table_from_file(
                    source_file, dataset_id+"."+table_id, job_config=job_config
                )

        load_job.result()  # Waits for the job to complete.

        destination_table = client.get_table(table_id)
        print("Loaded {} rows.".format(destination_table.num_rows))

    def payasyougo_check(self, method, status):
        try:
            pg.measure_execution_time(
                LicenseKey=self.license_key,
                Function=method,
                StartTime=self.StartTime,
                EndTime=time.time(),
                connectername=self.connector_name,
                status=status,
                logging=self.logging_options,
                log_connection=self.log_connection)
            self.log_connection = False
        except Exception as e:

            if self.__environment != 'development':
                raise Exception("Server Error - contact help@lyftrondata.com")
