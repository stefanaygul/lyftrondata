CONNECTION_KEY_MAPPING = [
    {
        "lyftron_key": "serviceaccountjson",
        "bigquery_key": "service_account_json"
    },
    {
        "lyftron_key": "dataset",
        "bigquery_key": "dataset"
    },
]
