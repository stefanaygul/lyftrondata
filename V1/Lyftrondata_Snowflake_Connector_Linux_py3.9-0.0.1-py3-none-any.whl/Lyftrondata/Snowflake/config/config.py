CONNECTION_KEY_MAPPING = [
    {
        "lyftron_key": "username",
        "snowflake_key": "sfUser"
    },
    {
        "lyftron_key": "password",
        "snowflake_key": "sfPassword"
    },
    {
        "lyftron_key": "hostname",
        "snowflake_key": "sfUrl"
    },
    {
        "lyftron_key": "database",
        "snowflake_key": "sfDatabase"
    },
    {
        "lyftron_key": "schema",
        "snowflake_key": "sfSchema"
    },
    {
        "lyftron_key": "warehouse",
        "snowflake_key": "sfWarehouse"
    },
    {
        "lyftron_key": "role",
        "snowflake_key": "sfRole"
    }
]
JDBC_CONN_STRING = f"snowflake://username:password@account/database/schema?warehouse=warehouse&role=role"
